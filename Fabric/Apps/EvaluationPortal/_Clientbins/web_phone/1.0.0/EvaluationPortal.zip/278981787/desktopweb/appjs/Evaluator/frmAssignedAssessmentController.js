endFlag = false;
entryFlag = false;
define("Evaluator/userfrmAssignedAssessmentController", ["AppToolBox", "Utils"], (AppToolBox, Utils) => ({
    onNavigate: function(appStatus) {
        this.view.preShow = this.preShow.bind(this, appStatus);
        this.view.postShow = this.postShow;
    },
    postShow: function() {},
    preShow: function(appStatus) {
        const scope = this;
        scope.view.onDeviceBack = function() {};
        kony.application.showLoadingScreen();
        var beforeUpdate = AppToolBox.store.getItem("BeforeUpdateData");
        var data = AppToolBox.store.getItem("applicationData");
        if (!AppToolBox.util.isNil(appStatus)) {
            this.filterByStatus(appStatus);
        } else {
            this.setAssessmentList();
        }
        this.view.segFilterStatus.onRowClick = this.filterByStatus.bind(this);
        this.view.segFilterRole.onRowClick = this.filterByRole.bind(this);
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navToDash.bind(this);
        this.view.segAssignedAssessments.onRowClick = this.navToApproval.bind(this);
        this.view.lblDownloadReport.onTouchStart = this.downloadReports.bind(this);
        this.view.imgDownload.onTouchStart = this.downloadReports.bind(this);
    },
    navToDash: function() {
        AppToolBox.navigation.navigateTo("frmEvaluatorDash");
    },
    scrollEnd: function() {
        if (endFlag === false) {
            var app = AppToolBox.store.getItem("applicationData");
            len = len + 20;
            if (app.length > len) {
                this.setAssessmentList(len);
            } else {
                endFlag = true;
                this.setAssessmentList(app.length);
            }
        }
    },
    filterStatus: function() {
        if (this.view.flxStatusFilterPopup.isVisible === true) {
            this.view.flxStatusFilterPopup.isVisible = false;
        } else {
            var status = AppToolBox.store.getItem("StatusList");
            var dataLst = [];
            var dataMap = {
                lblFilter: "lblFilter"
            };
            dataLst.push({
                lblFilter: "All STATUS"
            });
            for (var i = 0; i < status.length; i++) {
                var data = {
                    lblFilter: status[i]
                };
                dataLst.push(data);
            }
            this.view.segFilterStatus.widgetDataMap = dataMap;
            this.view.segFilterStatus.setData(dataLst);
            this.view.flxStatusFilterPopup.isVisible = true;
            this.view.flxRoleFilterPopup.isVisible = false;
        }
    },
    filterByStatus: function(status) {
        const scope = this;
        if (typeof(status) !== 'string') {
            status = scope.view.segFilterStatus.selectedRowItems[0].lblFilter.toUpperCase();
        }
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        scope.checkStatus(status, app);
    },
    checkStatus: function(status, app) {
        if (status === "ALL STATUS") {
            AppToolBox.store.setItem("applicationData", app);
            this.setAssessmentList();
        } else {
            const filterApp = this.filterAppByStatus(status);
            AppToolBox.store.setItem("applicationData", filterApp);
            this.setAssessmentList();
        }
    },
    filterAppByStatus: function(status) {
        var filApp = [];
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        for (var i = 0; i < app.length; i++) {
            if (app[i].ApplicationStatus === status) {
                filApp.push(app[i]);
            }
        }
        return filApp;
    },
    filterRole: function() {
        if (this.view.flxRoleFilterPopup.isVisible === true) {
            this.view.flxRoleFilterPopup.isVisible = false;
        } else {
            var Role = AppToolBox.store.getItem("RoleList");
            var dataLst = [];
            var dataMap = {
                lblFilter: "lblFilter"
            };
            dataLst.push({
                lblFilter: "All ROLE"
            });
            for (var i = 0; i < Role.length; i++) {
                var data = {
                    lblFilter: Role[i]
                };
                dataLst.push(data);
            }
            this.view.segFilterRole.widgetDataMap = dataMap;
            this.view.segFilterRole.setData(dataLst);
            this.view.flxRoleFilterPopup.isVisible = true;
            this.view.flxStatusFilterPopup.isVisible = false;
        }
    },
    filterByRole: function() {
        var role = this.view.segFilterRole.selectedRowItems[0].lblFilter;
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        if (role === "All ROLE") {
            AppToolBox.store.setItem("applicationData", app);
            this.setAssessmentList();
        } else {
            var filterApp = this.filterAppByRole(role);
            AppToolBox.store.setItem("applicationData", filterApp);
            this.setAssessmentList();
        }
    },
    filterAppByRole: function(Role) {
        var filApp = [];
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        for (var i = 0; i < app.length; i++) {
            if (app[i].RoleID.toLowerCase().replace("_", " ") === Role.toLowerCase()) {
                app[i].Role = app[i].Role.replace("_", " ");
                filApp.push(app[i]);
            }
        }
        return filApp;
    },
    formatDate: function(date) {
        const [year, month, day] = date.split('-');
        const result = [day, month, year].join('/');
        return result;
    },
    diffDays: function(date2) {
        var dt1 = new Date(date2);
        var dt2 = new Date();
        var diff = Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24));
        return diff;
    },
    navToApproval: function() {
        var selectedData = this.view.segAssignedAssessments.selectedRowItems[0];
        AppToolBox.store.setItem("RowData", selectedData);
        AppToolBox.navigation.navigateTo("frmApprovalAssessment");
    },
    setAssessmentList: function() {
        var scopeObj = this;
        this.view.flxStatusFilterPopup.isVisible = false;
        this.view.flxRoleFilterPopup.isVisible = false;
        var user = AppToolBox.store.getItem("UserList");
        var app = AppToolBox.store.getItem("Applistdata");
        var data = AppToolBox.store.getItem("applicationData");
        var beforeUpdate = AppToolBox.store.getItem("BeforeUpdateData");
        var status = AppToolBox.store.getItem("AppStatusResponse");
        var AssessmentList = [];
        //var len = assessLen;
        var dataMap = {
            lblAssessmentName: "lblAssessmentName",
            lblDuration: "lblDuration",
            lblAssigneeName: "lblAssigneeName",
            lblRole: "lblRole",
            lblStatus: "lblStatus",
            flxStatus: "flxStatus",
            flxRole: "flxRole",
            flxAssigneeName: "flxAssigneeName",
            imgSortRole: "imgSortRole",
            imgSortAssignee: "imgSortAssignee"
        };
        var userName;
        var appName;
        var assessID;
        var submittedDate = null;
        if (!entryFlag) {
            var statusLst = [];
            statusLst.push(data[0].ApplicationStatus);
            var RoleLst = [];
            RoleLst.push(data[0].Role.replace("_", " "));
        }
        this.view.segAssignedAssessments.widgetDataMap = dataMap;
        for (var i = data.length - 1; i >= 0; i--) {
            userName = data[i].Name;
            var assessmentName = {
                "text": data[i].AssessmentName,
                "isVisible": true
            };
            //var duration = data[i].AssigneeName;
            var Details;
            var date = data[i].StartDate;
            var Duration = data[i].Duration;
            if (data[i].ApplicationStatus === "INITIATED") {
                Details = "Duration: " + Duration + " Days";
            } else if (data[i].ApplicationStatus === "INPROGRESS") {
                var RemainDays = Duration - this.diffDays(date);
                Details = "Remaining Days: " + Math.abs(RemainDays) + " Days";
            } else if (data[i].ApplicationStatus === "OVERDUE") {
                var OverdueDays = Duration - this.diffDays(date);
                Details = "Time Lag: " + Math.abs(OverdueDays) + " Days";
            } else if (data[i].ApplicationStatus === "FAILED") {
                Details = "Rejected On: " + this.formatDate(data[i].UpdatedTs.slice(0, 10)); + " Days";
            } else if (data[i].ApplicationStatus === "COMPLETED") {
                submittedDate = this.formatDate(data[i].UpdatedTs.slice(0, 10));
                Details = "Approved On: " + submittedDate;
            } else if (data[i].ApplicationStatus === "SUBMITTED") {
                submittedDate = this.formatDate(data[i].UpdatedTs.slice(0, 10));
                Details = "Submitted On: " + submittedDate;
            }
            assessmentName = {
                "text": data[i].AssessmentName,
                "skin": "sknlblbreadcrumb411062"
            };
            var Role = data[i].Role.replace("_", " ");
            var statusskn = data[i].ApplicationStatus === "INITIATED" ? "sknlblFFFBFBbg7E6FFF" : data[i].ApplicationStatus === "INPROGRESS" ? "sknlblFFFBFBbgFFCC29" : data[i].ApplicationStatus === "OVERDUE" || data[i].ApplicationStatus === "FAILED" ? "sknlblFFFBFBbgF37070" : "sknlblFFFBFBbg4ECC48";
            if (!entryFlag) {
                if (statusLst.includes(data[i].ApplicationStatus)) {} else {
                    statusLst.push(data[i].ApplicationStatus);
                }
                if (RoleLst.includes(Role)) {} else {
                    RoleLst.push(Role);
                }
            }
            var AssessLst = {
                lblAssessmentName: assessmentName,
                lblDuration: userName,
                lblAssigneeName: Role,
                lblRole: Details,
                submittedDate: submittedDate,
                Duration: Duration,
                assessID: data[i].AssessmentID,
                role: data[i].Role,
                AppID: data[i].ApplicationID,
                status: data[i].ApplicationStatus,
                assessmentInstruction: data[i].AssessmentInstruction,
                userID: data[i].UserID,
                lblStatus: {
                    text: data[i].ApplicationStatus === "INPROGRESS" ? "In-progress" : data[i].ApplicationStatus.charAt(0) + data[i].ApplicationStatus.slice(1).toLowerCase(),
                    skin: statusskn
                }
            };
            AssessmentList.push(AssessLst);
        }
        if (!entryFlag) {
            AppToolBox.store.setItem("StatusList", statusLst);
            AppToolBox.store.setItem("RoleList", RoleLst);
        }
        var allUsers = [
            [{
                lblAssessmentName: "ASSESSMENT NAME",
                lblDuration: "ASSIGNEE NAME",
                lblAssigneeName: "ASSIGNEE ROLE",
                lblRole: "DETAILS",
                lblStatus: "STATUS",
                flxStatus: {
                    onClick: this.filterStatus.bind(this)
                },
                flxAssigneeName: {
                    onClick: this.filterRole.bind(this)
                },
                imgSortAssignee: {
                    "isVisible": true
                },
                imgSortRole: {
                    "isVisible": false
                }
            }, AssessmentList]
        ];
        this.view.segAssignedAssessments.setData(allUsers);
        entryFlag = true;
        kony.application.dismissLoadingScreen();
    },
    downloadReports: function() {
        var headerData = this.view.segAssignedAssessments.data[0][0];
        var headerAssignedData = {
            "assessmentName": headerData.lblAssessmentName.toLowerCase(),
            "assigneeName": headerData.lblDuration.toLowerCase(),
            "assigneeRole": headerData.lblAssigneeName.toLowerCase(),
            "details": headerData.lblRole.toLowerCase(),
            "status": headerData.lblStatus.toLowerCase()
        };
        var segmentData = this.view.segAssignedAssessments.data[0][1];
        var segmentAssignedData = [];
        for (var count = 0; count < segmentData.length; count++) {
            segmentAssignedData[count] = {
                "assessmentName": segmentData[count].lblAssessmentName.text,
                "assigneeName": segmentData[count].lblDuration,
                "assigneeRole": segmentData[count].role,
                "details": segmentData[count].lblRole,
                "status": segmentData[count].lblStatus.text
            };
        }
        Utils.getReports(headerAssignedData, segmentAssignedData);
    }
}));
define("Evaluator/frmAssignedAssessmentControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Evaluator/frmAssignedAssessmentController", ["Evaluator/userfrmAssignedAssessmentController", "Evaluator/frmAssignedAssessmentControllerActions"], function() {
    var controller = require("Evaluator/userfrmAssignedAssessmentController");
    var controllerActions = ["Evaluator/frmAssignedAssessmentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
