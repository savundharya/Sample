define(["animations", "AppToolBox", "Utils"], (animations, AppToolBox, Utils) => ({
    convertAlltoBase64: function(fileArray, callback) {
        var count = 0;
        var base64Array = [];

        function individualCallback(index, base64string) {
            count++;
            base64Array.splice(index, 0, base64string);
            if (count === fileArray.length) {
                callback(base64Array);
            }
        }
        fileArray.forEach(function(fileObject, index) {
            this.convertToBase64(fileObject.file, individualCallback.bind(null, index));
        }.bind(this));
    },
    convertToBase64: function(file, callback) {
        var reader = new FileReader();
        reader.onloadend = function() {
            var content = reader.result.substring(reader.result.indexOf(",") + 1);
            callback(content);
        };
        reader.readAsDataURL(file);
    },
    ConvertBlobToFile: function(file, fileName = "Specifications document") {
        try {
            const blob = this.base64ToBlob(file);
            const blobURL = URL.createObjectURL(blob);
            const link = document.createElement('a');
            //link.setAttribute('target', '_blank');
            link.setAttribute('download', `${fileName}.zip`)
            link.href = blobURL;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            kony.application.dismissLoadingScreen();
        } catch (e) {
            kony.print(`Catch of ConvertBlobToFile ${e.message}`);
        }
    },
    base64ToBlob: function(base64) {
        const binaryString = window.atob(base64);
        const len = binaryString.length;
        const bytes = new Uint8Array(len);
        for (let i = 0; i < len; ++i) {
            bytes[i] = binaryString.charCodeAt(i);
        }
        return new Blob([bytes], {
            type: 'application/pdf'
        });
    },
    getBase64: function(file) {
        var binaryData = file;
        //Converting Binary Data to base 64
        var base64String = window.btoa(binaryData);
        //var a  = window.btoa(file);
        return base64String;
    },
    checkValidPassword: function(passwordString) {
        var regex = /^(?=.*\d)(?=.*[a-zA-Z])(?=.*[A-Z])(?=.*[-\#\$\.\%\&\*\@])(?=.*[a-zA-Z]).{8,16}$/;
        if (regex.exec(passwordString) === null) {
            return false;
        } else {
            return true;
        }
    },
    checkValidUsername: function(usernameString) {
        var regex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (regex.exec(usernameString) === null) {
            return false;
        } else {
            return true;
        }
    },
    getReports: function(headerAssignedData, segmentAssignedData) {
        var headerData = headerAssignedData;
        var dataExport = JSON.stringify(headerData);
        var headerValue = typeof dataExport !== 'object' ? JSON.parse(dataExport) : dataExport;
        var segData = segmentAssignedData;
        var strExport = JSON.stringify(segData);
        var segmentValue = typeof strExport !== 'object' ? JSON.parse(strExport) : strExport;
        var str = '';
        line = headerValue.assessmentName.charAt(0).toUpperCase() + headerValue.assessmentName.slice(1) + ',' + headerValue.assigneeName.charAt(0).toUpperCase() + headerValue.assigneeName.slice(1) + ',' + headerValue.assigneeRole.charAt(0).toUpperCase() + headerValue.assigneeRole.slice(1) + ',' + headerValue.details.charAt(0).toUpperCase() + headerValue.details.slice(1) + ',' + headerValue.status.charAt(0).toUpperCase() + headerValue.status.slice(1);
        str += line + '\r\n';
        for (var i = 0; i < segmentValue.length; i++) {
            line = '';
            line += segmentValue[i].assessmentName + ',' + segmentValue[i].assigneeName + ',' + segmentValue[i].assigneeRole + ',' + segmentValue[i].details + ',' + segmentValue[i].status;
            str += line + '\r\n';
        }
        var textToWrite = str;
        var line = "";
        var textFileAsBlob = new Blob([textToWrite], {
            type: 'text/plain'
        });
        var fileNameToSaveAs = "Reports.csv";
        var downloadLink = document.createElement("a");
        downloadLink.download = fileNameToSaveAs;
        downloadLink.innerHTML = "Download File";
        if (window.webkitURL !== null) {
            downloadLink.href = window.webkitURL.createObjectURL(textFileAsBlob);
        } else {
            downloadLink.href = window.URL.createObjectURL(textFileAsBlob);
            downloadLink.onclick = destroyClickedElement;
            downloadLink.style.display = "none";
            document.body.appendChild(downloadLink);
        }
        downloadLink.click();
    },
    logout: function() {
        const serviceName = "identity_service_name";
        // Get an instance of SDK
        const customAuth = KNYMobileFabric.getIdentityService("Login");
        let options = {};
        options["slo"] = true;
        customAuth.logout(function(response) {
            kony.print("Logout success: " + JSON.stringify(response));
            AppToolBox.store.clear();
            applicationDetails.clear();
            AppToolBox.navigation.navigateTo("frmLogin");
        }, function(error) {
            kony.print("Logout failure: " + JSON.stringify(error));
        }, options);
    }
}));