endFlag = false;
define("AdminFlow/userfrmViewAllAssessmentController", ["AppToolBox", "Utils"], (AppToolBox, Utils) => ({
    onNavigate: function() {
        this.view.preShow = this.preShow;
        this.view.postShow = this.postShow;
    },
    preShow: function() {
        var scope = this;
        scope.view.onDeviceBack = function() {};
        var beforeUpdate = AppToolBox.store.getItem("BeforeUpdateData");
        var data = AppToolBox.store.getItem("applicationData");
        if (beforeUpdate.length > 20) {
            len = 20;
            this.setAssessmentList(len);
        } else {
            this.setAssessmentList(beforeUpdate.length);
        }
        this.view.segFilterStatus.onRowClick = this.filterByStatus.bind(this);
        this.view.segFilterRole.onRowClick = this.filterByRole.bind(this);
        this.view.segManageAllAssessment.scrollingEvents = {
            "onReachingEnd": this.scrollEnd.bind(this)
        };
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navToDash.bind(this);
        this.view.lblDownloadReport.onTouchStart = this.downloadReports.bind(this);
        this.view.imgDownload.onTouchStart = this.downloadReports.bind(this);
    },
    navToDash: function() {
        AppToolBox.navigation.navigateTo("frmAdminDash");
    },
    scrollEnd: function() {
        if (endFlag === false) {
            var app = AppToolBox.store.getItem("applicationData");
            len = len + 20;
            if (app.length > len) {
                this.setAssessmentList(len);
            } else {
                endFlag = true;
                this.setAssessmentList(app.length);
            }
        }
    },
    filterStatus: function() {
        if (this.view.flxStatusFilterPopup.isVisible === true) {
            this.view.flxStatusFilterPopup.isVisible = false;
        } else {
            var status = AppToolBox.store.getItem("StatusList");
            var dataLst = [];
            var dataMap = {
                lblFilter: "lblFilter"
            };
            dataLst.push({
                lblFilter: "All STATUS"
            });
            for (var i = 0; i < status.length; i++) {
                var data = {
                    lblFilter: status[i]
                };
                dataLst.push(data);
            }
            this.view.segFilterStatus.widgetDataMap = dataMap;
            this.view.segFilterStatus.setData(dataLst);
            this.view.flxStatusFilterPopup.isVisible = true;
            this.view.flxRoleFilterPopup.isVisible = false;
        }
    },
    filterByStatus: function() {
        var status = this.view.segFilterStatus.selectedRowItems[0].lblFilter;
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        if (status === "All STATUS") {
            AppToolBox.store.setItem("applicationData", app);
            this.setAssessmentList(app.length);
        } else {
            var filterApp = this.filterAppByStatus(status);
            AppToolBox.store.setItem("applicationData", filterApp);
            this.setAssessmentList(filterApp.length);
        }
    },
    filterAppByStatus: function(status) {
        var filApp = [];
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        for (var i = 0; i < app.length; i++) {
            if (app[i].ApplicationStatus === status) {
                filApp.push(app[i]);
            }
        }
        return filApp;
    },
    filterRole: function() {
        if (this.view.flxRoleFilterPopup.isVisible === true) {
            this.view.flxRoleFilterPopup.isVisible = false;
        } else {
            var Role = AppToolBox.store.getItem("RoleList");
            var dataLst = [];
            var dataMap = {
                lblFilter: "lblFilter"
            };
            dataLst.push({
                lblFilter: "All ROLE"
            });
            for (var i = 0; i < Role.length; i++) {
                var data = {
                    lblFilter: Role[i]
                };
                dataLst.push(data);
            }
            this.view.segFilterRole.widgetDataMap = dataMap;
            this.view.segFilterRole.setData(dataLst);
            this.view.flxRoleFilterPopup.isVisible = true;
            this.view.flxStatusFilterPopup.isVisible = false;
        }
    },
    filterByRole: function() {
        var role = this.view.segFilterRole.selectedRowItems[0].lblFilter;
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        if (role === "All ROLE") {
            AppToolBox.store.setItem("applicationData", app);
            this.setAssessmentList(app.length);
        } else {
            var filterApp = this.filterAppByRole(role);
            AppToolBox.store.setItem("applicationData", filterApp);
            this.setAssessmentList(filterApp.length);
        }
    },
    filterAppByRole: function(Role) {
        var filApp = [];
        var app = AppToolBox.store.getItem("BeforeUpdateData");
        for (var i = 0; i < app.length; i++) {
            if (app[i].RoleID.toLowerCase().replace("_", " ") === Role.toLowerCase()) {
                app[i].Role = app[i].Role.replace("_", " ");
                filApp.push(app[i]);
            }
        }
        return filApp;
    },
    setAssessmentList: function(assessLen) {
        this.view.flxStatusFilterPopup.isVisible = false;
        this.view.flxRoleFilterPopup.isVisible = false;
        var user = AppToolBox.store.getItem("UserList");
        var app = AppToolBox.store.getItem("Applistdata");
        var data = AppToolBox.store.getItem("applicationData");
        var beforeUpdate = AppToolBox.store.getItem("BeforeUpdateData");
        var status = AppToolBox.store.getItem("AppStatusResponse");
        var AssessmentList = [];
        var len = assessLen;
        var dataMap = {
            lblAssessmentName: "lblAssessmentName",
            lblDuration: "lblDuration",
            lblAssigneeName: "lblAssigneeName",
            lblRole: "lblRole",
            lblStatus: "lblStatus",
            flxStatus: "flxStatus",
            flxRole: "flxRole"
        };
        var userName;
        var appName;
        var assessID;
        var statusLst = [];
        statusLst.push(data[0].ApplicationStatus);
        var RoleLst = [];
        RoleLst.push(data[0].Role.replace("_", " "));
        this.view.segManageAllAssessment.widgetDataMap = dataMap;
        for (var i = 0; i < assessLen; i++) {
            userName = data[i].Name;
            var assessmentName = data[i].AssessmentName;
            var duration = data[i].Duration + " Days";
            var Role = data[i].Role.replace("_", " ");
            var statusskn = data[i].ApplicationStatus === "INITIATED" ? "sknlblFFFBFBbg7E6FFF" : data[i].ApplicationStatus === "INPROGRESS" ? "sknlblFFFBFBbgFFCC29" : data[i].ApplicationStatus === "OVERDUE" || data[i].ApplicationStatus === "FAILED" ? "sknlblFFFBFBbgF37070" : "sknlblFFFBFBbg4ECC48";
            if (statusLst.includes(data[i].ApplicationStatus)) {} else {
                statusLst.push(data[i].ApplicationStatus);
            }
            if (RoleLst.includes(Role)) {} else {
                RoleLst.push(Role);
            }
            var AssessLst = {
                lblAssessmentName: assessmentName,
                lblDuration: duration,
                lblAssigneeName: userName,
                lblRole: Role,
                lblStatus: {
                    text: data[i].ApplicationStatus === "INPROGRESS" ? "In-progress" : data[i].ApplicationStatus.charAt(0) + data[i].ApplicationStatus.slice(1).toLowerCase(),
                    skin: statusskn
                }
            };
            AssessmentList.push(AssessLst);
        }
        AppToolBox.store.setItem("StatusList", statusLst);
        AppToolBox.store.setItem("RoleList", RoleLst);
        var allUsers = [
            [{
                lblAssessmentName: "ASSESSMENT NAME",
                lblDuration: "DURATION",
                lblAssigneeName: "ASSIGNEE NAME",
                lblRole: "ROLE",
                lblStatus: "STATUS",
                flxStatus: {
                    onClick: this.filterStatus.bind(this)
                },
                flxRole: {
                    onClick: this.filterRole.bind(this)
                }
            }, AssessmentList]
        ];
        this.view.segManageAllAssessment.setData(allUsers);
        kony.application.dismissLoadingScreen();
    },
    downloadReports: function() {
        var headerData = this.view.segManageAllAssessment.data[0][0];
        var headerAssignedData = {
            "assessmentName": headerData.lblAssessmentName.toLowerCase(),
            "assigneeName": headerData.lblAssigneeName.toLowerCase(),
            "assigneeRole": headerData.lblDuration.toLowerCase(),
            "details": headerData.lblRole.toLowerCase(),
            "status": headerData.lblStatus.toLowerCase()
        };
        var segmentData = this.view.segManageAllAssessment.data[0][1];
        var segmentAssignedData = [];
        for (var count = 0; count < segmentData.length; count++) {
            segmentAssignedData[count] = {
                "assessmentName": segmentData[count].lblAssessmentName,
                "assigneeName": segmentData[count].lblAssigneeName,
                "assigneeRole": segmentData[count].lblDuration,
                "details": segmentData[count].lblRole,
                "status": segmentData[count].lblStatus.text
            };
        }
        Utils.getReports(headerAssignedData, segmentAssignedData);
    }
}));
define("AdminFlow/frmViewAllAssessmentControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_a5c198ec78e9421a9a61b6db545e718c: function AS_Form_a5c198ec78e9421a9a61b6db545e718c(eventobject) {
        var self = this;
    }
});
define("AdminFlow/frmViewAllAssessmentController", ["AdminFlow/userfrmViewAllAssessmentController", "AdminFlow/frmViewAllAssessmentControllerActions"], function() {
    var controller = require("AdminFlow/userfrmViewAllAssessmentController");
    var controllerActions = ["AdminFlow/frmViewAllAssessmentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
