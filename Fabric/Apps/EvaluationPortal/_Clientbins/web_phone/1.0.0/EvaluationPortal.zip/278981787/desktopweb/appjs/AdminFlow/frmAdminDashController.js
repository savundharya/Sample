define("AdminFlow/userfrmAdminDashController", ["AppToolBox"], (AppToolBox) => ({
    onNavigate: function() {
        count1 = 0;
        this.view.preShow = this.preShow;
        this.view.postShow = this.postShow;
    },
    preShow: function() {
        kony.application.showLoadingScreen();
        let param = {};
        var scope = this;
        scope.view.onDeviceBack = function() {};
        this.view.flxVerticalChart.setVisibility(true);
        this.view.flxNoData.setVisibility(false);
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getAllApp(param);
        //     params = {
        //       FlowType : "AdminDash"};
        this.setRole();
        this.view.lblViewAll.onTouchStart = this.navToViewAll.bind(this);
        this.view.flxQuickLinks1.flxQuickLinks1.onClick = this.navToAssessmentManage;
        this.view.flxQuickLinks1.flxQuickLinks2.onClick = this.navToUserManagement;
        this.view.flxQuickLinks1.flxQuickLinks3.onClick = this.navToRoleManagement;
        //     var timeFrameMData=[];
        //     timeFrameMData.push(["lb1","Last 1 month"]);
        //     timeFrameMData.push(["lb2","Last 3 months"]);
        //     timeFrameMData.push(["lb3","Last 6 months"]);
        //     timeFrameMData.push(["lb4","Last 1 year"]);
        //     this.view.lstBoxTimeFrame.masterData=timeFrameMData;
        //     this.view.lstBoxTimeFrame.selectedKey="lb1";
        //     this.view.lstBoxTimeFrame.onSelection=this.fetchAppStatus;
        this.view.lstBoxRoles.onSelection = this.fetchAppStatus;
        this.view.appFooter.btnMapAssessment.onClick = () => {
                let ntf = new kony.mvc.Navigation("frmAdminMapAssessment");
                ntf.navigate();
            },
            kony.timer.schedule("timer1", scope.fetchAppStatus, 5, false);
    },
    setRole: function() {
        var UserRole = [];
        StatusArray = [];
        roleArray = [];
        barDetailArray = [];
        UserRole.push(["Placeholder", "All User"]);
        RoleResponse = AppToolBox.store.getItem("userRolesResponse");
        AppStatusResponse = AppToolBox.store.getItem("AppStatusResponse");
        for (var i = 0; i < RoleResponse.length; i++) {
            //     for(var i=0; i < RoleResponse.length; i++){
            roleArray[i] = RoleResponse[i].RoleName;
            if (!AppToolBox.util.isNil(RoleResponse) && !AppToolBox.util.isNil(RoleResponse[i]) && !AppToolBox.util.isNil(RoleResponse[i].RoleName) && RoleResponse[i].RoleName !== "Admin" && RoleResponse[i].RoleName !== "Evaluator") {
                if (!((RoleResponse[i].RoleName === "ADMIN") || (RoleResponse[i].RoleName === "EVALUATOR"))) {
                    var Role = ["lb" + i, RoleResponse[i].RoleName.replace("_", " ")];
                    UserRole.push(Role);
                }
            }
        }
        //   }
        this.view.lstBoxRoles.masterData = UserRole;
        UserRole.splice();
        this.view.lstBoxRoles.selectedKey = "Placeholder";
    },
    onHide: function() {
        this.view.flxVerticalChart.remove(this.view.multiseriesverticalbar);
    },
    navToViewAll: function() {
        AppToolBox.navigation.navigateTo("frmViewAllAssessment");
    },
    navToUserManagement: function() {
        let ntf = new kony.mvc.Navigation("frmUserManage");
        ntf.navigate();
    },
    navToRoleManagement: function() {
        let ntf = new kony.mvc.Navigation("frmRoleManagement");
        ntf.navigate("manageRole");
    },
    navToAssessmentManage: function() {
        let ntf = new kony.mvc.Navigation("frmManageAssessment");
        ntf.navigate();
    },
    replaceAll: function(string, search, replace) {
        return string.split(search).join(replace);
    },
    fetchAppStatus: function() {
        var widgetArray = [];
        widgetArray = this.view.flxVerticalChart.widgets();
        if (widgetArray.length > 1) {
            this.onHide();
        }
        statusClrCode = ["#3ea6f0", "#f3c11b", "#e05151", "#8a38f5", "#28c758", "#d20006"];
        kony.application.dismissLoadingScreen();
        selectedStatus = this.view.lstBoxRoles.selectedKeyValue;
        //     this.view.lstBoxTimeFrame.selectedKey="lb1";
        //     selectedKeyTimeFrame=this.view.lstBoxTimeFrame.selectedKeyValue;
        //     if(selectedKeyTimeFrame[1]==="Last 1 month")
        //     {dayDiff=30;}
        //     else if(selectedKeyTimeFrame[1]==="Last 3 months")
        //     {dayDiff=90;}
        //     else if(selectedKeyTimeFrame[1]==="Last 6 months")
        //     {dayDiff=180;}
        //     else
        //     {dayDiff=365;}
        chartArray = [];
        array3 = [];
        array = [];
        array4 = [];
        for (var t = 0; t < RoleResponse.length; t++) {
            for (var q = 0; q < AppStatusResponse.length; q++) {
                StatusArray[q] = AppStatusResponse[q].Status;
                cd = '' + t + q;
                chartArray[cd] = 0;
                //       window[ 'value' +i+j ] = 0;
            }
        }
        //     const m = new Map();
        var date = new Date();
        var current_date = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
        current_date = current_date.toString();
        len = AppToolBox.store.getItem("applicationData").length;
        if (AppToolBox.store.getItem("applicationData").length > 0) {
            for (var j = 0; j < len; j++) {
                var applicationStatus = AppToolBox.store.getItem("applicationData")[j].ApplicationStatus;
                var roleID = AppToolBox.store.getItem("applicationData")[j].RoleID;
                for (var a = 0; a < RoleResponse.length; a++) {
                    for (var b = 0; b < AppStatusResponse.length; b++) {
                        if ((roleID === roleArray[a]) && (applicationStatus === StatusArray[b])) {
                            size = '' + (RoleResponse.length) + (AppStatusResponse.length);
                            var abc = '' + a + b;
                            //               var timeFrame=AppToolBox.store.getItem("applicationData")[j].CreatedTs;
                            //               timeFrame=timeFrame.split(/,/);
                            //               timeFrame=timeFrame.toString();
                            //               timeFrame=timeFrame.split(" ")[0];
                            //               var diff =  Math.floor(( Date.parse(current_date) - Date.parse(timeFrame) ) / 86400000);
                            //               if(diff<=dayDiff){
                            //               for(var d=0;d<size;d++){
                            //                 var h=d.toString();
                            //                 if(h===abc){
                            chartArray[abc] = chartArray[abc] + 1;
                            //               }
                        }
                    }
                }
            }
            for (var g = 0; g < RoleResponse.length; g++) {
                m = new Map();
                compare = roleArray[g];
                if ((roleArray[g] === "ADMIN")) {} else if (roleArray[g] === "EVALUATOR") {} else {
                    var axisLabel = roleArray[g].toLowerCase().replace("_", " ");
                    labelCap = axisLabel.charAt(0).toUpperCase();
                    axisLabel = labelCap + axisLabel.slice(1);
                    m.set("label", axisLabel);
                    //           var label=roleArray[g].toLowerCase();
                    //         m.set("label",label.replace("_"," "));
                    for (var f = 0; f < AppStatusResponse.length; f++) {
                        var ab = '' + g + f;
                        const v = f + 1;
                        var u = ":";
                        m.set("value" + v, chartArray[ab]);
                        array4.push(chartArray[ab]);
                    }
                    //           const obj = Object.fromEntries(m);
                    obj = Object.fromEntries(m);
                    var jsonString = JSON.stringify(obj);
                    //           array4.push(jsonString);
                    //           array3.push(m);
                    //           array4.push(m);
                    array.push(obj);
                }
            }
            m = new Map();
            m.set("label", "Total");
            arrayTotal = [];
            for (var n = 0; n < AppStatusResponse.length; n++) {
                val1 = 0;
                total = [];
                value = [];
                for (l = 0; l < RoleResponse.length; l++) {
                    //           var nl=''+n+l;
                    var nl = '' + l + n;
                    //           var nl=''+n+l;
                    val1 = chartArray[nl] + val1;
                }
                l = 0;
                const num = Number(n) + 1;
                m.set("value" + num, val1);
                arrayTotal.push(val1);
                //         n=num;
                //         m.set("value"+num,40);
                //         var obj = Object.fromEntries(m);   
                //       }
            }
            const obj2 = Object.fromEntries(m);
            //       obj2 = Object.fromEntries(m);
            array.push(obj2);
            //       arrayTotal.push(obj);
            max1 = Math.max(...arrayTotal);
            //     }   
        }
        //     if(count1===1){
        //     this.showAllUserChart(max1);
        //     if(count1===1){
        //       this.view.flxVerticalChart.setVisibility(true);
        //       //       this.view.flxVerticalChart.setVisibility(false);
        //       //       this.showChart(max1);
        //       this.showAllUserChart(max1);
        //       count1=count1+1;
        //     }
        //     else{
        chartDataSize = array.length;
        selectedStatus[1] = selectedStatus[1].replace(" ", "_");
        for (var i = 0; i < RoleResponse.length; i++) {
            if (selectedStatus[1] === roleArray[i]) {
                //         const index=array4.findIndex(checkAge(roleArray[i]));
                //         const index=array4.findIndex(checkAge, array4);
                //         const index=array.indexOf(selectedStatus[1]);
                //         const count1=filter(array[index],"0"); 
                var length = roleArray[i].length;
                for (var k = 0; k < RoleResponse.length; k++) {
                    array3 = [];
                    array3.push(array[k]);
                    con = [];
                    con = array[k];
                    const obj = {...con
                    };
                    name3 = [];
                    name3 = Object.values(obj);
                    name3.splice(0, 1);
                    maxVal = Math.max(...name3);
                    const myJSON = JSON.stringify(array3);
                    var compareString = roleArray[i].toLowerCase().replace("_", " ");
                    var stringCaps = compareString.charAt(0).toUpperCase();
                    compareString = stringCaps + compareString.slice(1);
                    const result = myJSON.search(compareString);
                    //           const size=result+length;
                    result2 = myJSON.substr(result, length);
                    //           if(result2===roleArray[i].toLowerCase().replace("_"," ")){
                    if (result2 === compareString) {
                        //             this.createBarChart();
                        this.view.flxVerticalChart.setVisibility(true);
                        this.showUniqueChart(selectedStatus, maxVal);
                        //             break;
                    }
                }
            }
        }
        if (selectedStatus[1] === "All_User") {
            //         count1=0;
            count1 = count1 + 1;
            //         this.createBarChart();
            this.view.flxVerticalChart.setVisibility(true);
            //         this.view.flxVerticalChart.setVisibility(false);
            this.showAllUserChart(max1);
            //         this.showUniqueChart(selectedStatus,max1);
            //         this.showChart(max1);
        }
        //     }
    },
    showUniqueChart: function(selectedStatus, total) {
        var max = total;
        if (max === 0) {
            //       selectedStatus[1]="No Data Found";
            this.view.flxVerticalChart.setVisibility(false);
            this.view.flxNoData.setVisibility(true);
        } else {
            this.nextMethod(max, selectedStatus);
        }
    },
    nextMethod: function(max, selectedStatus) {
        kony.application.showLoadingScreen();
        this.view.flxVerticalChart.setVisibility(true);
        //     this.view.flxNoData.setVisibility(false);
        //     multiseriesverticalbar = new com.konymp.multiseriesverticalbar(
        //       {
        //         "autogrowMode": kony.flex.AUTOGROW_NONE,
        //         "clipBounds": true,
        //         "height": "98%",
        //         "id": "multiseriesverticalbar",
        //         "isVisible": true,
        //         "layoutType": kony.flex.FREE_FORM,
        //         "left": "0%",
        //         "masterType": constants.MASTER_TYPE_USERWIDGET,
        //         "skin": "CopyCopyslFbox1",
        //         "top": "0%",
        //         "width": "100%"
        //       }, {}, {});
        kony.application.dismissLoadingScreen();
        //     this.view.flxVerticalChart.add(multiseriesverticalbar);
        var maxvalue = max.toString();
        this.view.multiseriesverticalbar.seriesBarDistance = "120";
        this.view.multiseriesverticalbar.barWidth = "100";
        this.view.multiseriesverticalbar.xAxisTitle = "";
        this.view.multiseriesverticalbar.yAxisTitle = " ";
        this.view.multiseriesverticalbar.chartTitle = " ";
        this.view.multiseriesverticalbar.highValue = maxvalue;
        this.view.multiseriesverticalbar.enableGrid = true;
        var dataSet = array3;
        barDetailArray = [];
        for (var color = 0; color < AppStatusResponse.length; color++) {
            const colorMap = new Map();
            var bardata = '';
            bardata = "{color" + ":}";
            statusClrCode
            //       colorMap.set("color", this.generateRandomColor());
            colorMap.set("color", statusClrCode[color]);
            var legendName = StatusArray[color].toLowerCase();
            var legendCaps = legendName.charAt(0).toUpperCase();
            legendName = legendCaps + StatusArray[color].toLowerCase().slice(1);
            colorMap.set("legendName", legendName);
            const obj2 = Object.fromEntries(colorMap);
            barDetailArray.push(obj2);
        }
        var barDetails = barDetailArray;
        this.view.multiseriesverticalbar.createChart(dataSet, barDetails);
        this.view.multiseriesverticalbar.chartData = {
            "data": array3
        };
        this.view.multiseriesverticalbar.barDetails = {
            //       "data": barDetailArray};
            "data": barDetailArray
        };
    },
    generateRandomColor: function() {
        // let maxVal = 0xFFFFFF; // 16777215.
        let maxVal = 0x243123;
        let randomNumber = Math.random() * maxVal;
        randomNumber = Math.floor(randomNumber);
        randomNumber = randomNumber.toString(16);
        let randColor = randomNumber.padStart(6, 0);
        return `#${randColor. toUpperCase()}`
    },
    //   showChart: function(max1){
    //     kony.application.dismissLoadingScreen();
    //     const n= new Map();
    //     var maxvalue=max1.toString();
    //     //     n.set("data",array);
    // //     multiseriesverticalbar.seriesBarDistance
    //     multiseriesverticalbar.chartTitle="";
    //     multiseriesverticalbar.xAxisTitle=" ";
    //     multiseriesverticalbar.yAxisTitle="";
    //     multiseriesverticalbar.highValue=maxvalue;
    //     multiseriesverticalbar.enableGrid=true;
    //     //     if(selectedStatus==="All User"){
    //     multiseriesverticalbar.chartData = {"data":array};
    //     barDetailArray=[];
    //     for(var color=0;color<AppStatusResponse.length;color++){
    //       const colorMap=new Map();
    //       var bardata='';
    //       bardata="{color"+":}";
    // //       colorMap.set("color", this.generateRandomColor());
    //       colorMap.set("color", statusClrCode[color]);
    //       var legendName=StatusArray[color].toLowerCase();
    //       var legendCaps=legendName.charAt(0).toUpperCase();
    //       legendName=legendCaps+StatusArray[color].toLowerCase().slice(1);
    //       colorMap.set("legendName", legendName);
    //       const obj2 = Object.fromEntries(colorMap);
    //       barDetailArray.push(obj2);
    //     }
    //     multiseriesverticalbar.barDetails =
    //       {
    // //       "data": barDetailArray};
    //       "data": barDetailArray};
    //   },
    showAllUserChart: function(max1) {
        //     multiseriesverticalbar = new com.konymp.multiseriesverticalbar(
        //       {
        //         "autogrowMode": kony.flex.AUTOGROW_NONE,
        //         "clipBounds": true,
        //         "height": "98%",
        //         "id": "multiseriesverticalbar",
        //         "isVisible": true,
        //         "layoutType": kony.flex.FREE_FORM,
        //         "left": "0%",
        //         "masterType": constants.MASTER_TYPE_USERWIDGET,
        //         "skin": "CopyCopyslFbox1",
        //         "top": "0%",
        //         "width": "100%"
        //       }, {}, {});
        barDetailArray = [];
        var maxvalue = max1.toString();
        for (var color = 0; color < AppStatusResponse.length; color++) {
            const colorMap = new Map();
            var bardata = '';
            bardata = "{color" + ":}";
            //       colorMap.set("color", this.generateRandomColor());
            colorMap.set("color", statusClrCode[color]);
            var legendName = StatusArray[color].toLowerCase();
            var legendCaps = legendName.charAt(0).toUpperCase();
            legendName = legendCaps + StatusArray[color].toLowerCase().slice(1);
            colorMap.set("legendName", legendName);
            const obj2 = Object.fromEntries(colorMap);
            barDetailArray.push(obj2);
        }
        //     kony.application.dismissLoadingScreen();
        this.view.multiseriesverticalbar.seriesBarDistance = "32";
        this.view.multiseriesverticalbar.barWidth = "25";
        this.view.multiseriesverticalbar.chartTitle = "";
        this.view.multiseriesverticalbar.xAxisTitle = " ";
        this.view.multiseriesverticalbar.yAxisTitle = "";
        this.view.multiseriesverticalbar.highValue = maxvalue;
        this.view.multiseriesverticalbar.enableGrid = true;
        var dataSet = array;
        var barDetails = barDetailArray;
        this.view.multiseriesverticalbar.createChart(dataSet, barDetails);
        this.view.multiseriesverticalbar.chartData = {
            "data": dataSet
        };
        this.view.multiseriesverticalbar.barDetails = {
            //       "data": barDetailArray};
            "data": barDetailArray
        };
        kony.application.dismissLoadingScreen();
        //     this.view.flxVerticalChart.add(multiseriesverticalbar);
    },
    setAssessmentList: function(assessLen) {
        this.view.flxStatusFilterPopup.isVisible = false;
        this.view.flxRoleFilterPopup.isVisible = false;
        var beforeUpdate = AppToolBox.store.getItem("BeforeUpdateData");
        var data = AppToolBox.store.getItem("applicationData");
        var AssessmentList = [];
        var len = assessLen;
        var dataMap = {
            lblAssessmentName: "lblAssessmentName",
            lblDuration: "lblDuration",
            lblAssigneeName: "lblAssigneeName",
            lblRole: "lblRole",
            lblStatus: "lblStatus",
            flxStatus: "flxStatus",
            flxRole: "flxRole",
            imgSortRole: "imgSortRole",
            imgSortStatus: "imgSortStatus"
        };
        var userName;
        var appName;
        var assessID;
        this.view.segAssessmentList.widgetDataMap = dataMap;
        for (var i = 0; i < assessLen; i++) {
            userName = data[i].Name;
            var assessmentName = data[i].AssessmentName;
            var duration = data[i].Duration + " Days";
            var Role = data[i].Role;
            var statusskn = data[i].ApplicationStatus === "INITIATED" ? "sknlblFFFBFBbg7E6FFF" : data[i].ApplicationStatus === "INPROGRESS" ? "sknlblFFFBFBbgFFCC29" : data[i].ApplicationStatus === "OVERDUE" ? "sknlblFFFBFBbgF37070" : "sknlblFFFBFBbg4ECC48";
            var AssessLst = {
                lblAssessmentName: assessmentName,
                lblDuration: duration,
                lblAssigneeName: userName,
                lblRole: Role,
                lblStatus: {
                    text: data[i].ApplicationStatus.charAt(0) + data[i].ApplicationStatus.slice(1).toLowerCase(),
                    skin: statusskn
                }
            };
            AssessmentList.push(AssessLst);
        }
        var allUsers = [
            [{
                lblAssessmentName: "ASSESSMENT NAME",
                lblDuration: "DURATION",
                lblAssigneeName: "ASSIGNEE NAME",
                lblRole: "ROLE",
                lblStatus: "STATUS",
                imgSortStatus: {
                    isVisible: false
                },
                imgSortRole: {
                    isVisible: false
                }
            }, AssessmentList]
        ];
        this.view.segAssessmentList.setData(allUsers);
        //     kony.application.dismissLoadingScreen();
    },
}));
define("AdminFlow/frmAdminDashControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_fb2965d26f3745f2ab5bb84dd8a69da8: function AS_Form_fb2965d26f3745f2ab5bb84dd8a69da8(eventobject) {
        var self = this;
    }
});
define("AdminFlow/frmAdminDashController", ["AdminFlow/userfrmAdminDashController", "AdminFlow/frmAdminDashControllerActions"], function() {
    var controller = require("AdminFlow/userfrmAdminDashController");
    var controllerActions = ["AdminFlow/frmAdminDashControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
