define("UserManagement/userfrmUserDashboardController", ["animations", "AppToolBox"], (animations, AppToolBox) => ({
    onNavigate: function() {
        this.view.preShow = this.preShow;
    },
    preShow: function() {
        this.view.lblAssessmentList.text = "My Current Assessment";
        this.currentTabAssess();
        this.view.txtSearch.text = " ";
        this.view.txtSearchB.placeholder.text = "Search Assessment";
        this.view.imgSearchB.onTouchEnd = this.onSearch;
        this.view.txtSearchB.onDone = this.onSearch;
        this.view.btnSearch.onClick = this.onSearch;
        this.view.tabs.flxCurrentbutton.onClick = this.onCheckBtn.bind(this, this.view.tabs.flxCurrentbutton, this.view.tabs.flxMandatorybutton, this.view.tabs.btnCompletedbutton);
        this.view.tabs.flxMandatorybutton.onClick = this.onCheckBtn.bind(this, this.view.tabs.flxMandatorybutton, this.view.tabs.flxCurrentbutton, this.view.tabs.btnCompletedbutton);
        this.view.tabs.btnCompletedbutton.onClick = this.onCheckBtn.bind(this, this.view.tabs.btnCompletedbutton, this.view.tabs.flxMandatorybutton, this.view.tabs.flxCurrentbutton);
        this.view.segTypeOfAssess.onRowClick = this.nav;
        this.view.tabs.flxCurrentbutton.isVisible = false;
        this.view.tabs.btnCompletedbutton.isVisible = true;
        this.view.tabs.flxMandatorybutton.isVisible = true;
        let userDetails = AppToolBox.store.getItem("userDetails");
        //this.view.flxMiddleErrorMessage.isVisible = false;
        this.view.onDeviceBack = function() {};
    },
    segContent: function(currBtnObj) {
        if (currBtnObj === this.view.tabs.flxCurrentbutton) {
            this.view.lblAssessmentList.text = "My Current Assessment";
            this.currentTabAssess();
        } else if (currBtnObj === this.view.tabs.btnCompletedbutton) {
            this.view.lblAssessmentList.text = "My Completed Assessment";
            this.completedTabAssess();
        } else if (currBtnObj === this.view.tabs.flxMandatorybutton) {
            this.view.lblAssessmentList.text = "My Mandatory Assessment";
            this.fetchAssessment();
        }
    },
    currentTabAssess: function() {
        kony.application.showLoadingScreen();
        let userDetails = AppToolBox.store.getItem("userDetails");
        let params = {
            "UserID": userDetails.ID,
            "tabClick": "Current"
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getMyAssessment(params);
    },
    completedTabAssess: function() {
        kony.application.showLoadingScreen();
        let userDetails = AppToolBox.store.getItem("userDetails");
        let params = {
            "UserID": userDetails.ID,
            "tabClick": "Completed"
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getMyAssessment(params);
    },
    setLabel: function(params) {
        this.view.flxSegCurrent.isVisible = false;
        if (params.tabClick === "Current") {
            this.view.lblNoAssessment.text = "No Current Assessment";
        } else if (params.tabClick === "Mandatory") {
            this.view.lblNoAssessment.text = "No Mandatory Assessment";
        } else if (params.tabClick === "Completed") {
            this.view.lblNoAssessment.text = "No Completed Assessment";
        }
        this.view.lblNoAssessment.isVisible = true;
        kony.application.dismissLoadingScreen();
    },
    onSearch: function() {
        kony.application.showLoadingScreen();
        let userDetails = AppToolBox.store.getItem("userDetails");
        var filter = "UserID eq " + userDetails.ID;
        let params = {
            "UserID": userDetails.ID,
            "tabClick": "Mandatory",
            "searchkey": this.view.txtSearchB.text
        };
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.getMyAssessment(params);
    },
    SearchRes: function(params, res) {
        var str = params.searchkey;
        var strArray = res;
        for (var i = 0; i < res.ApplicationList.length; i++) {
            if (res.ApplicationList[i].AssessmentName.toUpperCase() === str.trim().toUpperCase()) {
                this.view.lblNoSearch.isVisible = false;
                this.navToAssessment(res.ApplicationList[i]);
                break;
            } else {
                this.view.lblNoSearch.isVisible = true;
                this.view.txtSearchB.text = " ";
            }
        }
        kony.application.dismissLoadingScreen();
    },
    navToAssessment: function(resp) {
        let nav = new kony.mvc.Navigation("frmAssessment");
        let selectedSegData = {};
        selectedSegData.assessmentID = resp.AssessmentID;
        selectedSegData.assessmentInstructions = resp.AssessmentInstruction;
        selectedSegData.assessmentName = resp.AssessmentName;
        selectedSegData.duration = resp.Duration;
        selectedSegData.applicationID = resp.ApplicationID;
        selectedSegData.status = this.getStatus(resp.AppStatus);
        AppToolBox.store.setItem("segData", selectedSegData);
        nav.navigate();
    },
    onCheckBtn: function(currBtnObj, unselectedBtnObj1, unselectedBtnObj2) {
        currBtnObj.isVisible = false;
        unselectedBtnObj1.isVisible = true;
        unselectedBtnObj2.isVisible = true;
        this.segContent(currBtnObj);
    },
    nav: function() {
        let nav = new kony.mvc.Navigation("frmAssessment");
        var selectedSegData = this.view.segTypeOfAssess.selectedRowItems[0];
        AppToolBox.store.setItem("segData", selectedSegData);
        nav.navigate();
    },
    fetchAssessment: function() {
        kony.application.showLoadingScreen();
        let userDetails = AppToolBox.store.getItem("userDetails");
        var params = {
            "UserID": userDetails.ID,
            "tabClick": "Mandatory"
        };
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.getMyAssessment(params);
    },
    setAssessmentList: function(response, params) {
        var self = this;
        var AssessmentList = [];
        var dataMap = {
            lblAssessmentName: "lblAssessmentName",
            lblDuration: "lblDuration",
            lblAssigneeName: "lblAssigneeName",
            lblRole: "lblRole",
            lblStatus: "lblStatus",
            flxStatus: "flxStatus",
            flxRole: "flxRole",
            imgSortRole: "imgSortRole",
            imgSortStatus: "imgSortStatus",
            flxAssigneeName: "flxAssigneeName",
            flxAssessmentName: "flxAssessmentName",
            flxDuration: "flxDuration"
        };
        var EvaluatorName;
        var thirdHeader = params.tabClick === "Current" ? "DUE DATE" : params.tabClick === "Mandatory" ? "STATUS" : params.tabClick === "Completed" ? "COMPLETED DATE" : " ";
        var AssigneeNamevisiblity = params.tabClick === "Current" ? true : params.tabClick === "Mandatory" ? false : params.tabClick === "Completed" ? true : " ";
        var Statusvisiblity = params.tabClick === "Current" ? false : params.tabClick === "Mandatory" ? true : params.tabClick === "Completed" ? false : " ";
        this.view.segTypeOfAssess.widgetDataMap = dataMap;
        if (!AppToolBox.util.isNil(response) && !AppToolBox.util.isNil(response.ApplicationList)) {
            for (var i = response.ApplicationList.length - 1; i >= 0; i--) {
                EvaluatorName = response.ApplicationList[i].Name;
                var assessmentName = response.ApplicationList[i].AssessmentName;
                var duration = this.setDuration(response.ApplicationList[i]);
                var status = self.getStatus(response.ApplicationList[i].AppStatus);
                var statusskn = response.ApplicationList[i].AppStatus === "STATUS001" ? "sknlblFFFBFBbg7E6FFF" : response.ApplicationList[i].AppStatus === "STATUS002" ? "sknlblFFFBFBbgFFCC29" : response.ApplicationList[i].AppStatus === "STATUS003" || response.ApplicationList[i].AppStatus === "STATUS006" ? "sknlblFFFBFBbgF37070" : "sknlblFFFBFBbg4ECC48";
                var AssessLst = {
                    lblAssessmentName: {
                        text: assessmentName,
                        width: "30%"
                    },
                    lblDuration: {
                        text: EvaluatorName,
                        width: "30%"
                    },
                    lblAssigneeName: {
                        text: duration,
                        isVisible: AssigneeNamevisiblity,
                        width: "30%"
                    },
                    lblRole: {
                        isVisible: false,
                        width: "30%"
                    },
                    lblStatus: {
                        text: status,
                        skin: statusskn,
                        isVisible: Statusvisiblity,
                        width: "20%"
                    },
                    assessmentName: assessmentName,
                    assessmentInstructions: response.ApplicationList[i].AssessmentInstruction,
                    assessmentID: response.ApplicationList[i].AssessmentID,
                    duration: response.ApplicationList[i].Duration,
                    applicationID: response.ApplicationList[i].ApplicationID,
                    status: status
                };
                AssessmentList.push(AssessLst);
            }
            var allUsers = [];
            if (params.tabClick === "Current") {
                allUsers = [
                    [{
                        lblAssessmentName: "ASSESSMENT NAME",
                        lblDuration: "EVALUATOR NAME",
                        lblAssigneeName: thirdHeader,
                        lblStatus: {
                            isVisible: false
                        },
                        imgSortStatus: {
                            isVisible: false
                        },
                        imgSortRole: {
                            isVisible: false
                        },
                        flxRole: {
                            isVisible: false,
                            width: "30%"
                        },
                        flxStatus: {
                            isVisible: false,
                            width: "30%"
                        },
                        flxAssigneeName: {
                            isVisible: true,
                            width: "30%"
                        },
                        flxAssessmentName: {
                            width: "30%"
                        },
                        flxDuration: {
                            width: "30%"
                        }
                    }, AssessmentList]
                ];
            } else if (params.tabClick === "Mandatory") {
                allUsers = [
                    [{
                        lblAssessmentName: "ASSESSMENT NAME",
                        lblDuration: "EVALUATOR NAME",
                        lblAssigneeName: {
                            isVisible: false
                        },
                        lblStatus: {
                            text: thirdHeader,
                            isVisible: true
                        },
                        imgSortStatus: {
                            isVisible: false
                        },
                        imgSortRole: {
                            isVisible: false
                        },
                        flxRole: {
                            isVisible: false,
                            width: "30%"
                        },
                        flxStatus: {
                            isVisible: true,
                            width: "30%"
                        },
                        flxAssigneeName: {
                            isVisible: false,
                            width: "30%"
                        },
                        flxAssessmentName: {
                            width: "30%"
                        },
                        flxDuration: {
                            width: "30%"
                        }
                    }, AssessmentList]
                ];
            } else {
                allUsers = [
                    [{
                        lblAssessmentName: "ASSESSMENT NAME",
                        lblDuration: "EVALUATOR NAME",
                        lblAssigneeName: thirdHeader,
                        lblStatus: {
                            isVisible: false
                        },
                        imgSortStatus: {
                            isVisible: false
                        },
                        imgSortRole: {
                            isVisible: false
                        },
                        flxRole: {
                            isVisible: false,
                            width: "30%"
                        },
                        flxStatus: {
                            isVisible: false,
                            width: "30%"
                        },
                        flxAssigneeName: {
                            isVisible: true,
                            width: "30%"
                        },
                        flxAssessmentName: {
                            width: "30%"
                        },
                        flxDuration: {
                            width: "30%"
                        }
                    }, AssessmentList]
                ];
            }
            this.view.flxSegCurrent.isVisible = true;
            this.view.lblNoAssessment.isVisible = false;
            this.view.segTypeOfAssess.setData(allUsers);
            kony.application.dismissLoadingScreen();
        } else {
            this.setLabel(params);
        }
    },
    getStatus: function(status) {
        const appStatus = AppToolBox.store.getItem("AppStatusResponse");
        return appStatus.find(el => el.ID === status).Status;
    },
    formatDate: function(date) {
        const [year, month, day] = date.split('-');
        const result = [day, month, year].join('/');
        return result;
    },
    setDuration: function(resp) {
        var appDetails = resp;
        var date = resp.date;
        if (appDetails.AppStatus === "STATUS002") {
            var RemainDays = appDetails.Duration - this.diffDays(date);
            return Math.abs(RemainDays) + " days";
        } else if (appDetails.AppStatus === "STATUS004" || appDetails.AppStatus === "STATUS005") {
            return this.formatDate(appDetails.lastUpdate.slice(0, 10));
        } else if (appDetails.AppStatus === "STATUS001") {
            return appDetails.Duration + " days";
        } else if (appDetails.AppStatus === "STATUS003") {
            var OverDue = appDetails.Duration - this.diffDays(date);
            return Math.abs(OverDue) + " days";
        }
    },
    diffDays: function(date2) {
        var dt1 = new Date(date2);
        var dt2 = new Date();
        var diff = Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24));
        return diff;
    },
    displayMsg: function(Msg) {
        var scope = this;
        this.view.msgContainer.setImageSuccess();
        this.view.msgContainer.setMessage(Msg);
        this.view.msgContainer.setCancelSuccess();
        this.view.msgContainer.imgCancel.onTouchStart = function() {
            scope.view.flxMiddleErrorMessage.isVisible = false;
        };
        this.view.flxMiddleErrorMessage.isVisible = true;
        this.view.flxFooter.top = "12%";
    },
    displayErrorMsg: function(errMsg) {
        var scope = this;
        this.view.msgContainer.setImageWarning();
        this.view.msgContainer.setMessage(errMsg);
        this.view.msgContainer.setCancelWarn();
        this.view.msgContainer.imgCancel.onTouchStart = function() {
            scope.view.flxMiddleErrorMessage.isVisible = false;
        };
        this.view.flxMiddleErrorMessage.isVisible = true;
        this.view.flxFooter.top = "12%";
    }
}));
define("UserManagement/frmUserDashboardControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("UserManagement/frmUserDashboardController", ["UserManagement/userfrmUserDashboardController", "UserManagement/frmUserDashboardControllerActions"], function() {
    var controller = require("UserManagement/userfrmUserDashboardController");
    var controllerActions = ["UserManagement/frmUserDashboardControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
