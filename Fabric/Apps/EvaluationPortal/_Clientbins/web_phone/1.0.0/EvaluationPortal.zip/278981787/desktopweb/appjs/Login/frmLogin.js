define("Login/frmLogin", function() {
    return function(controller) {
        function addWidgetsfrmLogin() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxMainb",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "responsiveConfig": {
                    "offset": {
                        "640": 0,
                        "1024": 0,
                        "1366": 0
                    },
                    "span": {
                        "640": 6,
                        "1024": 4,
                        "1366": 3
                    }
                },
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxLoginMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLoginMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "sknLoginMainBack",
                "top": "0dp",
                "width": "100%",
                "zIndex": kony.flex.ZINDEX_AUTO,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLoginMain.setDefaultUnit(kony.flex.DP);
            var FlxOverlay = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "FlxOverlay",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxOverlay",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            FlxOverlay.setDefaultUnit(kony.flex.DP);
            FlxOverlay.add();
            var flxLeft = new kony.ui.FlexContainer({
                "centerY": "48.08%",
                "clipBounds": false,
                "height": "370dp",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-37%",
                "isModalContainer": false,
                "skin": "sknLeftLogin",
                "width": "493dp",
                "zIndex": 3,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxMainLogin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "343dp",
                "id": "flxMainLogin",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxmainLoginpage",
                "top": 0,
                "width": "493dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainLogin.setDefaultUnit(kony.flex.DP);
            var lblLoginErr = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblLoginErr",
                "isVisible": false,
                "skin": "sknlblLatoReg12pxRed",
                "text": "Invalid Credentials",
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLblLogin = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxLblLogin",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblLogin.setDefaultUnit(kony.flex.DP);
            var lblLogin = new kony.ui.Label({
                "centerX": "50.00%",
                "id": "lblLogin",
                "isVisible": true,
                "left": "186dp",
                "right": "136dp",
                "skin": "sknLoginLable",
                "text": "LOGIN",
                "top": "9dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblLogin.add(lblLogin);
            var flxUserName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxUserName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "sknflxUser",
                "top": "31dp",
                "width": "400dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserName.setDefaultUnit(kony.flex.DP);
            var FlxContact = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "FlxContact",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "sknflxContactIcon",
                "top": "-1dp",
                "width": "42dp",
                "zIndex": 5,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            FlxContact.setDefaultUnit(kony.flex.DP);
            var imgContactIcon = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgContactIcon",
                "isVisible": true,
                "left": "2dp",
                "skin": "slImage",
                "src": "vector.png",
                "top": "5dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxContact.add(imgContactIcon);
            var FlexContainer0c0a89e36b01448 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "47dp",
                "id": "FlexContainer0c0a89e36b01448",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-30dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0b2cf1d7ec1fa4f",
                "top": "-24dp",
                "width": "49dp",
                "zIndex": 4,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContainer0c0a89e36b01448.setDefaultUnit(kony.flex.DP);
            var ImgContact = new kony.ui.Image2({
                "height": "47dp",
                "id": "ImgContact",
                "isVisible": true,
                "left": "-3dp",
                "skin": "CopyslImage0jaf6d7ef7b634e",
                "src": "vector.png",
                "top": "0dp",
                "width": "50dp",
                "zIndex": 3
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContainer0c0a89e36b01448.add(ImgContact);
            var FlxBackwhite = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "FlxBackwhite",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "sknblack",
                "top": "-1dp",
                "width": "90.47%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            FlxBackwhite.setDefaultUnit(kony.flex.DP);
            var txtboxUserName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "49dp",
                "id": "txtboxUserName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.30%",
                "placeholder": "Please enter the username",
                "secureTextEntry": false,
                "skin": "skntextbackround",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-1dp",
                "width": "99%",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            FlxBackwhite.add(txtboxUserName);
            flxUserName.add(FlxContact, FlexContainer0c0a89e36b01448, FlxBackwhite);
            var flxPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "sknflxUser",
                "top": "20dp",
                "width": "400dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPassword.setDefaultUnit(kony.flex.DP);
            var flxPassIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxPassIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "sknflxContactIcon",
                "top": "-1dp",
                "width": "42dp",
                "zIndex": 5,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPassIcon.setDefaultUnit(kony.flex.DP);
            var ImgPassIcon = new kony.ui.Image2({
                "height": "40dp",
                "id": "ImgPassIcon",
                "isVisible": true,
                "left": "3dp",
                "skin": "slImage",
                "src": "vector__1_.png",
                "top": "4dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPassIcon.add(ImgPassIcon);
            var FlxPasswordtype = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "FlxPasswordtype",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "sknblack",
                "top": "-1dp",
                "width": "90.47%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            FlxPasswordtype.setDefaultUnit(kony.flex.DP);
            var txtboxPasswd = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "49dp",
                "id": "txtboxPasswd",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.30%",
                "placeholder": "Please enter the password",
                "secureTextEntry": true,
                "skin": "sknBoxLato",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-1dp",
                "width": "99.00%",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            var lblResetPassword = new kony.ui.Label({
                "id": "lblResetPassword",
                "isVisible": false,
                "left": "-40dp",
                "skin": "CopydefLabel0dcd139d2b49743",
                "text": "Forget Password?",
                "top": "100dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxPasswordtype.add(txtboxPasswd, lblResetPassword);
            flxPassword.add(flxPassIcon, FlxPasswordtype);
            var flxButton = new kony.ui.FlexContainer({
                "bottom": "30dp",
                "clipBounds": false,
                "height": "50dp",
                "id": "flxButton",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "32dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxButton.setDefaultUnit(kony.flex.DP);
            var btnLogin = new kony.ui.Button({
                "bottom": "46dp",
                "centerX": "75.16%",
                "focusSkin": "sknBtnLatoRegPurple16px",
                "height": "42dp",
                "id": "btnLogin",
                "isVisible": true,
                "left": "314dp",
                "skin": "sknBtnLatoRegPurple16px",
                "text": "LOG IN",
                "top": "6dp",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnResetPassword = new kony.ui.Button({
                "focusSkin": "CopydefBtnNormal0b72d97d4f39b40",
                "height": "29dp",
                "id": "btnResetPassword",
                "isVisible": true,
                "left": "38dp",
                "skin": "CopydefBtnNormal0b72d97d4f39b40",
                "text": "Reset Password",
                "top": "12dp",
                "width": "120dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxButton.add(btnLogin, btnResetPassword);
            flxMainLogin.add(lblLoginErr, flxLblLogin, flxUserName, flxPassword, flxButton);
            var flxResetPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "135.14%",
                "id": "flxResetPassword",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxmainLoginpage",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetPassword.setDefaultUnit(kony.flex.DP);
            var lblResetPasswordErr = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblResetPasswordErr",
                "isVisible": false,
                "skin": "sknlblLatoReg12pxRed",
                "text": "Invalid Credentials",
                "top": "3%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLblResetPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLblResetPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLblResetPassword.setDefaultUnit(kony.flex.DP);
            var lblResetPasswordTitle = new kony.ui.Label({
                "centerX": "50%",
                "id": "lblResetPasswordTitle",
                "isVisible": true,
                "left": "30dp",
                "skin": "sknLoginLable",
                "text": "Reset Password",
                "top": -1,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxLblResetPassword.add(lblResetPasswordTitle);
            var flxResetUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxResetUser",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "sknflxUser",
                "top": "23dp",
                "width": "400dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUser.setDefaultUnit(kony.flex.DP);
            var flxResetUserIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxResetUserIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "sknflxContactIcon",
                "top": "-1dp",
                "width": "42dp",
                "zIndex": 5,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUserIcon.setDefaultUnit(kony.flex.DP);
            var imgResetUserIcon = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgResetUserIcon",
                "isVisible": true,
                "left": "2dp",
                "skin": "slImage",
                "src": "vector.png",
                "top": "5dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResetUserIcon.add(imgResetUserIcon);
            var flxUserNameBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxUserNameBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "sknblack",
                "top": "-1dp",
                "width": "90.47%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserNameBack.setDefaultUnit(kony.flex.DP);
            var txtUserName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "49dp",
                "id": "txtUserName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.30%",
                "placeholder": "Please enter the username",
                "secureTextEntry": false,
                "skin": "skntextbackround",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-1dp",
                "width": "99%",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxUserNameBack.add(txtUserName);
            flxResetUser.add(flxResetUserIcon, flxUserNameBack);
            var flxResetUserName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxResetUserName",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxResetUserName.setDefaultUnit(kony.flex.DP);
            var txtBoxResetUserName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtBoxResetUserName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "7%",
                "placeholder": "Username",
                "secureTextEntry": false,
                "skin": "sknBoxLato",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0dp",
                "width": "85%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxResetUserName.add(txtBoxResetUserName);
            var flxPasswordOld = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPasswordOld",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "sknflxUser",
                "top": "20dp",
                "width": "400dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPasswordOld.setDefaultUnit(kony.flex.DP);
            var flxPasswordIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxPasswordIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "sknflxContactIcon",
                "top": "-1dp",
                "width": "42dp",
                "zIndex": 5,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPasswordIcon.setDefaultUnit(kony.flex.DP);
            var imgPasswordIcon = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgPasswordIcon",
                "isVisible": true,
                "left": "3dp",
                "skin": "slImage",
                "src": "vector__1_.png",
                "top": "4dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPasswordIcon.add(imgPasswordIcon);
            var flxPasswordBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxPasswordBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "sknblack",
                "top": "-1dp",
                "width": "90.47%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPasswordBack.setDefaultUnit(kony.flex.DP);
            var txtOldPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "49dp",
                "id": "txtOldPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.30%",
                "placeholder": "Please enter your old Password",
                "secureTextEntry": true,
                "skin": "sknBoxLato",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-1dp",
                "width": "99.00%",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxPasswordBack.add(txtOldPassword);
            flxPasswordOld.add(flxPasswordIcon, flxPasswordBack);
            var flxOldPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxOldPassword",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxOldPassword.setDefaultUnit(kony.flex.DP);
            var txtBoxOldPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtBoxOldPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "7%",
                "placeholder": "Old Password",
                "secureTextEntry": true,
                "skin": "sknBoxLato",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-7dp",
                "width": "85%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxOldPassword.add(txtBoxOldPassword);
            var flxPasswordNew = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxPasswordNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "sknflxUser",
                "top": "20dp",
                "width": "400dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPasswordNew.setDefaultUnit(kony.flex.DP);
            var flxNewPasswordIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxNewPasswordIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "sknflxContactIcon",
                "top": "-1dp",
                "width": "42dp",
                "zIndex": 5,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewPasswordIcon.setDefaultUnit(kony.flex.DP);
            var imgNewPasswordIcon = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgNewPasswordIcon",
                "isVisible": true,
                "left": "3dp",
                "skin": "slImage",
                "src": "vector__1_.png",
                "top": "4dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNewPasswordIcon.add(imgNewPasswordIcon);
            var flxNewPasswordBack = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxNewPasswordBack",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "sknblack",
                "top": "-1dp",
                "width": "90.47%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewPasswordBack.setDefaultUnit(kony.flex.DP);
            var txtNewPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "49dp",
                "id": "txtNewPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.30%",
                "placeholder": "Please enter your new Password",
                "secureTextEntry": true,
                "skin": "sknBoxLato",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-1dp",
                "width": "99.00%",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxNewPasswordBack.add(txtNewPassword);
            flxPasswordNew.add(flxNewPasswordIcon, flxNewPasswordBack);
            var flxNewPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNewPassword",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNewPassword.setDefaultUnit(kony.flex.DP);
            var txtBoxNewPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtBoxNewPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "7%",
                "placeholder": "New Password",
                "secureTextEntry": true,
                "skin": "sknBoxLato",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-6dp",
                "width": "85%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            var flxInfo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxInfo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "93%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5dp",
                "width": "25dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxInfo.setDefaultUnit(kony.flex.DP);
            var imgInfo = new kony.ui.Image2({
                "height": "20dp",
                "id": "imgInfo",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "infoicon.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxInfo.add(imgInfo);
            flxNewPassword.add(txtBoxNewPassword, flxInfo);
            var flxConfirmPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxConfirmPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "46dp",
                "isModalContainer": false,
                "skin": "sknflxUser",
                "top": "20dp",
                "width": "400dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmPassword.setDefaultUnit(kony.flex.DP);
            var flxConfirmPasswordIcon = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxConfirmPasswordIcon",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "sknflxContactIcon",
                "top": "-1dp",
                "width": "42dp",
                "zIndex": 5,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmPasswordIcon.setDefaultUnit(kony.flex.DP);
            var imgConfirmPasswordIcon = new kony.ui.Image2({
                "height": "40dp",
                "id": "imgConfirmPasswordIcon",
                "isVisible": true,
                "left": "3dp",
                "skin": "slImage",
                "src": "vector__1_.png",
                "top": "4dp",
                "width": "30dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxConfirmPasswordIcon.add(imgConfirmPasswordIcon);
            var flxConfirmPasswordback = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "49dp",
                "id": "flxConfirmPasswordback",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "39dp",
                "isModalContainer": false,
                "skin": "sknblack",
                "top": "-1dp",
                "width": "90.47%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmPasswordback.setDefaultUnit(kony.flex.DP);
            var txtConfirmPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "49dp",
                "id": "txtConfirmPassword",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.30%",
                "placeholder": "Confirm New Password",
                "secureTextEntry": true,
                "skin": "sknBoxLato",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-1dp",
                "width": "99.00%",
                "zIndex": 2
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxConfirmPasswordback.add(txtConfirmPassword);
            flxConfirmPassword.add(flxConfirmPasswordIcon, flxConfirmPasswordback);
            var flxConfirmNewPassword = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxConfirmNewPassword",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxConfirmNewPassword.setDefaultUnit(kony.flex.DP);
            var txtBoxConfirmNewPassword = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "40dp",
                "id": "txtBoxConfirmNewPassword",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "7%",
                "placeholder": "Confirm New Password",
                "secureTextEntry": true,
                "skin": "sknTxtBoxLatoReg12pxDisabled",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "-4dp",
                "width": "85%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxConfirmNewPassword.add(txtBoxConfirmNewPassword);
            var flxBtnReset = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "50dp",
                "id": "flxBtnReset",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBtnReset.setDefaultUnit(kony.flex.DP);
            var btnReset = new kony.ui.Button({
                "centerX": "49%",
                "focusSkin": "sknBtnLatoRegPurple16px",
                "height": "50dp",
                "id": "btnReset",
                "isVisible": true,
                "left": "0",
                "skin": "sknBtnLatoReg16pxPurpleDisabled",
                "text": "RESET PASSWORD",
                "top": "0dp",
                "width": "70%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxBtnReset.add(btnReset);
            var lblCancelReset = new kony.ui.Label({
                "centerX": "48%",
                "id": "lblCancelReset",
                "isVisible": false,
                "left": "0",
                "skin": "sknlblLatoBold14pxPurple",
                "text": "Cancel",
                "top": "3%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancelReset = new kony.ui.Button({
                "centerX": "48%",
                "focusSkin": "CopydefBtnNormal0b72d97d4f39b40",
                "id": "btnCancelReset",
                "isVisible": true,
                "left": 0,
                "skin": "CopydefBtnNormal0b72d97d4f39b40",
                "text": "Cancel",
                "top": "3%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxResetPassword.add(lblResetPasswordErr, flxLblResetPassword, flxResetUser, flxResetUserName, flxPasswordOld, flxOldPassword, flxPasswordNew, flxNewPassword, flxConfirmPassword, flxConfirmNewPassword, flxBtnReset, lblCancelReset, btnCancelReset);
            flxLeft.add(flxMainLogin, flxResetPassword);
            var flxRightMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerY": "48%",
                "clipBounds": true,
                "id": "flxRightMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "10%",
                "isModalContainer": false,
                "skin": "CopyslFbox0ca6f392d6e7a40",
                "width": "45%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightMain.setDefaultUnit(kony.flex.DP);
            var LblLine1 = new kony.ui.Label({
                "id": "LblLine1",
                "isVisible": true,
                "left": "60dp",
                "skin": "SknLableLeft",
                "text": "Welcome to",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var LblTemenosCOE = new kony.ui.Label({
                "id": "LblTemenosCOE",
                "isVisible": true,
                "left": "290dp",
                "skin": "SknLableleftOrange",
                "text": " Temenos COE",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblWelMsg = new kony.ui.Label({
                "id": "lblWelMsg",
                "isVisible": false,
                "left": 5,
                "skin": "sknlblLatoBold40pxPurple",
                "i18n_text": "kony.i18n.getLocalizedString(\"i18n.common.title\")",
                "top": 0,
                "width": "93.41%",
                "blur": {
                    "enabled": false,
                    "value": 0
                }
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var LblLine2 = new kony.ui.Label({
                "id": "LblLine2",
                "isVisible": true,
                "left": "-77dp",
                "skin": "SknLableLeft",
                "text": "     a unit of Banking and Financial ",
                "top": "70dp",
                "width": "710dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var LblLine3 = new kony.ui.Label({
                "id": "LblLine3",
                "isVisible": true,
                "left": "65dp",
                "skin": "SknLableLeft",
                "text": "Services Business Unit at ",
                "top": "140dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblAspiresystems = new kony.ui.Label({
                "id": "lblAspiresystems",
                "isVisible": true,
                "left": "150dp",
                "skin": "SknLableleftOrange",
                "text": "Aspire Systems",
                "top": "210dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRightMain.add(LblLine1, LblTemenosCOE, lblWelMsg, LblLine2, LblLine3, lblAspiresystems);
            var FlxHeadLogo = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100dp",
                "id": "FlxHeadLogo",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "CopyslFbox0g371de6698334b",
                "top": "0dp",
                "width": "50%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            FlxHeadLogo.setDefaultUnit(kony.flex.DP);
            var Image0bd41ed237fea40 = new kony.ui.Image2({
                "height": "45dp",
                "id": "Image0bd41ed237fea40",
                "isVisible": true,
                "left": "64dp",
                "skin": "slImage",
                "src": "aspire_logo_second_1.png",
                "top": "32dp",
                "width": "230dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlxHeadLogo.add(Image0bd41ed237fea40);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "83.50%",
                "isModalContainer": false,
                "skin": "sknLoginPopup",
                "top": "290dp",
                "width": "180dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var lblPopup = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblPopup",
                "isVisible": true,
                "left": "5%",
                "skin": "sknLblLatoReg12pxPurple",
                "text": "Password Length : 8 to 16 characters maximum (Should contain atleast 1 Uppercase letters: A-Z, 1 Digit: 0-9 and  1 special character)",
                "top": "0",
                "width": "90%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPopup.add(lblPopup);
            var imgLoginBackground = new kony.ui.Image2({
                "zoomEnabled": false,
                "height": "100%",
                "id": "imgLoginBackground",
                "isVisible": false,
                "left": "0",
                "skin": "slImage",
                "src": "bfs_banner_1.png",
                "top": "3dp",
                "width": "100%",
                "blur": {
                    "enabled": true,
                    "value": 1
                }
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "20dp",
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "9dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var FooterText = new Footertext.FooterText({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "id": "FooterText",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0f43ddcf6492c41",
                "top": "-4dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "FooterText": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerX": "50%",
                        "left": "0dp",
                        "top": "-4dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(FooterText);
            flxLoginMain.add(FlxOverlay, flxLeft, flxRightMain, FlxHeadLogo, flxPopup, imgLoginBackground, flxFooter);
            flxMain.add(flxLoginMain);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
                "640": {
                    "flxLoginMain": {
                        "segmentProps": []
                    },
                    "flxLeft": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "segmentProps": []
                    },
                    "flxMainLogin": {
                        "centerX": {
                            "type": "string",
                            "value": "50%"
                        },
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxLblLogin": {
                        "segmentProps": []
                    },
                    "flxUserName": {
                        "segmentProps": []
                    },
                    "flxPassword": {
                        "segmentProps": []
                    },
                    "flxButton": {
                        "bottom": {
                            "type": "string",
                            "value": "30dp"
                        },
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "segmentProps": []
                    },
                    "flxLblResetPassword": {
                        "segmentProps": []
                    },
                    "flxResetUser": {
                        "segmentProps": []
                    },
                    "flxResetUserName": {
                        "segmentProps": []
                    },
                    "flxPasswordOld": {
                        "segmentProps": []
                    },
                    "flxOldPassword": {
                        "segmentProps": []
                    },
                    "flxPasswordNew": {
                        "segmentProps": []
                    },
                    "flxNewPassword": {
                        "segmentProps": []
                    },
                    "flxConfirmPassword": {
                        "segmentProps": []
                    },
                    "flxConfirmNewPassword": {
                        "segmentProps": []
                    },
                    "flxBtnReset": {
                        "height": {
                            "type": "string",
                            "value": "50dp"
                        },
                        "segmentProps": []
                    },
                    "btnReset": {
                        "height": {
                            "type": "string",
                            "value": "100%"
                        },
                        "segmentProps": []
                    },
                    "flxRightMain": {
                        "segmentProps": []
                    },
                    "lblWelMsg": {
                        "segmentProps": []
                    }
                },
                "1024": {
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxMainLogin": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxLblLogin": {
                        "segmentProps": []
                    },
                    "flxUserName": {
                        "segmentProps": []
                    },
                    "flxPassword": {
                        "segmentProps": []
                    },
                    "flxButton": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "btnLogin": {
                        "segmentProps": []
                    },
                    "flxLblResetPassword": {
                        "segmentProps": []
                    },
                    "flxResetUser": {
                        "segmentProps": []
                    },
                    "flxResetUserName": {
                        "segmentProps": []
                    },
                    "flxPasswordOld": {
                        "segmentProps": []
                    },
                    "flxOldPassword": {
                        "segmentProps": []
                    },
                    "flxPasswordNew": {
                        "segmentProps": []
                    },
                    "flxNewPassword": {
                        "segmentProps": []
                    },
                    "flxConfirmPassword": {
                        "segmentProps": []
                    },
                    "flxConfirmNewPassword": {
                        "segmentProps": []
                    },
                    "flxBtnReset": {
                        "segmentProps": []
                    },
                    "btnReset": {
                        "segmentProps": []
                    },
                    "flxRightMain": {
                        "minWidth": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "lblWelMsg": {
                        "segmentProps": []
                    }
                },
                "1366": {
                    "flxLeft": {
                        "segmentProps": []
                    },
                    "flxMainLogin": {
                        "layoutType": kony.flex.FLOW_VERTICAL,
                        "segmentProps": []
                    },
                    "flxLblLogin": {
                        "segmentProps": []
                    },
                    "flxUserName": {
                        "segmentProps": []
                    },
                    "flxPassword": {
                        "segmentProps": []
                    },
                    "flxButton": {
                        "centerY": {
                            "type": "string",
                            "value": ""
                        },
                        "segmentProps": []
                    },
                    "flxLblResetPassword": {
                        "segmentProps": []
                    },
                    "flxResetUser": {
                        "segmentProps": []
                    },
                    "flxResetUserName": {
                        "segmentProps": []
                    },
                    "flxPasswordOld": {
                        "segmentProps": []
                    },
                    "flxOldPassword": {
                        "segmentProps": []
                    },
                    "flxPasswordNew": {
                        "segmentProps": []
                    },
                    "flxNewPassword": {
                        "segmentProps": []
                    },
                    "flxConfirmPassword": {
                        "segmentProps": []
                    },
                    "flxConfirmNewPassword": {
                        "segmentProps": []
                    },
                    "flxBtnReset": {
                        "segmentProps": []
                    },
                    "flxRightMain": {
                        "segmentProps": []
                    },
                    "lblWelMsg": {
                        "segmentProps": []
                    }
                }
            }
            this.compInstData = {
                "FooterText": {
                    "centerX": "50%",
                    "left": "0dp",
                    "top": "-4dp"
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmLogin,
            "enabledForIdleTimeout": false,
            "id": "frmLogin",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "CopyslForm0icbc7a2dd7da4d",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});