define("Login/userfrmLoginController", ["animations", "AppToolBox", "Utils"], (animations, AppToolBox, Utils) => ({
    onViewCreated: function() {
        this.view.preShow = this.preShow;
        this.view.postShow = this.postShow;
        this.view.onDeviceBack = () => {};
    },
    preShow: function() {
        let scope = this;
        scope.view.lblResetPassword.onTouchStart = scope.showResetPassword;
        scope.view.txtBoxNewPassword.onTextChange = scope.showOrHideConfirmPassword;
        scope.view.txtBoxConfirmNewPassword.onTextChange = scope.checkConfirmPassword;
        scope.view.txtBoxOldPassword.onTextChange = scope.checkAllEntered;
        scope.view.flxLeft.left = "-37%";
        scope.view.flxRightMain.left = "100%";
        this.loadMasterData();
        scope.view.txtBoxResetUserName.onTextChange = scope.checkAllEntered;
        scope.view.btnLogin.onClick = scope.login;
        scope.view.btnReset.onClick = scope.resetPassword;
        scope.view.btnResetPassword.onClick = () => {
            scope.view.flxMainLogin.setVisibility(false);
            scope.view.flxResetPassword.setVisibility(true);
        }
        scope.view.btnReset.onClick = scope.resetPassword;
        scope.view.btnCancelReset.onClick = scope.reset;
        scope.view.lblCancelReset.onTouchStart = scope.showLogin;
        scope.view.flxInfo.onHover = this.showToolTip;
        scope.reset();
    },
    postShow: function() {
        animations.loginAnim(this);
    },
    loadMasterData: function() {
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.fetchAllUserRole({});
        DashBoardModule.presentationController.getAppStatusByID({});
    },
    reset: function() {
        let scope = this;
        scope.view.lblLoginErr.setVisibility(false);
        scope.view.flxRightMain.height = "290dp";
        scope.view.flxResetPassword.isVisible = false;
        scope.view.flxMainLogin.isVisible = true;
        scope.view.flxLblLogin.top = "10%";
        scope.view.txtboxUserName.text = "";
        scope.view.txtboxPasswd.text = "";
        scope.view.lblResetPasswordErr.setVisibility(false);
    },
    resetPassword: function() {
        try {
            const scope = this;
            const userName = scope.view.txtUserName.text;
            const oldPassword = scope.view.txtOldPassword.text;
            const newPassword = scope.view.txtNewPassword.text;
            const confirmPassword = scope.view.txtConfirmPassword.text;
            if (AppToolBox.util.isNil(userName) || AppToolBox.util.isNil(oldPassword) || AppToolBox.util.isNil(newPassword) || AppToolBox.util.isNil(confirmPassword)) {
                scope.view.lblResetPasswordErr.text = "Please enter all the required data";
                scope.view.lblResetPasswordErr.setVisibility(true);
                scope.callResetTimer();
                return;
            }
            if (oldPassword === newPassword) {
                scope.view.lblResetPasswordErr.text = "New password can't be same as the old password";
                scope.view.lblResetPasswordErr.setVisibility(true);
                scope.callResetTimer();
                return;
            }
            if (newPassword !== confirmPassword) {
                scope.view.lblResetPasswordErr.text = "New password and confirm password doesn't match";
                scope.view.lblResetPasswordErr.setVisibility(true);
                scope.callResetTimer();
                return;
            }
            const data = {
                EmailID: userName,
                oldPassword: oldPassword,
                newPassword: newPassword,
            };
            let LoginMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("LoginModule");
            LoginMod.presentationController.resetPasswordNew(data);
        } catch (e) {
            kony.print(e.message);
        }
    },
    displayResetErr: function(Errmsg) {
        let scope = this;
        scope.view.lblResetPasswordErr.text = Errmsg;
        scope.view.lblResetPasswordErr.setVisibility(true);
        scope.view.flxLblResetPassword.top = "4%";
        kony.application.dismissLoadingScreen();
        scope.callResetTimer();
    },
    showResetPassword: function() {
        let scope = this;
        scope.view.btnReset.setEnabled(false);
        scope.view.flxMainLogin.isVisible = false;
        scope.view.flxRightMain.height = "380dp";
        scope.view.flxResetPassword.isVisible = true;
        scope.view.lblResetPasswordErr.setVisibility(false);
        scope.view.flxLblResetPassword.top = "10%";
        scope.view.txtBoxOldPassword.text = "";
        scope.view.txtBoxResetUserName.text = "";
        scope.view.txtBoxNewPassword.text = "";
        scope.view.txtBoxConfirmNewPassword.text = "";
        scope.view.txtBoxConfirmNewPassword.skin = "sknTxtBoxLatoReg12pxDisabled";
        scope.view.txtBoxNewPassword.skin = "skntxtBoxLatoReg12px";
        scope.view.txtBoxConfirmNewPassword.setEnabled(false);
    },
    checkAllEntered: function() {
        let scope = this;
        if (!AppToolBox.util.isNil(scope.view.txtBoxNewPassword.text) && !AppToolBox.util.isNil(scope.view.txtBoxConfirmNewPassword.text) && !AppToolBox.util.isNil(scope.view.txtBoxOldPassword.text) && !AppToolBox.util.isNil(scope.view.txtBoxResetUserName.text)) {
            if (scope.view.txtBoxNewPassword.text === scope.view.txtBoxConfirmNewPassword.text) {
                scope.view.btnReset.skin = "sknBtnLatoRegPurple16px";
                scope.view.btnReset.setEnabled(true);
            } else {
                scope.view.btnReset.skin = "sknBtnLatoReg16pxPurpleDisabled";
                scope.view.btnReset.setEnabled(false);
            }
        } else {
            scope.view.btnReset.skin = "sknBtnLatoReg16pxPurpleDisabled";
            scope.view.btnReset.setEnabled(false);
        }
    },
    checkConfirmPassword: function() {
        let scope = this;
        if (!AppToolBox.util.isNil(scope.view.txtBoxNewPassword.text) && !AppToolBox.util.isNil(scope.view.txtBoxConfirmNewPassword.text)) {
            if (scope.view.txtBoxNewPassword.text === scope.view.txtBoxConfirmNewPassword.text) {
                scope.view.txtBoxConfirmNewPassword.skin = "sknTxtBoxLatoReg12pxBorderGreen";
                scope.checkAllEntered();
            } else {
                scope.view.txtBoxConfirmNewPassword.skin = "sknTxtBoxLatoReg12pxBorderRed";
                scope.checkAllEntered();
            }
        } else {
            scope.checkAllEntered();
        }
    },
    showOrHideConfirmPassword: function() {
        let scope = this;
        var passwordValidity = this.checkValidPassword();
        if (!AppToolBox.util.isNil(scope.view.txtBoxNewPassword.text) && passwordValidity) {
            scope.view.txtBoxConfirmNewPassword.setEnabled(true);
            scope.view.txtBoxConfirmNewPassword.skin = "skntxtBoxLatoReg12px";
            scope.checkConfirmPassword();
        } else {
            scope.view.txtBoxConfirmNewPassword.setEnabled(false);
            scope.view.txtBoxConfirmNewPassword.skin = "sknTxtBoxLatoReg12pxDisabled";
        }
    },
    login: function() {
        try {
            const scope = this;
            const userid = scope.view.txtboxUserName.text;
            const Password = scope.view.txtboxPasswd.text;
            if (!AppToolBox.util.isNil(userid) && !AppToolBox.util.isNil(Password)) {
                kony.application.showLoadingScreen();
                const customAuth = KNYMobileFabric.getIdentityService("Login");
                customAuth.login({
                    userid,
                    Password
                }, function() {
                    customAuth.getSecurityAttributes(function(response) {
                        kony.print("Got Security response" + JSON.stringify(response));
                    }, function(err) {
                        kony.print();
                    })
                    customAuth.getUserAttributes(function(response) {
                        kony.print("Got user response" + JSON.stringify(response));
                        scope.loginSC(response);
                    }, function(err) {
                        kony.print();
                    })
                }, function(error) {
                    kony.print("Something went wrong in cusom login" + JSON.stringify(error));
                    scope.displayInvalidCred("Incorrect username or password");
                });
            } else {
                scope.displayInvalidCred("Please enter the credentails");
            }
        } catch (e) {
            kony.print(e.message);
        }
    },
    loginSC: function(response, params) {
        const scope = this;
        const userFlow = {
            "EVALUATOR": "frmEvaluatorDash",
            "ADMIN": "frmAdminDash",
            "TRAINEE": "frmUserDashboard",
            "CONSULTANT": "frmUserDashboard",
            "PROSPECTIVE_CANDIDATE": "frmUserDashboard",
        };
        const flow = ["EVALUATOR", "ADMIN", "TRAINEE", "CONSULTANT", "PROSPECTIVE_CANDIDATE"];
        try {
            if (!AppToolBox.util.isNil(response)) {
                response.Name = response.Name.replace("_", " ");
                AppToolBox.store.setItem("userDetails", response);
                if (!AppToolBox.util.isNil(response.isActive) && response.isActive === true) {
                    if (!AppToolBox.util.isNil(response.RoleID)) {
                        if (flow.includes(response.RoleID)) {
                            AppToolBox.navigation.navigateTo(userFlow[response.RoleID]);
                        } else {
                            AppToolBox.navigation.navigateTo("frmUserDashboard");
                        }
                    }
                } else {
                    scope.view.lblLoginErr.setVisibility(true);
                    this.displayAccountStatus();
                }
                kony.application.dismissLoadingScreen();
            } else {
                !AppToolBox.util.isNil(response) ? this.displayInvalidCred("User doesn't exists") : null;
            }
        } catch (e) {
            kony.print("catch of loginSC:: " + e);
        }
    },
    loginFC: function(response, params) {
        try {
            if (!AppToolBox.util.isNil(params.newPassword)) {
                let controller = kony.mvc.getController('frmLogin', true);
                controller.displayResetErr("Unable to reach the server. Please try again");
            } else {
                let controller = kony.mvc.getController('frmLogin', true);
                controller.displayInvalidCred("Unable to reach the server. Please try again");
            }
        } catch (e) {
            kony.print("catch of loginFC:: " + e);
        }
    },
    displayInvalidCred: function(Errmsg) {
        let scope = this;
        scope.view.lblLoginErr.skin = "sknlblLatoReg12pxRed";
        scope.view.lblLoginErr.text = Errmsg;
        scope.view.lblLoginErr.setVisibility(true);
        scope.view.flxLblLogin.top = "5%";
        kony.application.dismissLoadingScreen();
    },
    displaySuccess: function(Successmsg) {
        let scope = this;
        scope.showLogin();
        scope.view.lblLoginErr.text = Successmsg;
        scope.view.lblLoginErr.skin = "sknlblLatoBold14pxPurple";
        scope.view.lblLoginErr.setVisibility(true);
        scope.view.flxLblLogin.top = "5%";
    },
    displayAccountStatus: function() {
        let scope = this;
        scope.view.lblLoginErr.skin = "sknlblLatoReg12pxRed";
        scope.view.lblLoginErr.text = "Account Deactivated please login using Active Account";
        scope.view.lblLoginErr.setVisibility(true);
        scope.view.flxLblLogin.top = "5%";
        kony.application.dismissLoadingScreen();
    },
    checkValidPassword: function() {
        let scope = this;
        var validity = Utils.checkValidPassword(scope.view.txtBoxNewPassword.text);
        if ((!AppToolBox.util.isNil(scope.view.txtBoxNewPassword.text)) && validity) {
            scope.view.txtBoxNewPassword.skin = "sknTxtBoxLatoReg12pxBorderGreen";
        } else {
            scope.view.txtBoxNewPassword.skin = "sknTxtBoxLatoReg12pxBorderRed";
        }
        return validity;
    },
    checkValidUsername: function() {
        let scope = this;
        var validity = Utils.checkValidUsername(scope.view.txtBoxResetUserName.text);
        if ((!AppToolBox.util.isNil(scope.view.txtBoxResetUserName.text)) && validity) {
            scope.view.txtBoxResetUserName.skin = "sknTxtBoxLatoReg12pxBorderGreen";
        } else {
            scope.view.txtBoxResetUserName.skin = "sknTxtBoxLatoReg12pxBorderRed";
        }
        return validity;
    },
    showToolTip: function(widget, context) {
        var scope = this;
        if (context.eventType === constants.ONHOVER_MOUSE_ENTER) {
            scope.view.flxPopup.setVisibility(true);
        } else if (context.eventType === constants.ONHOVER_MOUSE_MOVE) {
            scope.view.flxPopup.setVisibility(true);
        } else if (context.eventType === constants.ONHOVER_MOUSE_LEAVE) {
            scope.view.flxPopup.setVisibility(false);
        }
    },
    callResetTimer: function() {
        kony.timer.schedule("resetErrTimer", () => {
            this.view.lblResetPasswordErr.setVisibility(false);
            kony.timer.cancel("resetErrTimer");
        }, 2, false);
    }
}));
define("Login/frmLoginControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Login/frmLoginController", ["Login/userfrmLoginController", "Login/frmLoginControllerActions"], function() {
    var controller = require("Login/userfrmLoginController");
    var controllerActions = ["Login/frmLoginControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
