define("AdminFlow/userfrmManageAssessmentController", ["AppToolBox", "animations"], (AppToolBox, animations) => ({
    //Type your controller code here 
    onNavigate: function() {
        this.view.preShow = this.preShow;
        this.view.postShow = this.postShow;
    },
    preShow: function() {
        //let userDetails = AppToolBox.store.getItem("userDetails");
        // this.view.headerNew1.setProfileUser(userDetails[0].Name);
        var scope = this;
        scope.view.onDeviceBack = function() {};
        this.view.flxQuickLinks.flxQuickLinks1.onTouchStart = this.navToCreateAssessment.bind(this, "create");
        this.view.flxQuickLinks.flxQuickLinks2.onTouchStart = this.navToMapAssessment;
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navToDash.bind(this);
        this.view.msgContainer.imgClose.onTouchStart = this.hideMessage;
        this.getAllAssessment();
    },
    hideMessage: function() {
        animations.hideMessage(this.view.flxMessageContainer);
    },
    navToDash: function() {
        AppToolBox.navigation.navigateTo("frmAdminDash");
    },
    getAllAssessment: function() {
        var params = {};
        kony.application.showLoadingScreen();
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.getAssessment(params);
    },
    setAllUsers: function(response) {
        var Users = [];
        var dataMap = {
            lblField1: "lblName",
            lblField2: "lblDuration",
            lblField3: "lblRole",
            lblViewbtn: "lblViewbtn",
            FlxView: "FlxView",
            flxEditbtn: "flxEditbtn",
            flxDeletebtn: "flxDeletebtn",
            lblAssessmentName: "lblAssessmentName",
            lblDuration: "lblDuration",
            lblRole: "lblRole",
            lblActions: "lblActions",
            imgSortName: "imgSortName",
            imgSortRole: "imgSortRole",
            imgSortDuration: "imgSortDuration",
            imgSortActions: "imgSortActions"
        };
        assessmentList = response.Assessments;
        for (var i = assessmentList.length - 1; i >= 0; i--) {
            var AllUsers = {
                lblName: assessmentList[i].AssessmentName,
                lblDuration: {
                    text: assessmentList[i].Duration + " Days",
                    skin: "sknlbl000000font15px"
                },
                lblRole: {
                    text: assessmentList[i].Role,
                    skin: "sknlbl000000font15px"
                },
                FlxView: {
                    "onClick": this.navToViewAssessment.bind(this, assessmentList[i], "view")
                },
                lblViewbtn: "View",
                flxEditbtn: {
                    "onClick": this.navToEditAssessment.bind(this, assessmentList[i], "edit")
                },
                flxDeletebtn: {
                    "isVisible": false
                },
                flxAssessmentDetails: {
                    "isVisible": true
                }
            };
            Users.push(AllUsers);
        }
        this.view.manageTable.segManageTable.widgetDataMap = dataMap;
        var allUsers = [
            [{
                lblAssessmentName: "ASSESSMENT NAME",
                lblDuration: "DURATION",
                lblRole: "ROLE",
                "lblActions": "ACTIONS",
                imgSortName: {
                    "isVisible": false
                },
                imgSortRole: {
                    "isVisible": false
                },
                imgSortDuration: {
                    "isVisible": false
                },
                imgSortActions: {
                    "isVisible": false
                }
            }, Users]
        ];
        this.view.manageTable.segManageTable.setData(allUsers);
        // this.view.manageTable.segManageTable.onRowClick=this.navToEditAssessment;
        kony.application.dismissLoadingScreen();
    },
    navToViewAssessment: function(res, flow) {
        var params = {
            "Filter": "AssessmentID eq " + res.AssessmentID,
            "flow": flow
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ApplicationFileModule");
        DashMod.presentationController.fetchAssessFile(params);
        AppToolBox.store.setItem("AsseesmentDetails", res);
    },
    navToEditAssessment: function(res, flow) {
        var params = {
            "Filter": "AssessmentID eq " + res.AssessmentID,
            "flow": flow
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ApplicationFileModule");
        DashMod.presentationController.fetchAssessFile(params);
        AppToolBox.store.setItem("AsseesmentDetails", res);
    },
    navToCreateAssessment: function(flow) {
        let nav = new kony.mvc.Navigation("frmCreateAssessment");
        nav.navigate(flow);
    },
    navToMapAssessment: function() {
        let nav = new kony.mvc.Navigation("frmAdminMapAssessment");
        nav.navigate();
    },
    displayMsg: function(Msg) {
        var scope = this;
        //this.reset();
        scope.view.msgContainer.setMessage(Msg);
        scope.view.msgContainer.flxMessageContainer.skin = "sknmessagepop";
        scope.view.msgContainer.showMessage(scope.view.flxMessageContainer, scope);
    },
}));
define("AdminFlow/frmManageAssessmentControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_i3bb2168d56c4de199207ca3abec8670: function AS_Form_i3bb2168d56c4de199207ca3abec8670(eventobject) {
        var self = this;
    }
});
define("AdminFlow/frmManageAssessmentController", ["AdminFlow/userfrmManageAssessmentController", "AdminFlow/frmManageAssessmentControllerActions"], function() {
    var controller = require("AdminFlow/userfrmManageAssessmentController");
    var controllerActions = ["AdminFlow/frmManageAssessmentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
