define("AdminFlow/frmCreateAssessment", function() {
    return function(controller) {
        function addWidgetsfrmCreateAssessment() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var headerNew = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "headerNew": {
                        "height": "100%"
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(headerNew);
            var flxMiddle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": false,
                "height": "82%",
                "id": "flxMiddle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddle.setDefaultUnit(kony.flex.DP);
            var flxMessageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "7%",
                "id": "flxMessageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "sknflxBottom",
                "top": "-13%",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageContainer.setDefaultUnit(kony.flex.DP);
            var msgContainer = new com.evaluationPortal.msgContainer.msgContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "msgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgClose": {
                        "src": "close_white_solid.png"
                    },
                    "lblMessage": {
                        "centerY": "50%"
                    },
                    "msgContainer": {
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMessageContainer.add(msgContainer);
            var flxMiddleScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMiddleScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddleScroll.setDefaultUnit(kony.flex.DP);
            var flxBreadcrum = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "5%",
                "id": "flxBreadcrum",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "28dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadcrum.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxBreadcrum": {
                        "centerY": "62%",
                        "height": "100%",
                        "left": "3%",
                        "top": "28dp",
                        "width": "94%"
                    },
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false
                    },
                    "imgHome": {
                        "height": "100%",
                        "isVisible": true,
                        "src": "home_solid.png",
                        "width": "1%"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBreadcrum.add(BreadCrum);
            var flxBodyCreateAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "150%",
                "id": "flxBodyCreateAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-5dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyCreateAssessment.setDefaultUnit(kony.flex.DP);
            var flxCreateAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxCreateAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateAssessment.setDefaultUnit(kony.flex.DP);
            var flxCreateAssessmentTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxCreateAssessmentTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "92%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateAssessmentTitle.setDefaultUnit(kony.flex.DP);
            var lblCreateAssessment = new kony.ui.Label({
                "id": "lblCreateAssessment",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl000000font28px",
                "text": "Create Assessment",
                "top": "7dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCreateAssessmentTitle.add(lblCreateAssessment);
            var flxCreateAssessmentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "85%",
                "id": "flxCreateAssessmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "10dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateAssessmentContainer.setDefaultUnit(kony.flex.DP);
            var flxSelectRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "17%",
                "id": "flxSelectRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectRole.setDefaultUnit(kony.flex.DP);
            var lblRole = new kony.ui.Label({
                "id": "lblRole",
                "isVisible": true,
                "left": "3%",
                "skin": "sknNameAssessment",
                "text": "Role",
                "top": "20%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lstBoxRole = new kony.ui.ListBox({
                "focusSkin": "defListBoxFocus",
                "height": "44dp",
                "id": "lstBoxRole",
                "isVisible": false,
                "left": "2.99%",
                "masterData": [
                    ["lb1", "Placeholder One"],
                    ["lb2", "Placeholder Two"],
                    ["lb3", "Placeholder Three"]
                ],
                "skin": "sknRolePlace",
                "top": "7.93%",
                "width": "405dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            var flxRolecontainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxRolecontainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "22dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "45%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRolecontainer.setDefaultUnit(kony.flex.DP);
            var txtBoRoleName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtBoRoleName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "1.98%",
                "placeholder": "Select a Role",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "20%",
                "width": "404dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var imgDropdownArrow = new kony.ui.Image2({
                "height": "26dp",
                "id": "imgDropdownArrow",
                "isVisible": true,
                "left": "367dp",
                "skin": "slImage",
                "src": "polygon_6.png",
                "top": "22dp",
                "width": "44dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRolecontainer.add(txtBoRoleName, imgDropdownArrow);
            var flxDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "26dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "404dp",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var DropDown = new com.evaluationPortal.dropDown.DropDown({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "44dp",
                "id": "DropDown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxDropDownValues": {
                        "isVisible": false
                    },
                    "imgDropdownArrow": {
                        "src": "polygon_6.png"
                    },
                    "txtBoxDropDown": {
                        "centerY": "52%",
                        "left": "0%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxDropDown.add(DropDown);
            flxSelectRole.add(lblRole, lstBoxRole, flxRolecontainer, flxDropDown);
            var flxAssessmentNameDuration = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxAssessmentNameDuration",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentNameDuration.setDefaultUnit(kony.flex.DP);
            var flxAssessmentName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAssessmentName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "11dp",
                "width": "50%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentName.setDefaultUnit(kony.flex.DP);
            var lblAssessmentName = new kony.ui.Label({
                "id": "lblAssessmentName",
                "isVisible": true,
                "left": "6%",
                "skin": "sknNameAssessment",
                "text": "Assessment Name",
                "top": "-3%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBoxAssessmentName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "44dp",
                "id": "txtBoxAssessmentName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "6%",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13%",
                "width": "404dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxAssessmentName.add(lblAssessmentName, txtBoxAssessmentName);
            var flxAssessmentDuration = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxAssessmentDuration",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "10dp",
                "width": "50%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentDuration.setDefaultUnit(kony.flex.DP);
            var lblAssessmentDuration = new kony.ui.Label({
                "id": "lblAssessmentDuration",
                "isVisible": true,
                "left": "3%",
                "skin": "sknNameAssessment",
                "text": "Duration",
                "top": "-4%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBoxAssessmentDuration = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "44dp",
                "id": "txtBoxAssessmentDuration",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "3%",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13%",
                "width": "404dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 3, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxAssessmentDuration.add(lblAssessmentDuration, txtBoxAssessmentDuration);
            flxAssessmentNameDuration.add(flxAssessmentName, flxAssessmentDuration);
            var flxAssessmentInstructions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "19%",
                "id": "flxAssessmentInstructions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentInstructions.setDefaultUnit(kony.flex.DP);
            var lblAssessmentInstructions = new kony.ui.Label({
                "id": "lblAssessmentInstructions",
                "isVisible": true,
                "left": "3%",
                "skin": "sknNameAssessment",
                "text": "Assessment Instructions",
                "top": "3%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBoxAssessmentInstructions2 = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "height": "90dp",
                "id": "txtBoxAssessmentInstructions2",
                "isVisible": false,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_CHAT,
                "left": "3%",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "8%",
                "width": "835dp"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var txtBoxAssessmentInstructions = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "height": "90dp",
                "id": "txtBoxAssessmentInstructions",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "3%",
                "numberOfVisibleLines": 3,
                "skin": "skntxtdescfffccc8pxradius",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "8%",
                "width": "835dp",
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxAssessmentInstructions.add(lblAssessmentInstructions, txtBoxAssessmentInstructions2, txtBoxAssessmentInstructions);
            var flxUpload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "28%",
                "id": "flxUpload",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUpload.setDefaultUnit(kony.flex.DP);
            var flxUploadFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "72.05%",
                "id": "flxUploadFiles",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadFiles.setDefaultUnit(kony.flex.DP);
            var lblUploadFiles = new kony.ui.Label({
                "id": "lblUploadFiles",
                "isVisible": true,
                "left": "8%",
                "skin": "sknNameAssessment",
                "text": "Upload Files",
                "top": "-3dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "212dp",
                "id": "flxDropFiles",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8%",
                "isModalContainer": false,
                "skin": "CopysknBrowseDrop0fb5aa86ab5e94e",
                "top": "5%",
                "width": "404dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropFiles.setDefaultUnit(kony.flex.DP);
            var imgUpload = new kony.ui.Image2({
                "centerX": "50%",
                "centerY": "35%",
                "height": "20%",
                "id": "imgUpload",
                "isVisible": true,
                "left": "0",
                "skin": "slImage",
                "src": "upload_cloud_solid.png",
                "top": "0",
                "width": "20%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadDrag = new kony.ui.Label({
                "centerX": "42%",
                "centerY": "50%",
                "height": "8%",
                "id": "lblUploadDrag",
                "isVisible": false,
                "left": "0",
                "skin": "sknlbl00015pxbold",
                "text": "Drag and drop or",
                "top": "0",
                "width": "34%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblUploadBrowse = new kony.ui.Label({
                "centerX": "52%",
                "centerY": "50%",
                "height": "8%",
                "id": "lblUploadBrowse",
                "isVisible": true,
                "left": "33%",
                "skin": "sknlbl15px411062",
                "text": "Browse",
                "top": "0",
                "width": "16%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropFiles.add(imgUpload, lblUploadDrag, lblUploadBrowse);
            flxUploadFiles.add(lblUploadFiles, flxDropFiles);
            var flxUploadedFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "77.81%",
                "id": "flxUploadedFiles",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-1dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFiles.setDefaultUnit(kony.flex.DP);
            var lblUploadedFiles = new kony.ui.Label({
                "id": "lblUploadedFiles",
                "isVisible": true,
                "left": "5%",
                "skin": "sknNameAssessment",
                "text": "Uploaded Files",
                "top": "-4dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedFilesMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxUploadedFilesMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "5%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFilesMain.setDefaultUnit(kony.flex.DP);
            var flxUploadedFiles1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "49%",
                "clipBounds": false,
                "height": "58dp",
                "id": "flxUploadedFiles1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "skin": "sknuploaded",
                "top": "0%",
                "width": "404dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFiles1.setDefaultUnit(kony.flex.DP);
            var imgUploadIcon1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgUploadIcon1",
                "isVisible": true,
                "left": "5%",
                "skin": "slImage",
                "src": "doc_solid.png",
                "top": "0",
                "width": "10%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedDetails1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "60%",
                "id": "flxUploadedDetails1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedDetails1.setDefaultUnit(kony.flex.DP);
            var lblUploadedFileName1 = new kony.ui.Label({
                "height": "20dp",
                "id": "lblUploadedFileName1",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl15px411062",
                "text": "FSD Document",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadStatus1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "20%",
                "id": "flxUploadStatus1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "6%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadStatus1.setDefaultUnit(kony.flex.DP);
            var flxUploadStatusGreen1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxUploadStatusGreen1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlx4ECC48",
                "top": "0dp",
                "width": "0%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadStatusGreen1.setDefaultUnit(kony.flex.DP);
            flxUploadStatusGreen1.add();
            var flxUploadStatusBg1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxUploadStatusBg1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknFlxD9D9D9",
                "top": "0dp",
                "width": "98%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadStatusBg1.setDefaultUnit(kony.flex.DP);
            flxUploadStatusBg1.add();
            flxUploadStatus1.add(flxUploadStatusGreen1, flxUploadStatusBg1);
            flxUploadedDetails1.add(lblUploadedFileName1, flxUploadStatus1);
            var imgDelete1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgDelete1",
                "isVisible": true,
                "right": "5%",
                "skin": "slImage",
                "src": "delete_solid.png",
                "top": "0",
                "width": "8%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedFiles1.add(imgUploadIcon1, flxUploadedDetails1, imgDelete1);
            var flxUploadedFiles2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "49%",
                "clipBounds": false,
                "height": "58dp",
                "id": "flxUploadedFiles2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "skin": "sknuploaded",
                "top": "11%",
                "width": "404dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFiles2.setDefaultUnit(kony.flex.DP);
            var imgUploadIcon2 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgUploadIcon2",
                "isVisible": true,
                "left": "5%",
                "skin": "slImage",
                "src": "pdf_solid.png",
                "top": "0",
                "width": "10%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedDetails2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxUploadedDetails2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedDetails2.setDefaultUnit(kony.flex.DP);
            var lblUploadedFileName2 = new kony.ui.Label({
                "centerY": "43%",
                "height": "50%",
                "id": "lblUploadedFileName2",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl15px411062",
                "text": "FSD Document1",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUploadedDetails2 = new kony.ui.Image2({
                "centerY": "70%",
                "height": "20%",
                "id": "imgUploadedDetails2",
                "isVisible": false,
                "left": "2%",
                "skin": "slImage",
                "src": "upload_bgd_solid.png",
                "top": "12%",
                "width": "97%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedDetails2.add(lblUploadedFileName2, imgUploadedDetails2);
            var imgDelete2 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgDelete2",
                "isVisible": true,
                "right": "5%",
                "skin": "slImage",
                "src": "delete_solid.png",
                "top": "0",
                "width": "8%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedFiles2.add(imgUploadIcon2, flxUploadedDetails2, imgDelete2);
            var flxUploadedFiles3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "49.00%",
                "clipBounds": false,
                "height": "58dp",
                "id": "flxUploadedFiles3",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "skin": "sknuploaded",
                "top": "10%",
                "width": "404dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedFiles3.setDefaultUnit(kony.flex.DP);
            var imgUploadIcon3 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgUploadIcon3",
                "isVisible": true,
                "left": "5%",
                "skin": "slImage",
                "src": "doc_solid.png",
                "top": "0",
                "width": "10%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxUploadedDetails3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxUploadedDetails3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadedDetails3.setDefaultUnit(kony.flex.DP);
            var lblUploadedFileName3 = new kony.ui.Label({
                "centerY": "26%",
                "height": "50%",
                "id": "lblUploadedFileName3",
                "isVisible": true,
                "left": "2%",
                "skin": "sknlbl15px411062",
                "text": "FSD Document3",
                "top": "0%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgUploadedDetails3 = new kony.ui.Image2({
                "centerY": "83%",
                "height": "20%",
                "id": "imgUploadedDetails3",
                "isVisible": true,
                "left": "2%",
                "skin": "slImage",
                "src": "upload_bgd_solid.png",
                "top": "60%",
                "width": "97%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgGreenLine = new kony.ui.Image2({
                "height": "20%",
                "id": "imgGreenLine",
                "isVisible": true,
                "left": "3dp",
                "skin": "slImage",
                "src": "rectangle_70.png",
                "top": "19dp",
                "width": "175dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedDetails3.add(lblUploadedFileName3, imgUploadedDetails3, imgGreenLine);
            var imgDelete3 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgDelete3",
                "isVisible": true,
                "right": "5%",
                "skin": "slImage",
                "src": "x__1_.png",
                "top": "0",
                "width": "8%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadedFiles3.add(imgUploadIcon3, flxUploadedDetails3, imgDelete3);
            flxUploadedFilesMain.add(flxUploadedFiles1, flxUploadedFiles2, flxUploadedFiles3);
            flxUploadedFiles.add(lblUploadedFiles, flxUploadedFilesMain);
            flxUpload.add(flxUploadFiles, flxUploadedFiles);
            var flxOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "9.52%",
                "id": "flxOptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "8%",
                "width": "66.08%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxOptions.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "centerY": "50%",
                "height": "42dp",
                "id": "btnCancel",
                "isVisible": true,
                "left": "46%",
                "skin": "sknCancelbtn",
                "text": "Cancel",
                "top": "0",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnDelete = new kony.ui.Button({
                "centerY": "50%",
                "height": "42dp",
                "id": "btnDelete",
                "isVisible": true,
                "left": 13,
                "skin": "skncreatebtn",
                "text": "Create",
                "top": "0",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOptions.add(btnCancel, btnDelete);
            flxCreateAssessmentContainer.add(flxSelectRole, flxAssessmentNameDuration, flxAssessmentInstructions, flxUpload, flxOptions);
            flxCreateAssessment.add(flxCreateAssessmentTitle, flxCreateAssessmentContainer);
            var flxQuickLinksMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "400dp",
                "id": "flxQuickLinksMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": 0,
                "width": "30%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinksMain.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-10dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxLinks": {
                        "top": "0dp"
                    },
                    "flxQuickLinks": {
                        "left": "-10dp"
                    },
                    "flxQuickLinks1": {
                        "isVisible": true,
                        "width": "100%"
                    },
                    "flxQuickLinks2": {
                        "width": "100%"
                    },
                    "flxQuickLinks3": {
                        "isVisible": true,
                        "width": "100%"
                    },
                    "flxQuickLinks4": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinksTitle": {
                        "top": "4dp"
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "map_solid.png"
                    },
                    "imgQuickLinks3": {
                        "src": "manageassesment.png"
                    },
                    "lblQuickLinks": {
                        "top": "15%"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Assessment"
                    },
                    "lblQuickLinks2": {
                        "text": "Map Assessment"
                    },
                    "lblQuickLinks3": {
                        "text": "Manage Assessment"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxQuickLinksMain.add(flxQuickLinks);
            flxBodyCreateAssessment.add(flxCreateAssessment, flxQuickLinksMain);
            var flxFooterMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "34.50%",
                "id": "flxFooterMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterMenu.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "appFooter": {
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "copyrightFooter": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooterMenu.add(appFooter, copyrightFooter);
            flxMiddleScroll.add(flxBreadcrum, flxBodyCreateAssessment, flxFooterMenu);
            flxMiddle.add(flxMessageContainer, flxMiddleScroll);
            flxMain.add(flxHeader, flxMiddle);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknDeletePopup",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var flxPopup1 = new com.evaluationPortal.popup.flxPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxPopup1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxPopup": {
                        "isVisible": true
                    },
                    "imgClose": {
                        "src": "close_black_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(flxPopup1);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew": {
                    "height": "100%"
                },
                "headerNew.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew.imgUserImage": {
                    "src": "userimg.png"
                },
                "msgContainer.imgClose": {
                    "src": "close_white_solid.png"
                },
                "msgContainer.lblMessage": {
                    "centerY": "50%"
                },
                "msgContainer": {
                    "top": "0dp"
                },
                "BreadCrum.flxBreadcrum": {
                    "centerY": "62%",
                    "height": "100%",
                    "left": "3%",
                    "top": "28dp",
                    "width": "94%"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "height": "100%",
                    "src": "home_solid.png",
                    "width": "1%"
                },
                "DropDown.imgDropdownArrow": {
                    "src": "polygon_6.png"
                },
                "DropDown.txtBoxDropDown": {
                    "centerY": "52%",
                    "left": "0%"
                },
                "flxQuickLinks.flxLinks": {
                    "top": "0dp"
                },
                "flxQuickLinks": {
                    "left": "-10dp"
                },
                "flxQuickLinks.flxQuickLinks1": {
                    "width": "100%"
                },
                "flxQuickLinks.flxQuickLinks2": {
                    "width": "100%"
                },
                "flxQuickLinks.flxQuickLinks3": {
                    "width": "100%"
                },
                "flxQuickLinks.flxQuickLinks4": {
                    "width": "100%"
                },
                "flxQuickLinks.flxQuickLinksTitle": {
                    "top": "4dp"
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "map_solid.png"
                },
                "flxQuickLinks.imgQuickLinks3": {
                    "src": "manageassesment.png"
                },
                "flxQuickLinks.lblQuickLinks": {
                    "top": "15%"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "Create Assessment"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Map Assessment"
                },
                "flxQuickLinks.lblQuickLinks3": {
                    "text": "Manage Assessment"
                },
                "appFooter": {
                    "top": "0dp"
                },
                "copyrightFooter": {
                    "centerY": "",
                    "top": "0dp"
                },
                "flxPopup1.imgClose": {
                    "src": "close_black_solid.png"
                }
            }
            this.add(flxMain, flxPopup);
        };
        return [{
            "addWidgets": addWidgetsfrmCreateAssessment,
            "enabledForIdleTimeout": false,
            "id": "frmCreateAssessment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_ee83d1b8d89043aa840e2731ae739d89,
            "retainScrollPosition": false
        }]
    }
});