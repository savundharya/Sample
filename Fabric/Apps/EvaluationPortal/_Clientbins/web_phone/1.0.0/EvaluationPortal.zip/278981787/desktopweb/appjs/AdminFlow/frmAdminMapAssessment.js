define("AdminFlow/frmAdminMapAssessment", function() {
    return function(controller) {
        function addWidgetsfrmAdminMapAssessment() {
            this.setDefaultUnit(kony.flex.DP);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var flxPopup1 = new com.evaluationPortal.popup.flxPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxPopup1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxPopup": {
                        "isVisible": true
                    },
                    "imgClose": {
                        "src": "close_black_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(flxPopup1);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var headerNew = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "headerNew": {
                        "height": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(headerNew);
            var flxMiddle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": false,
                "height": "82%",
                "id": "flxMiddle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddle.setDefaultUnit(kony.flex.DP);
            var flxMessageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "7%",
                "id": "flxMessageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxBottom",
                "top": "-13%",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageContainer.setDefaultUnit(kony.flex.DP);
            var msgContainer = new com.evaluationPortal.msgContainer.msgContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "msgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "CopyslFbox0h6658fb10fd743",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgClose": {
                        "src": "close_white_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMessageContainer.add(msgContainer);
            var flxMiddleScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMiddleScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddleScroll.setDefaultUnit(kony.flex.DP);
            var flxBreadcrum = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8%",
                "id": "flxBreadcrum",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "40dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "91.51%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadcrum.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxBreadcrum": {
                        "centerY": "54%",
                        "height": "100%",
                        "left": "0dp"
                    },
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false
                    },
                    "imgHome": {
                        "height": "100%",
                        "isVisible": true,
                        "src": "home_solid.png",
                        "width": "1%"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBreadcrum.add(BreadCrum);
            var flxBodyMapAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "161.25%",
                "id": "flxBodyMapAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyMapAssessment.setDefaultUnit(kony.flex.DP);
            var flxMapAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMapAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMapAssessment.setDefaultUnit(kony.flex.DP);
            var flxMapAssessmentTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxMapAssessmentTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "92%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMapAssessmentTitle.setDefaultUnit(kony.flex.DP);
            var lblMapAssessment = new kony.ui.Label({
                "id": "lblMapAssessment",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl000000font28px",
                "text": "Map Assessment",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxMapAssessmentTitle.add(lblMapAssessment);
            var flxMapAssessmentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "51%",
                "clipBounds": false,
                "height": "90%",
                "id": "flxMapAssessmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "20dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMapAssessmentContainer.setDefaultUnit(kony.flex.DP);
            var flxInstructions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxInstructions",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxInstructions.setDefaultUnit(kony.flex.DP);
            var FlexContaiflxInstruction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": 50,
                "clipBounds": false,
                "height": "66dp",
                "id": "FlexContaiflxInstruction",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "41dp",
                "isModalContainer": false,
                "right": "31dp",
                "skin": "sknflxInstruction",
                "top": 0,
                "width": "95%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            FlexContaiflxInstruction.setDefaultUnit(kony.flex.DP);
            var imgInfoicon = new kony.ui.Image2({
                "bottom": "19dp",
                "height": "30dp",
                "id": "imgInfoicon",
                "isVisible": true,
                "left": "15dp",
                "skin": "slImage",
                "src": "info_solid.png",
                "top": "17dp",
                "width": "30dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblInstruction = new kony.ui.Label({
                "bottom": "25dp",
                "centerY": 30,
                "height": "17dp",
                "id": "lblInstruction",
                "isVisible": true,
                "left": "57dp",
                "skin": "sknbluecolortxt",
                "text": "Select the role and assessment to map the assessment for the users under the role",
                "top": "57dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            FlexContaiflxInstruction.add(imgInfoicon, lblInstruction);
            flxInstructions.add(FlexContaiflxInstruction);
            var flxAssessmentNameDuration = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8.40%",
                "id": "flxAssessmentNameDuration",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "28dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentNameDuration.setDefaultUnit(kony.flex.DP);
            var flxSelectRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSelectRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectRole.setDefaultUnit(kony.flex.DP);
            var lblRole = new kony.ui.Label({
                "id": "lblRole",
                "isVisible": true,
                "left": "6%",
                "skin": "sknNameAssessment",
                "text": "Role",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxRoleDropdown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRoleDropdown",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRoleDropdown.setDefaultUnit(kony.flex.DP);
            var DropDown = new com.evaluationPortal.dropDown.DropDown({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "44dp",
                "id": "DropDown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxDropDownValues": {
                        "isVisible": false
                    },
                    "imgDropdownArrow": {
                        "left": "92%",
                        "src": "polygon_6.png",
                        "top": "15dp"
                    },
                    "txtBoxDropDown": {
                        "centerY": "45%",
                        "height": "44dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRoleDropdown.add(DropDown);
            flxSelectRole.add(lblRole, flxRoleDropdown);
            var flxSelectAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxSelectAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSelectAssessment.setDefaultUnit(kony.flex.DP);
            var lblAssessmentName = new kony.ui.Label({
                "id": "lblAssessmentName",
                "isVisible": true,
                "left": "18dp",
                "skin": "sknNameAssessment",
                "text": "Assessment",
                "top": "0%",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxEverydayRetail = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEverydayRetail",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "18dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "15dp",
                "width": "92%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxEverydayRetail.setDefaultUnit(kony.flex.DP);
            var DropDown1 = new com.evaluationPortal.dropDown.DropDown({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "44dp",
                "id": "DropDown1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgDropdownArrow": {
                        "left": "91%",
                        "src": "polygon_6.png",
                        "top": "15dp"
                    },
                    "txtBoxDropDown": {
                        "centerY": "45%",
                        "height": "44dp",
                        "left": "0%",
                        "top": "0dp",
                        "width": "100%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxEverydayRetail.add(DropDown1);
            flxSelectAssessment.add(lblAssessmentName, flxEverydayRetail);
            flxAssessmentNameDuration.add(flxSelectRole, flxSelectAssessment);
            var flxAssignUsers = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50%",
                "id": "flxAssignUsers",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "29dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssignUsers.setDefaultUnit(kony.flex.DP);
            var flxEvaluatorList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "470dp",
                "id": "flxEvaluatorList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "31dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "45%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxEvaluatorList.setDefaultUnit(kony.flex.DP);
            var lblEvaluator = new kony.ui.Label({
                "id": "lblEvaluator",
                "isVisible": true,
                "left": 0,
                "skin": "sknNameAssessment",
                "text": "Unassigned People",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxListEvaluator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90%",
                "id": "flxListEvaluator",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "sknSearchbox",
                "top": "4%",
                "width": "404dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxListEvaluator.setDefaultUnit(kony.flex.DP);
            var flxSearchEvaluator = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxSearchEvaluator",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchEvaluator.setDefaultUnit(kony.flex.DP);
            var imgSearchEvaluator = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgSearchEvaluator",
                "isVisible": true,
                "left": "8%",
                "skin": "slImage",
                "src": "search_solid.png",
                "top": "0",
                "width": "8%",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSearchEvaluator = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "96%",
                "id": "txtSearchEvaluator",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Search Name",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "3%",
                "width": "90%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [13, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxSearchEvaluator.add(imgSearchEvaluator, txtSearchEvaluator);
            var flxEvaluator = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": false,
                "enableScrolling": true,
                "height": "80%",
                "horizontalScrollIndicator": true,
                "id": "flxEvaluator",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "3%",
                "verticalScrollIndicator": true,
                "width": "95%"
            }, {
                "paddingInPixel": false
            }, {});
            flxEvaluator.setDefaultUnit(kony.flex.DP);
            var chckBoxEvaluator = new kony.ui.CheckBoxGroup({
                "id": "chckBoxEvaluator",
                "isVisible": true,
                "left": "5%",
                "masterData": [
                    ["cbg2", "Vinay Vinothan"],
                    ["cbg3", "Aswini Srinivasa"],
                    ["Key598042387", "Deepika Bala"],
                    ["Key4059423223", "Surya Ravi"],
                    ["Key2368135797", "Williams Smith"],
                    ["Key3805122593", "Peterson"]
                ],
                "minHeight": "90%",
                "selectedKeys": ["Key4059423223"],
                "skin": "sknCheckboxGroup",
                "top": "1%",
                "width": "90%"
            }, {
                "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEvaluator.add(chckBoxEvaluator);
            flxListEvaluator.add(flxSearchEvaluator, flxEvaluator);
            var flxUnassignedPeople = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "432dp",
                "id": "flxUnassignedPeople",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6.08%",
                "isModalContainer": false,
                "skin": "sknflxUnassignedPeople",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUnassignedPeople.setDefaultUnit(kony.flex.DP);
            var flxUnassignedPeopleSearchname = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "44dp",
                "id": "flxUnassignedPeopleSearchname",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUnassignedPeopleSearchname.setDefaultUnit(kony.flex.DP);
            var imgSearch = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgSearch",
                "isVisible": true,
                "left": "8%",
                "skin": "slImage",
                "src": "search_solid.png",
                "top": "0",
                "width": "8%",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSearch = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "txtSearch",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Search Name",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [13, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxUnassignedPeopleSearchname.add(imgSearch, txtSearch);
            var flxGroupCheckbox = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "83%",
                "horizontalScrollIndicator": true,
                "id": "flxGroupCheckbox",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "sknGroupseg",
                "top": "15.50%",
                "verticalScrollIndicator": true,
                "width": "95%"
            }, {
                "paddingInPixel": false
            }, {});
            flxGroupCheckbox.setDefaultUnit(kony.flex.DP);
            var chckGroupCheckbox = new kony.ui.CheckBoxGroup({
                "id": "chckGroupCheckbox",
                "isVisible": false,
                "left": "5%",
                "masterData": [
                    ["cbg2", "Vinay Vinothan"],
                    ["cbg3", "Aswini Srinivasa"],
                    ["Key598042387", "Deepika Bala"],
                    ["Key4059423223", "Surya Ravi"],
                    ["Key2368135797", "Williams Smith"],
                    ["Key3805122593", "Peterson"]
                ],
                "minHeight": "90%",
                "skin": "sknCheckboxGroup",
                "top": "5%",
                "width": "90%"
            }, {
                "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segUnassignedPeople = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "imgChecked": "imagedrag.png",
                    "imgSelection": "rectangle_47.png",
                    "lblUserName": "Williams Smith"
                }, {
                    "imgChecked": "imagedrag.png",
                    "imgSelection": "rectangle_47.png",
                    "lblUserName": "Adam Smith"
                }, {
                    "imgChecked": "imagedrag.png",
                    "imgSelection": "rectangle_47.png",
                    "lblUserName": "John Adam"
                }, {
                    "imgChecked": "imagedrag.png",
                    "imgSelection": "rectangle_47.png",
                    "lblUserName": "Peterson"
                }, {
                    "imgChecked": "imagedrag.png",
                    "imgSelection": "rectangle_47.png",
                    "lblUserName": "harris vettori"
                }, {
                    "imgChecked": "imagedrag.png",
                    "imgSelection": "rectangle_47.png",
                    "lblUserName": "Williams Smith"
                }, {
                    "imgChecked": "imagedrag.png",
                    "imgSelection": "rectangle_47.png",
                    "lblUserName": "Adam Smith"
                }],
                "groupCells": false,
                "id": "segUnassignedPeople",
                "isVisible": true,
                "left": "0",
                "maxHeight": "95%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxMultiSelectUser",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_SINGLE_SELECT_BEHAVIOR,
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "3dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxMultiSelectUser": "flxMultiSelectUser",
                    "flxSelectionImage": "flxSelectionImage",
                    "flxUserName": "flxUserName",
                    "imgChecked": "imgChecked",
                    "imgSelection": "imgSelection",
                    "lblUserName": "lblUserName"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxGroupCheckbox.add(chckGroupCheckbox, segUnassignedPeople);
            flxUnassignedPeople.add(flxUnassignedPeopleSearchname, flxGroupCheckbox);
            flxEvaluatorList.add(lblEvaluator, flxListEvaluator, flxUnassignedPeople);
            var flxUnAssignedList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "470dp",
                "id": "flxUnAssignedList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2.70%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "46%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUnAssignedList.setDefaultUnit(kony.flex.DP);
            var lblUnAssignedPeople = new kony.ui.Label({
                "id": "lblUnAssignedPeople",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknNameAssessment",
                "text": "Evaluator",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxListUnAssigned = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90%",
                "id": "flxListUnAssigned",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6%",
                "isModalContainer": false,
                "skin": "sknBrowseDrop",
                "top": "4%",
                "width": "404dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxListUnAssigned.setDefaultUnit(kony.flex.DP);
            var flxSearchUnAssigned = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxSearchUnAssigned",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSearchUnAssigned.setDefaultUnit(kony.flex.DP);
            var imgSearchUnAssigned = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgSearchUnAssigned",
                "isVisible": true,
                "left": "8%",
                "skin": "slImage",
                "src": "search_solid.png",
                "top": "0",
                "width": "8%",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSearchUnAssigned = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "96%",
                "id": "txtSearchUnAssigned",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Search Name",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "3%",
                "width": "90%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [13, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxSearchUnAssigned.add(imgSearchUnAssigned, txtSearchUnAssigned);
            var flxUnAssigned = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "centerX": "50%",
                "clipBounds": false,
                "enableScrolling": true,
                "height": "80%",
                "horizontalScrollIndicator": true,
                "id": "flxUnAssigned",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_NONE,
                "skin": "slFSbox",
                "top": "3%",
                "verticalScrollIndicator": true,
                "width": "404dp"
            }, {
                "paddingInPixel": false
            }, {});
            flxUnAssigned.setDefaultUnit(kony.flex.DP);
            var chckBoxUnAssigned = new kony.ui.CheckBoxGroup({
                "id": "chckBoxUnAssigned",
                "isVisible": false,
                "left": "5%",
                "masterData": [
                    ["lbl1", "Jeeva Subramani"],
                    ["cbg2", "Vinay Vinothan"],
                    ["cbg3", "Aswini Srinivasa"],
                    ["Key598042387", "Deepika Bala"],
                    ["Key3203041355", "Gokul Nagarajan"],
                    ["Key4059423223", "Surya Ravi"],
                    ["Key1539998950", "Pallavi Bagul"],
                    ["Key1448936809", "Kajal GafarShaikh"],
                    ["Key2368135797", "Williams Smith"],
                    ["Key746650462", "John Adam"],
                    ["Key3805122593", "Peterson"],
                    ["Key2713552073", "Adam Smith"],
                    ["Key2265109049", "Kalyan Venkat"],
                    ["Key622491267", "Lucas Smith"],
                    ["Key3587111194", "Lucerys"]
                ],
                "minHeight": "90%",
                "top": "1%",
                "width": "90%"
            }, {
                "itemOrientation": constants.CHECKBOX_ITEM_ORIENTATION_VERTICAL,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var segEvaluator = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblEvaluatorserch": "Adam Johnson"
                }, {
                    "lblEvaluatorserch": "Michael Clark"
                }, {
                    "lblEvaluatorserch": "Ronaldo"
                }, {
                    "lblEvaluatorserch": "David letterman"
                }, {
                    "lblEvaluatorserch": "Shawn Michael"
                }],
                "groupCells": false,
                "id": "segEvaluator",
                "isVisible": true,
                "left": "2dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxEvaluatorSegment",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "3dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxEvaluatorSegment": "flxEvaluatorSegment",
                    "lblEvaluatorserch": "lblEvaluatorserch"
                },
                "width": "99%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUnAssigned.add(chckBoxUnAssigned, segEvaluator);
            flxListUnAssigned.add(flxSearchUnAssigned, flxUnAssigned);
            var flxEvaluatorsearch = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "432dp",
                "id": "flxEvaluatorsearch",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "6%",
                "isModalContainer": false,
                "skin": "sknflxUnassignedPeople",
                "top": "11dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxEvaluatorsearch.setDefaultUnit(kony.flex.DP);
            var flxEvaluatorSearchBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "10%",
                "id": "flxEvaluatorSearchBox",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxEvaluatorSearchBox.setDefaultUnit(kony.flex.DP);
            var imgSearchbox = new kony.ui.Image2({
                "centerY": "50%",
                "height": "50%",
                "id": "imgSearchbox",
                "isVisible": true,
                "left": "8%",
                "skin": "slImage",
                "src": "search_solid.png",
                "top": "0",
                "width": "8%",
                "zIndex": 2
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSearchBox = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "height": "44dp",
                "id": "txtSearchBox",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": 18,
                "placeholder": "Search Name",
                "secureTextEntry": false,
                "skin": "skntxtBox",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "width": "90%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [13, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false
            });
            flxEvaluatorSearchBox.add(imgSearchbox, txtSearchBox);
            var flxEvaluatorDetail = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "84%",
                "horizontalScrollIndicator": true,
                "id": "flxEvaluatorDetail",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_NONE,
                "skin": "slFSbox",
                "top": "15%",
                "verticalScrollIndicator": true,
                "width": "95%"
            }, {
                "paddingInPixel": false
            }, {});
            flxEvaluatorDetail.setDefaultUnit(kony.flex.DP);
            var segEvaluatorSearchOptions = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblEvaluatorserch": "Adam Johnson"
                }, {
                    "lblEvaluatorserch": "Michael Clark"
                }, {
                    "lblEvaluatorserch": "Ronaldo"
                }, {
                    "lblEvaluatorserch": "David letterman"
                }, {
                    "lblEvaluatorserch": "Shawn Michael"
                }],
                "groupCells": false,
                "id": "segEvaluatorSearchOptions",
                "isVisible": true,
                "left": "0dp",
                "maxHeight": "95%",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "sknSegEvaluator",
                "rowTemplate": "flxEvaluatorSegment",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 0,
                "showScrollbars": false,
                "top": "3dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxEvaluatorSegment": "flxEvaluatorSegment",
                    "lblEvaluatorserch": "lblEvaluatorserch"
                },
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxEvaluatorDetail.add(segEvaluatorSearchOptions);
            flxEvaluatorsearch.add(flxEvaluatorSearchBox, flxEvaluatorDetail);
            flxUnAssignedList.add(lblUnAssignedPeople, flxListUnAssigned, flxEvaluatorsearch);
            flxAssignUsers.add(flxEvaluatorList, flxUnAssignedList);
            var flxOptions = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": 21,
                "centerX": "50%",
                "clipBounds": false,
                "height": "70dp",
                "id": "flxOptions",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "94dp",
                "width": "96.66%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxOptions.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "bottom": "0",
                "centerY": "50%",
                "focusSkin": "skncreatebtn",
                "height": "42dp",
                "id": "btnCancel",
                "isVisible": true,
                "left": "570dp",
                "skin": "sknCancelbtn",
                "text": "Cancel",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAssign = new kony.ui.Button({
                "bottom": "0",
                "centerY": "50%",
                "focusSkin": "sknCancelbtn",
                "height": "42dp",
                "id": "btnAssign",
                "isVisible": true,
                "left": 13,
                "skin": "skncreatebtn",
                "text": "Assign",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxOptions.add(btnCancel, btnAssign);
            flxMapAssessmentContainer.add(flxInstructions, flxAssessmentNameDuration, flxAssignUsers, flxOptions);
            flxMapAssessment.add(flxMapAssessmentTitle, flxMapAssessmentContainer);
            var flxQuickLinksMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "400dp",
                "id": "flxQuickLinksMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "-7dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinksMain.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-3dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-7dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxLinks": {
                        "top": "2dp"
                    },
                    "flxQuickLinks": {
                        "left": "-3dp",
                        "top": "-7dp"
                    },
                    "flxQuickLinks3": {
                        "isVisible": false
                    },
                    "flxQuickLinks4": {
                        "isVisible": false
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "map_solid.png"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Assessment"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage Assessment"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxQuickLinksMain.add(flxQuickLinks);
            flxBodyMapAssessment.add(flxMapAssessment, flxQuickLinksMain);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "34.50%",
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(appFooter, copyrightFooter);
            flxMiddleScroll.add(flxBreadcrum, flxBodyMapAssessment, flxFooter);
            flxMiddle.add(flxMessageContainer, flxMiddleScroll);
            flxMain.add(flxHeader, flxMiddle);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "flxPopup1.imgClose": {
                    "src": "close_black_solid.png"
                },
                "headerNew": {
                    "height": "100%"
                },
                "msgContainer.imgClose": {
                    "src": "close_white_solid.png"
                },
                "BreadCrum.flxBreadcrum": {
                    "centerY": "54%",
                    "height": "100%",
                    "left": "0dp"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "height": "100%",
                    "src": "home_solid.png",
                    "width": "1%"
                },
                "DropDown.imgDropdownArrow": {
                    "left": "92%",
                    "src": "polygon_6.png",
                    "top": "15dp"
                },
                "DropDown.txtBoxDropDown": {
                    "centerY": "45%",
                    "height": "44dp",
                    "width": "100%"
                },
                "DropDown1.imgDropdownArrow": {
                    "left": "91%",
                    "src": "polygon_6.png",
                    "top": "15dp"
                },
                "DropDown1.txtBoxDropDown": {
                    "centerY": "45%",
                    "height": "44dp",
                    "left": "0%",
                    "top": "0dp",
                    "width": "100%"
                },
                "flxQuickLinks.flxLinks": {
                    "top": "2dp"
                },
                "flxQuickLinks": {
                    "left": "-3dp",
                    "top": "-7dp"
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "map_solid.png"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "Create Assessment"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Manage Assessment"
                }
            }
            this.add(flxPopup, flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmAdminMapAssessment,
            "enabledForIdleTimeout": false,
            "id": "frmAdminMapAssessment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "slForm",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_cbe3e693312344a880f60f4d36c38f6d,
            "retainScrollPosition": false
        }]
    }
});