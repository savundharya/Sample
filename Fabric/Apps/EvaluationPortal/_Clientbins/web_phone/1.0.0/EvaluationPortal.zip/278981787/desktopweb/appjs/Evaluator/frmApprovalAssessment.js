define("Evaluator/frmApprovalAssessment", function() {
    return function(controller) {
        function addWidgetsfrmApprovalAssessment() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var headerNew = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxUserRoleName": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "35%"
                    },
                    "headerNew": {
                        "height": "100%",
                        "isVisible": true
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(headerNew);
            var flxMainContentLayout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "82%",
                "id": "flxMainContentLayout",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContentLayout.setDefaultUnit(kony.flex.DP);
            var flxMiddleScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMiddleScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddleScroll.setDefaultUnit(kony.flex.DP);
            var flxMainLayout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainLayout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainLayout.setDefaultUnit(kony.flex.DP);
            var flxBreadcrum = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "55dp",
                "id": "flxBreadcrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "21dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadcrum.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxBreadcrum": {
                        "height": "100%"
                    },
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false
                    },
                    "imgHome": {
                        "height": "100%",
                        "isVisible": true,
                        "src": "home_solid.png",
                        "width": "1%"
                    },
                    "lblBreadcrum1": {
                        "text": "Manage Assessment"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBreadcrum.add(BreadCrum);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "66dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxLeftContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainer.setDefaultUnit(kony.flex.DP);
            var flxAssessmentTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentTitle.setDefaultUnit(kony.flex.DP);
            var flxAssessmentName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentName.setDefaultUnit(kony.flex.DP);
            var lblAssessmentName = new kony.ui.Label({
                "id": "lblAssessmentName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl000000font28px",
                "text": "Best Buy App",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAssessmentStatus = new kony.ui.Button({
                "focusSkin": "sknbtn7E6FFF",
                "height": "18dp",
                "id": "btnAssessmentStatus",
                "isVisible": true,
                "left": "6dp",
                "skin": "sknbtn7E6FFF",
                "text": "Submitted",
                "top": "10dp",
                "width": "71dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssessmentName.add(lblAssessmentName, btnAssessmentStatus);
            flxAssessmentTitle.add(flxAssessmentName);
            var flxMainData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainData.setDefaultUnit(kony.flex.DP);
            var flxMainContents = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "23dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContents.setDefaultUnit(kony.flex.DP);
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "31dp",
                "isModalContainer": false,
                "right": "31dp",
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxFirstRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFirstRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "31dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFirstRow.setDefaultUnit(kony.flex.DP);
            var flxUserName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUserName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUserName.setDefaultUnit(kony.flex.DP);
            var lblUserName = new kony.ui.Label({
                "id": "lblUserName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "User Name",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtUserName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtUserName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntxteeedisabled",
                "text": "Williams Smith",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxUserName.add(lblUserName, txtUserName);
            var flxSubmittedDate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSubmittedDate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubmittedDate.setDefaultUnit(kony.flex.DP);
            var lblSubmittedDate = new kony.ui.Label({
                "id": "lblSubmittedDate",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Submitted Date",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtSubmittedDate = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtSubmittedDate",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntxteeedisabled",
                "text": "10-11-2022",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxSubmittedDate.add(lblSubmittedDate, txtSubmittedDate);
            flxFirstRow.add(flxUserName, flxSubmittedDate);
            var flxSecondRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecondRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondRow.setDefaultUnit(kony.flex.DP);
            var flxAssessmentNames = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentNames",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentNames.setDefaultUnit(kony.flex.DP);
            var lblAssessmentNames = new kony.ui.Label({
                "id": "lblAssessmentNames",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Assessment Name",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtAssessmentName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtAssessmentName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntxteeedisabled",
                "text": "Best Buy App",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxAssessmentNames.add(lblAssessmentNames, txtAssessmentName);
            var flxDuration = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDuration",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDuration.setDefaultUnit(kony.flex.DP);
            var lblDuration = new kony.ui.Label({
                "id": "lblDuration",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Duration",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtDuration = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtDuration",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntxteeedisabled",
                "text": "60 days",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxDuration.add(lblDuration, txtDuration);
            flxSecondRow.add(flxAssessmentNames, flxDuration);
            var flxThirdRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxThirdRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxThirdRow.setDefaultUnit(kony.flex.DP);
            var flxAssessmentInstruction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentInstruction",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentInstruction.setDefaultUnit(kony.flex.DP);
            var lblAssessmentInstruction = new kony.ui.Label({
                "id": "lblAssessmentInstruction",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Assessment Instruction",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtAreaAssessmentInstruction = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextAreaFocus",
                "height": "100dp",
                "id": "txtAreaAssessmentInstruction",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "numberOfVisibleLines": 3,
                "placeholder": "Placeholder",
                "skin": "skntxtareaF4F4F4disabled",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxAssessmentInstruction.add(lblAssessmentInstruction, txtAreaAssessmentInstruction);
            flxThirdRow.add(flxAssessmentInstruction);
            var flxAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessment.setDefaultUnit(kony.flex.DP);
            var flxFourthRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFourthRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFourthRow.setDefaultUnit(kony.flex.DP);
            var flxAssessmentFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentFiles",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentFiles.setDefaultUnit(kony.flex.DP);
            var lblAssessmentFiles = new kony.ui.Label({
                "id": "lblAssessmentFiles",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl13px666666",
                "text": "Assessment Files",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDownload",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "80%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var flxDownloads = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDownloads",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0",
                "width": "15%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloads.setDefaultUnit(kony.flex.DP);
            var lblDownload = new kony.ui.Label({
                "id": "lblDownload",
                "isVisible": true,
                "right": "0",
                "skin": "sknLblcccccc",
                "text": "Download",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknFlxDarkPurple",
                "top": "0",
                "width": "75%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine.setDefaultUnit(kony.flex.DP);
            flxLine.add();
            flxDownloads.add(lblDownload, flxLine);
            flxDownload.add(flxDownloads);
            flxAssessmentFiles.add(lblAssessmentFiles, flxDownload);
            flxFourthRow.add(flxAssessmentFiles);
            var flxFifthRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFifthRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFifthRow.setDefaultUnit(kony.flex.DP);
            var flxUploadRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxUploadRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadRow1.setDefaultUnit(kony.flex.DP);
            var flxUploadFileContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxUploadFileContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer.setDefaultUnit(kony.flex.DP);
            var imgFileType = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgFileType",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFileUploadName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxFileUploadName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadName.setDefaultUnit(kony.flex.DP);
            var lblFileUploadName = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblFileUploadName",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknlbl000000opacity80",
                "text": "Assessment File",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileUploadName.add(lblFileUploadName);
            var imgUploadAction = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgUploadAction",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "download.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer.add(imgFileType, flxFileUploadName, imgUploadAction);
            flxUploadRow1.add(flxUploadFileContainer);
            flxFifthRow.add(flxUploadRow1);
            flxAssessment.add(flxFourthRow, flxFifthRow);
            var flxComment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxComment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxComment.setDefaultUnit(kony.flex.DP);
            var flxSixthRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSixthRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSixthRow.setDefaultUnit(kony.flex.DP);
            var flxComments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxComments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxComments.setDefaultUnit(kony.flex.DP);
            var lblComments = new kony.ui.Label({
                "id": "lblComments",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Comments",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComments.add(lblComments);
            flxSixthRow.add(flxComments);
            var flxSeventhRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSeventhRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxCCCCCCff8pxborder",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeventhRow.setDefaultUnit(kony.flex.DP);
            var flxCommentsLayout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxCommentsLayout",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCommentsLayout.setDefaultUnit(kony.flex.DP);
            var flxNames = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "53dp",
                "id": "flxNames",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "21dp",
                "isModalContainer": false,
                "skin": "sknflxF37070",
                "top": "0dp",
                "width": "51dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNames.setDefaultUnit(kony.flex.DP);
            var lblChatName = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "53dp",
                "id": "lblChatName",
                "isVisible": true,
                "skin": "sknlblfff16px",
                "text": "GN",
                "top": "0",
                "width": "51dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNames.add(lblChatName);
            var txtComments = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "defTextAreaFocus",
                "height": "80dp",
                "id": "txtComments",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "17dp",
                "numberOfVisibleLines": 3,
                "placeholder": "Add a comment here...",
                "skin": "sknTxtAreaffffff",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "width": "88%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxCommentsLayout.add(flxNames, txtComments);
            flxSeventhRow.add(flxCommentsLayout);
            flxComment.add(flxSixthRow, flxSeventhRow);
            var flxSubmitted = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSubmitted",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubmitted.setDefaultUnit(kony.flex.DP);
            var flxSubmittedFilesHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSubmittedFilesHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubmittedFilesHeading.setDefaultUnit(kony.flex.DP);
            var flxHeading = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeading",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeading.setDefaultUnit(kony.flex.DP);
            var lblSubmitted = new kony.ui.Label({
                "id": "lblSubmitted",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl13px666666",
                "text": "Submitted Files",
                "top": "0",
                "width": "15%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDownloadAllMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDownloadAllMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "reverseLayoutDirection": false,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0dp",
                "width": "50%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadAllMain.setDefaultUnit(kony.flex.DP);
            var imgDownload = new kony.ui.Image2({
                "height": "16dp",
                "id": "imgDownload",
                "isVisible": true,
                "right": "95dp",
                "skin": "slImage",
                "src": "download.png",
                "top": "0",
                "width": "16dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDownloadAll = new kony.ui.Label({
                "id": "lblDownloadAll",
                "isVisible": true,
                "right": "0dp",
                "skin": "sknlbl41106213px",
                "text": "Download All",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownloadAllMain.add(imgDownload, lblDownloadAll);
            flxHeading.add(lblSubmitted, flxDownloadAllMain);
            flxSubmittedFilesHeading.add(flxHeading);
            var flxApplicantFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxApplicantFiles",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFiles.setDefaultUnit(kony.flex.DP);
            var flxRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow1.setDefaultUnit(kony.flex.DP);
            var flxApplicantFile1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxApplicantFile1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFile1.setDefaultUnit(kony.flex.DP);
            var imgApplicantFIleType1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgApplicantFIleType1",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApplicantFileName1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxApplicantFileName1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFileName1.setDefaultUnit(kony.flex.DP);
            var lblApplicantFileName1 = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblApplicantFileName1",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknlbl000000opacity80",
                "text": "File 1",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFileName1.add(lblApplicantFileName1);
            var imgDownloadFile1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDownloadFile1",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "download.png",
                "top": "0",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFile1.add(imgApplicantFIleType1, flxApplicantFileName1, imgDownloadFile1);
            var flxApplicantFile2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxApplicantFile2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFile2.setDefaultUnit(kony.flex.DP);
            var imgApplicantFIleType2 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgApplicantFIleType2",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApplicantFileName2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxApplicantFileName2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFileName2.setDefaultUnit(kony.flex.DP);
            var lblApplicantFileName2 = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblApplicantFileName2",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknlbl000000opacity80",
                "text": "File 2",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFileName2.add(lblApplicantFileName2);
            var imgDownloadFile2 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDownloadFile2",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "download.png",
                "top": "0",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFile2.add(imgApplicantFIleType2, flxApplicantFileName2, imgDownloadFile2);
            flxRow1.add(flxApplicantFile1, flxApplicantFile2);
            var flxRow2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxRow2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "top": "13dp",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow2.setDefaultUnit(kony.flex.DP);
            var imgApplicantFIleType3 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgApplicantFIleType3",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApplicantFileName3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxApplicantFileName3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFileName3.setDefaultUnit(kony.flex.DP);
            var lblApplicantFileName3 = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblApplicantFileName3",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknlbl000000opacity80",
                "text": "File 3",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFileName3.add(lblApplicantFileName3);
            var imgDownloadFile3 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDownloadFile3",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "download.png",
                "top": "0",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRow2.add(imgApplicantFIleType3, flxApplicantFileName3, imgDownloadFile3);
            flxApplicantFiles.add(flxRow1, flxRow2);
            flxSubmitted.add(flxSubmittedFilesHeading, flxApplicantFiles);
            var flxEightRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEightRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxEightRow.setDefaultUnit(kony.flex.DP);
            var flxAttachFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAttachFiles",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "5%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAttachFiles.setDefaultUnit(kony.flex.DP);
            var imgAttachFiles = new kony.ui.Image2({
                "height": "15dp",
                "id": "imgAttachFiles",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "imagedrag.png",
                "top": "0",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAttachFilesContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAttachFilesContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "10dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "150dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAttachFilesContent.setDefaultUnit(kony.flex.DP);
            var lblAttachFiles = new kony.ui.Label({
                "id": "lblAttachFiles",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknLblcccccc",
                "text": "Attach Files",
                "top": "0",
                "width": "90dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAttachFilesBar = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxAttachFilesBar",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknFlxDarkPurple",
                "top": "0",
                "width": "90dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAttachFilesBar.setDefaultUnit(kony.flex.DP);
            flxAttachFilesBar.add();
            flxAttachFilesContent.add(lblAttachFiles, flxAttachFilesBar);
            flxAttachFiles.add(imgAttachFiles, flxAttachFilesContent);
            var flxsubmit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxsubmit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": 0,
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxsubmit.setDefaultUnit(kony.flex.DP);
            var flxPost = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "42dp",
                "id": "flxPost",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "16dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "89dp",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPost.setDefaultUnit(kony.flex.DP);
            var btnPost = new kony.ui.Button({
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "42dp",
                "id": "btnPost",
                "isVisible": true,
                "right": "0",
                "skin": "sknbtnprimaryFFFFFF411062",
                "text": "Post",
                "top": "0",
                "width": "89dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPost = new kony.ui.Image2({
                "centerY": "50%",
                "id": "imgPost",
                "isVisible": true,
                "right": "14dp",
                "skin": "slImage",
                "src": "post.png",
                "top": "0",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPost.add(btnPost, imgPost);
            var btnSubmit = new kony.ui.Button({
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "42dp",
                "id": "btnSubmit",
                "isVisible": true,
                "left": "16dp",
                "right": "0",
                "skin": "sknbtnprimaryFFFFFF411062",
                "text": "Submit",
                "top": "0",
                "width": "131dp",
                "zIndex": 2
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var DropDown = new com.evaluationPortal.dropDown.DropDown({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "44dp",
                "id": "DropDown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "33%",
                "zIndex": 2,
                "appName": "EPOLBRelease",
                "overrides": {
                    "DropDown": {
                        "isVisible": true,
                        "left": "viz.val_cleared",
                        "width": "33%",
                        "zIndex": 2
                    },
                    "flxDopDownHeader": {
                        "zIndex": 2
                    },
                    "flxDropDownValues": {
                        "isVisible": false,
                        "zIndex": 2
                    },
                    "imgDropdownArrow": {
                        "src": "polygon_6.png",
                        "zIndex": 2
                    },
                    "segDropDown": {
                        "data": [{
                            "lblFilter": "Approved"
                        }, {
                            "lblFilter": "Rejected"
                        }, {
                            "lblFilter": "In-Progress"
                        }],
                        "zIndex": 2
                    },
                    "txtBoxDropDown": {
                        "placeholder": "Select assessment status",
                        "zIndex": 2
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxsubmit.add(flxPost, btnSubmit, DropDown);
            flxEightRow.add(flxAttachFiles, flxsubmit);
            var flxNinethRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNinethRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNinethRow.setDefaultUnit(kony.flex.DP);
            var flxChatContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxChatContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "maxHeight": "500dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxChatContent.setDefaultUnit(kony.flex.DP);
            var flxChatMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChatMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxChatMain.setDefaultUnit(kony.flex.DP);
            var chatBoxContents = new com.evaluationPortal.chat.chatBoxContents({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "chatBoxContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "chatBoxContents": {
                        "isVisible": true,
                        "left": "0dp",
                        "width": kony.flex.USE_PREFFERED_SIZE
                    },
                    "segchatBoxContents": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxChatMain.add(chatBoxContents);
            flxChatContent.add(flxChatMain);
            flxNinethRow.add(flxChatContent);
            var flxCancel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCancel",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancel.setDefaultUnit(kony.flex.DP);
            var btnCancel = new kony.ui.Button({
                "focusSkin": "sknbtnsecondaryFFFFFF411062",
                "height": "42dp",
                "id": "btnCancel",
                "isVisible": true,
                "right": "0%",
                "skin": "sknbtnsecondaryFFFFFF411062",
                "text": "Cancel",
                "top": "0",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCancel.add(btnCancel);
            var flxSpace = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxSpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace.setDefaultUnit(kony.flex.DP);
            flxSpace.add();
            flxMainContent.add(flxFirstRow, flxSecondRow, flxThirdRow, flxAssessment, flxComment, flxSubmitted, flxEightRow, flxNinethRow, flxCancel, flxSpace);
            flxMainContents.add(flxMainContent);
            flxMainData.add(flxMainContents);
            flxLeftContainer.add(flxAssessmentTitle, flxMainData);
            var flxRightContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "250dp",
                "id": "flxRightContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "25%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks1": {
                        "isVisible": true
                    },
                    "flxQuickLinks2": {
                        "isVisible": false
                    },
                    "flxQuickLinks3": {
                        "isVisible": false
                    },
                    "flxQuickLinks4": {
                        "isVisible": false
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "map_solid.png"
                    },
                    "imgQuickLinks3": {
                        "src": "managerole.png"
                    },
                    "imgQuickLinks4": {
                        "src": "managerole.png"
                    },
                    "lblQuickLinks1": {
                        "text": "Manage Assigned Assessments"
                    },
                    "lblQuickLinks2": {
                        "text": "Map Assessment"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightContainer.add(flxQuickLinks);
            flxContainer.add(flxLeftContainer, flxRightContainer);
            var flxAssessmentStatusPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentStatusPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "41%",
                "isModalContainer": false,
                "skin": "sknflxShadow",
                "top": "765dp",
                "width": "250dp",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentStatusPopup.setDefaultUnit(kony.flex.DP);
            var segAssessmentStatus = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}],
                "groupCells": false,
                "id": "segAssessmentStatus",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxFilterPopup",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssessmentStatusPopup.add(segAssessmentStatus);
            flxMainLayout.add(flxBreadcrum, flxContainer, flxAssessmentStatusPopup);
            var flxFooterMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooterMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxfooter",
                "top": "3%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterMenu.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "appFooter": {
                        "top": "0dp"
                    },
                    "btnCreateAssessment": {
                        "isVisible": false
                    },
                    "btnDeleteAssessment": {
                        "isVisible": false
                    },
                    "btnManageAssessment": {
                        "isVisible": false,
                        "text": "Manage Assigned Assesments"
                    },
                    "btnMapAssessment": {
                        "isVisible": true,
                        "text": "Manage Assigned Assesments"
                    },
                    "flxRoleManagement": {
                        "isVisible": false
                    },
                    "flxUserManagement": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "copyrightFooter": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooterMenu.add(appFooter, copyrightFooter);
            flxMiddleScroll.add(flxMainLayout, flxFooterMenu);
            flxMainContentLayout.add(flxMiddleScroll);
            flxMain.add(flxHeader, flxMainContentLayout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew.flxUserRoleName": {
                    "centerY": "",
                    "top": "35%"
                },
                "headerNew": {
                    "height": "100%"
                },
                "headerNew.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew.imgUserImage": {
                    "src": "userimg.png"
                },
                "BreadCrum.flxBreadcrum": {
                    "height": "100%"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "height": "100%",
                    "src": "home_solid.png",
                    "width": "1%"
                },
                "BreadCrum.lblBreadcrum1": {
                    "text": "Manage Assessment"
                },
                "DropDown": {
                    "left": "",
                    "width": "33%",
                    "zIndex": 2
                },
                "DropDown.flxDopDownHeader": {
                    "zIndex": 2
                },
                "DropDown.flxDropDownValues": {
                    "zIndex": 2
                },
                "DropDown.imgDropdownArrow": {
                    "src": "polygon_6.png",
                    "zIndex": 2
                },
                "DropDown.segDropDown": {
                    "data": [{
                        "lblFilter": "Approved"
                    }, {
                        "lblFilter": "Rejected"
                    }, {
                        "lblFilter": "In-Progress"
                    }],
                    "zIndex": 2
                },
                "DropDown.txtBoxDropDown": {
                    "zIndex": 2
                },
                "chatBoxContents": {
                    "left": "0dp",
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "chatBoxContents.segchatBoxContents": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "map_solid.png"
                },
                "flxQuickLinks.imgQuickLinks3": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.imgQuickLinks4": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "Manage Assigned Assessments"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Map Assessment"
                },
                "appFooter": {
                    "top": "0dp"
                },
                "appFooter.btnManageAssessment": {
                    "text": "Manage Assigned Assesments"
                },
                "appFooter.btnMapAssessment": {
                    "text": "Manage Assigned Assesments"
                },
                "copyrightFooter": {
                    "centerY": "",
                    "top": "0dp"
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmApprovalAssessment,
            "enabledForIdleTimeout": false,
            "id": "frmApprovalAssessment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknfrmbgimg",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});