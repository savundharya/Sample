var AssessmentFile = "";
define("AdminFlow/userfrmCreateAssessmentController", ["AppToolBox", "Utils", "animations"], (AppToolBox, Utils, animations) => ({
    onNavigate: function(flowType) {
        this.view.preShow = this.preShow(flowType);
        this.view.postShow = this.postShow;
    },
    postShow: function() {
        //this.view.msgContainer.showMessage(this.view.flxMessageContainer,this);
    },
    preShow: function(flowType) {
        var scope = this;
        scope.view.onDeviceBack = function() {};
        let assessmentDetails = AppToolBox.store.getItem("AsseesmentDetails");
        this.view.txtBoxAssessmentName.restrictCharactersSet = "~#^|$%&*!@_-=+/?<>{}:;,.`[]'()^[^\"]*$^[^\\]*$";
        //this.view.txtBoxAssessmentInstructions.restrictCharactersSet = "~#^|$%&*!@_-=+/?<>{}:;,`[]'()^[^\"]*$^[^\\]*$";
        this.view.txtBoxAssessmentDuration.restrictCharactersSet = "~#^|$%&*!@_-=+/?<>`{}':;,.[]() qwertyuiopasdfghjklzxcvbnmABCDEFGHIJKLMNOPQRSTUVWXYZ^[^\"]*$^[^\\]*$";
        this.view.txtBoxAssessmentDuration.maxTextLength = 4;
        this.view.txtBoxAssessmentName.skin = "skntxtcccccc8pxradiusfff";
        this.view.txtBoxAssessmentInstructions.skin = "skntxtdescfffccc8pxradius";
        this.view.txtBoxAssessmentDuration.skin = "skntxtcccccc8pxradiusfff";
        this.view.DropDown.txtBoxDropDown.skin = "skntxtcccccc8pxradiusfff";
        this.view.flxDropFiles.setEnabled(true);
        this.view.flxQuickLinks.flxQuickLinks1.onClick = this.navigateToFormParams.bind(this, "frmCreateAssessment", "create");
        this.view.flxQuickLinks.flxQuickLinks2.onClick = this.navigateToForm.bind(this, "frmAdminMapAssessment");
        this.view.flxQuickLinks.flxQuickLinks3.onTouchStart = this.navigateToForm.bind(this, "frmManageAssessment");
        this.view.DropDown.flxDropDownValues.isVisible = false;
        this.view.txtBoxAssessmentName.onTextChange = this.checkAllEntries;
        this.view.txtBoxAssessmentInstructions.onTextChange = this.checkAllEntries;
        this.view.txtBoxAssessmentDuration.onTextChange = this.checkAllEntries;
        this.view.btnCancel.onClick = () => {
            const nav = new kony.mvc.Navigation('frmManageAssessment');
            nav.navigate()
        };
        this.view.lblUploadedFileName1.text = "Assessment File";
        this.view.DropDown.reset();
        this.view.btnDelete.setVisibility(true);
        this.view.btnCancel.left = "46%";
        if (flowType === "create") {
            this.reset();
            kony.application.showLoadingScreen();
            this.setRole();
            this.view.DropDown.segDropDown.onRowClick = () => {
                this.view.DropDown.setTxtBoxValue();
            };
            this.view.lblCreateAssessment.text = kony.i18n.getLocalizedString("i18n.adminFlow.createAssessment");
            this.view.flxQuickLinks.flxQuickLinks1.isVisible = false;
            this.view.txtBoxAssessmentName.setEnabled(true);
            this.view.txtBoxAssessmentDuration.setEnabled(true);
            this.view.txtBoxAssessmentInstructions.setEnabled(true);
            this.view.btnDelete.onClick = this.initiateAddAssessment;
            this.view.flxDropFiles.onTouchStart = this.uploadFile;
            this.view.msgContainer.imgClose.onTouchStart = this.hideMessage;
        } else if (flowType === "view") {
            this.viewAssessment(assessmentDetails);
        } else if (flowType === "edit") {
            this.editAssessment(assessmentDetails);
        }
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navToDash.bind(this);
    },
    navToDash: function() {
        AppToolBox.navigation.navigateTo("frmAdminDash");
    },
    hideMessage: function() {
        animations.hideMessage(this.view.flxMessageContainer);
    },
    navigateToForm: function(frmName) {
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.navigateTo(frmName);
    },
    navigateToFormParams: function(formName, flow) {
        let nav = new kony.mvc.Navigation(formName);
        nav.navigate(flow);
    },
    uploadFile: function() {
        var scope = this;
        var config = {
            selectMultipleFiles: true,
            filter: ["application/zip"]
        };
        kony.io.FileSystem.browse(config, scope.browseFiles1Callback);
    },
    reset: function() {
        this.view.txtBoxAssessmentName.text = "";
        this.view.txtBoxAssessmentInstructions.text = "";
        this.view.txtBoxAssessmentDuration.text = "";
        this.view.DropDown.txtBoxDropDown.text = "Select a Role";
        this.view.flxUploadedFiles1.isVisible = false;
        this.view.flxUploadedFiles2.isVisible = false;
        this.view.flxUploadedFiles3.isVisible = false;
        this.checkAllEntries();
        AssessmentFile = "";
        kony.application.dismissLoadingScreen();
    },
    setRole: function() {
        var roles = AppToolBox.store.getItem("userRolesResponse");
        var dataLst = [];
        var dataMap = {
            lblFilter: "lblFilter"
        };
        for (var i = 0; i < roles.length; i++) {
            if (roles[i].ID !== "ADMIN" && roles[i].ID !== "EVALUATOR") {
                var data = {
                    lblFilter: roles[i].RoleName.replace("_", " "),
                    ID: roles[i].ID
                };
                dataLst.push(data);
            }
        }
        this.view.DropDown.setValues(dataMap, dataLst);
        kony.application.dismissLoadingScreen();
    },
    initiateAddAssessment: function() {
        var scope = this;
        kony.application.showLoadingScreen();
        var AssessmentName = this.view.txtBoxAssessmentName.text;
        var ID = AssessmentName.toUpperCase().split(' ').join('_');
        this.checkAllID(ID);
        //this.addAssessmentRole();
    },
    checkAllID: function(ID) {
        var params = {
            "Filter": "ID eq " + ID,
            "FlowType": "CheckID"
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.fetchAssessmentsName(params);
    },
    showIDExists: function(Msg) {
        if (Msg !== "") {
            this.view.msgContainer.setMessage(Msg);
            this.view.msgContainer.flxMessageContainer.skin = "sknflxF37070error";
            this.view.msgContainer.showMessage(this.view.flxMessageContainer, this);
            kony.application.dismissLoadingScreen();
        } else {
            //this.view.lblerrMsg.isVisible = false;
            this.addAssessment();
        }
    },
    addAssessment: function() {
        var AssessmentName = this.view.txtBoxAssessmentName.text;
        var ID = AssessmentName.toUpperCase().split(' ').join('_');
        var params = {
            "ID": ID,
            "AssessmentName": AssessmentName,
            "AssessmentInstructions": this.view.txtBoxAssessmentInstructions.text,
            "FormDetails": "frmCreateAssessment"
        };
        var EvaluatorModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("EvaluatorModule");
        EvaluatorModule.presentationController.createAssessment(params);
    },
    resetUpload: function(scopeObj) {
        scopeObj.view.flxUploadStatus1.isVisible = true;
        scopeObj.view.flxUploadStatusGreen1.width = "0%";
        scopeObj.view.flxUploadedDetails1.height = "60%";
    },
    browseFiles1Callback: function(event, fileArray) {
        var scopeObj = this;
        var base64 = "";
        scopeObj.view.lblUploadedFileName1.text = fileArray[0].name;
        scopeObj.resetUpload(scopeObj);
        scopeObj.view.lblUploadedFileName1.centerY = "26%";
        scopeObj.view.flxUploadedFiles1.setVisibility(true);
        scopeObj.view.imgDelete1.src = "x__1_.png";
        scopeObj.view.imgDelete1.onTouchStart = function() {
            scopeObj.resetUpload(scopeObj);
            scopeObj.view.lblUploadedFileName1.centerY = "50%";
            scopeObj.view.flxUploadedFiles1.setVisibility(false);
            AssessmentFile = "";
            scopeObj.checkAllEntries();
        };
        Utils.convertAlltoBase64(fileArray, function(base64Array) {
            base64 = base64Array[0];
            animations.uploadSlide(scopeObj, scopeObj.view.flxUploadStatusGreen1);
            AssessmentFile = base64;
            scopeObj.checkAllEntries();
        });
    },
    animationCallbackFn: function() {
        this.view.flxUploadStatus1.isVisible = false;
        this.view.lblUploadedFileName1.top = "50%";
        this.view.flxUploadedDetails1.height = "40%";
        this.view.flxUploadStatusGreen1.width = "0%";
        //this.view.flxUploadedFiles1.isVisible = true;
        this.view.imgDelete1.src = "delete_solid.png";
    },
    addAssessFile: function() {
        var params = {
            "AssessmentID": this.view.txtBoxAssessmentName.text.toUpperCase().split(' ').join('_'),
            "AssessmentFile": AssessmentFile,
        };
        var AppFileMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ApplicationFileModule");
        AppFileMod.presentationController.createAssessFile(params);
    },
    addAssessmentRole: function() {
        var params = {
            "RoleID": this.view.DropDown.getSelected().ID.toUpperCase().split(' ').join('_'),
            "AssessmentID": this.view.txtBoxAssessmentName.text.toUpperCase().split(' ').join('_'),
            "Duration": this.view.txtBoxAssessmentDuration.text,
        };
        var EvaluatorModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("EvaluatorModule");
        EvaluatorModule.presentationController.createAssessmentUserRole(params);
    },
    checkAllEntries: function() {
        if (!AppToolBox.util.isNil(this.view.txtBoxAssessmentName.text) && !AppToolBox.util.isNil(this.view.txtBoxAssessmentInstructions.text) && !AppToolBox.util.isNil(this.view.txtBoxAssessmentDuration.text) && this.view.txtBoxAssessmentDuration.text > 0 && this.view.DropDown.txtBoxDropDown.text !== "Select a Role") {
            if (AssessmentFile !== "" || !AppToolBox.util.isNil(AssessFile)) {
                this.view.btnDelete.setEnabled(true);
                this.view.btnDelete.skin = "sknbtnprimaryFFFFFF411062";
            } else {
                this.view.btnDelete.setEnabled(false);
                this.view.btnDelete.skin = "sknbtndisabledeee666";
            }
        } else {
            this.view.btnDelete.setEnabled(false);
            this.view.btnDelete.skin = "sknbtndisabledeee666";
        }
    },
    viewAssessment: function(assessmentDetails) {
        this.view.txtBoxAssessmentName.text = assessmentDetails.AssessmentName;
        this.view.txtBoxAssessmentDuration.text = assessmentDetails.Duration;
        this.view.txtBoxAssessmentInstructions.text = assessmentDetails.AssessmentInstruction;
        this.view.DropDown.txtBoxDropDown.text = assessmentDetails.Role;
        this.view.lblCreateAssessment.text = kony.i18n.getLocalizedString("i18n.AdminFlow.viewAssessment");
        this.view.txtBoxAssessmentName.setEnabled(false);
        this.view.txtBoxAssessmentDuration.setEnabled(false);
        this.view.txtBoxAssessmentInstructions.setEnabled(false);
        this.view.DropDown.txtBoxDropDown.setEnabled(false);
        this.view.txtBoxAssessmentName.skin = "skntxteeedisabled";
        this.view.txtBoxAssessmentDuration.skin = "skntxteeedisabled";
        this.view.txtBoxAssessmentInstructions.skin = "skntxtareaF4F4F4disabled";
        this.view.DropDown.txtBoxDropDown.skin = "skntxteeedisabled";
        this.view.imgDelete1.src = "download.png";
        this.view.imgDelete1.onTouchStart = this.downloadKit;
        if (!AppToolBox.util.isNil(AssessFile)) {
            this.view.flxUploadedFiles1.setVisibility(true);
        } else {
            this.view.flxUploadedFiles1.setVisibility(false);
        }
        this.view.flxDropFiles.setEnabled(false);
        this.view.btnDelete.setVisibility(false);
        this.view.btnCancel.left = "71%";
        this.view.flxUploadStatus1.setVisibility(false);
        this.view.flxUploadedFiles2.setVisibility(false);
        this.view.flxUploadedFiles3.setVisibility(false);
    },
    editAssessment: function(assessmentDetails) {
        this.view.txtBoxAssessmentName.text = assessmentDetails.AssessmentName;
        this.view.txtBoxAssessmentDuration.text = assessmentDetails.Duration;
        this.view.txtBoxAssessmentInstructions.text = assessmentDetails.AssessmentInstruction;
        this.view.DropDown.txtBoxDropDown.text = assessmentDetails.Role;
        this.view.lblCreateAssessment.text = kony.i18n.getLocalizedString("i18n.AdminFlow.editAssessment");
        this.view.txtBoxAssessmentName.setEnabled(true);
        this.view.txtBoxAssessmentDuration.setEnabled(false);
        this.view.txtBoxAssessmentInstructions.setEnabled(true);
        this.view.txtBoxAssessmentDuration.skin = "skntxteeedisabled";
        this.view.DropDown.txtBoxDropDown.setEnabled(false);
        this.view.DropDown.txtBoxDropDown.skin = "skntxteeedisabled";
        this.view.imgDelete1.src = "delete_solid.png";
        //this.view.flxUploadedDetails1.onTouchStart= this.downloadKit;
        if (!AppToolBox.util.isNil(AssessFile)) {
            this.view.flxUploadedFiles1.setVisibility(true);
        } else {
            this.view.flxUploadedFiles1.setVisibility(false);
        }
        this.view.flxUploadStatus1.setVisibility(false);
        this.view.flxUploadedFiles2.setVisibility(false);
        this.view.flxUploadedFiles3.setVisibility(false);
        this.view.flxDropFiles.onTouchStart = this.uploadFile;
        this.view.btnDelete.skin = "sknbtndisabledeee666";
        this.view.btnDelete.setEnabled(false);
        this.view.btnDelete.text = "SUBMIT";
        this.view.btnDelete.onClick = this.updateAssessmentDetails;
        this.view.imgDelete1.onTouchStart = this.setFile;
        this.view.txtBoxAssessmentName.onTextChange = this.changeBtnSkin;
        this.view.txtBoxAssessmentInstructions.onTextChange = this.changeBtnSkin;
    },
    changeBtnSkin: function() {
        this.view.btnDelete.skin = "skncreatebtn";
        this.view.btnDelete.setEnabled(true);
        this.checkAllEntries();
    },
    downloadKit: function() {
        Utils.ConvertBlobToFile(AssessFile, "Assessment File");
    },
    setFile: function() {
        this.view.flxUploadedFiles1.setVisibility(false);
        AssessFile = "";
        AssessmentFile = "";
        this.changeBtnSkin();
    },
    updateAssessFile: function() {
        let assessmentDetails = AppToolBox.store.getItem("AsseesmentDetails");
        if (this.view.flxUploadedFiles1.isVisible === false && this.view.flxUploadedFiles3.isVisible === false) {
            AssessmentFile = "";
        }
        var params = {
            "AssessmentID": assessmentDetails.AssessmentID,
            "AssessmentFile": AssessmentFile,
            "flow": "create"
        };
        var AppFileMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ApplicationFileModule");
        AppFileMod.presentationController.updateAssessFile(params);
    },
    updateAssessmentDetails: function() {
        let assessmentDetails = AppToolBox.store.getItem("AsseesmentDetails");
        var params = {
            "ID": assessmentDetails.AssessmentID,
            "AssessmentName": this.view.txtBoxAssessmentName.text,
            "AssessmentInstructions": this.view.txtBoxAssessmentInstructions.text
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.updateAssessment(params);
    },
    displayMsg: function(Msg) {
        var scope = this;
        //this.reset();
        scope.view.msgContainer.setMessage(Msg);
        scope.view.msgContainer.flxMessageContainer.skin = "sknmessagepop";
        scope.view.msgContainer.showMessage(scope.view.flxMessageContainer, scope);
    },
    navToHome: function() {
        this.view.BreadCrum.navigateToHome(AppToolBox);
    },
    displayErrorMsg: function(errMsg) {
        var scope = this;
        scope.view.msgContainer.setMessage(errMsg);
        scope.view.msgContainer.flxMessageContainer.skin = "sknflxF37070error";
        scope.view.msgContainer.showMessage(scope.view.flxMessageContainer, scope);
    }
}));
define("AdminFlow/frmCreateAssessmentControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_ee83d1b8d89043aa840e2731ae739d89: function AS_Form_ee83d1b8d89043aa840e2731ae739d89(eventobject) {
        var self = this;
    }
});
define("AdminFlow/frmCreateAssessmentController", ["AdminFlow/userfrmCreateAssessmentController", "AdminFlow/frmCreateAssessmentControllerActions"], function() {
    var controller = require("AdminFlow/userfrmCreateAssessmentController");
    var controllerActions = ["AdminFlow/frmCreateAssessmentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
