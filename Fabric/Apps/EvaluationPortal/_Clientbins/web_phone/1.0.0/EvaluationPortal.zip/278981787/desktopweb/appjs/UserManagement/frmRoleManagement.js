define("UserManagement/frmRoleManagement", function() {
    return function(controller) {
        function addWidgetsfrmRoleManagement() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderNew = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeaderNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 3,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderNew.setDefaultUnit(kony.flex.DP);
            var headerNew1 = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxUserRoleName": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "35%"
                    },
                    "headerNew": {
                        "height": "100%",
                        "isVisible": true
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderNew.add(headerNew1);
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": false,
                "height": "82%",
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxMessageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "7%",
                "id": "flxMessageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-13%",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageContainer.setDefaultUnit(kony.flex.DP);
            var msgContainer = new com.evaluationPortal.msgContainer.msgContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "msgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknmessagepop",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgClose": {
                        "src": "close_white_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMessageContainer.add(msgContainer);
            var flxBodyScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "0%",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxBodyScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyScroll.setDefaultUnit(kony.flex.DP);
            var flxBodyRole = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxBodyRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyRole.setDefaultUnit(kony.flex.DP);
            var flxBreadCrumbManageRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8%",
                "id": "flxBreadCrumbManageRole",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "28dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadCrumbManageRole.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false,
                        "src": "right_arrow_solid.png"
                    },
                    "imgHome": {
                        "src": "home_solid.png"
                    },
                    "lblBreadcrum1": {
                        "text": "Dashboard"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightQuicklinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRightQuicklinks",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40px",
                "width": "60%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightQuicklinks.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks": {
                        "left": "0dp"
                    },
                    "flxQuickLinks1": {
                        "zIndex": 2
                    },
                    "flxQuickLinks2": {
                        "isVisible": false
                    },
                    "flxQuickLinks3": {
                        "isVisible": false
                    },
                    "flxQuickLinks4": {
                        "isVisible": false
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "imgQuickLinks3": {
                        "src": "managerole.png"
                    },
                    "imgQuickLinks4": {
                        "src": "managerole.png"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Role"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage Role"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightQuicklinks.add(flxQuickLinks);
            flxBreadCrumbManageRole.add(BreadCrum, flxRightQuicklinks);
            var flxCreateRoleMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "88%",
                "id": "flxCreateRoleMain",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateRoleMain.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "75%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxTop.setDefaultUnit(kony.flex.DP);
            var lblCreateRole = new kony.ui.Label({
                "id": "lblCreateRole",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl000000font28px",
                "text": "Create Role",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTop.add(lblCreateRole);
            var flxCreateRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxfff15pxradius",
                "top": "21dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateRole.setDefaultUnit(kony.flex.DP);
            var flxCreateRoleContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "40dp",
                "clipBounds": false,
                "id": "flxCreateRoleContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateRoleContent.setDefaultUnit(kony.flex.DP);
            var flxAddRoleRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAddRoleRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "34dp",
                "width": "90%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRoleRow1.setDefaultUnit(kony.flex.DP);
            var flxColumn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxColumn1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn1.setDefaultUnit(kony.flex.DP);
            var lblRoleID = new kony.ui.Label({
                "id": "lblRoleID",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Role ID",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBoxRoleID = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtcccccc8pxradiusfff",
                "height": "44dp",
                "id": "txtBoxRoleID",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "skin": "skntxtcccccc8pxradiusfff",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxColumn1.add(lblRoleID, txtBoxRoleID);
            var flxColumn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxColumn2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn2.setDefaultUnit(kony.flex.DP);
            var lblRoleName = new kony.ui.Label({
                "id": "lblRoleName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Role Name",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBoxRoleName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtBoxRoleName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "skin": "skntxtcccccc8pxradiusfff",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxColumn2.add(lblRoleName, txtBoxRoleName);
            flxAddRoleRow1.add(flxColumn1, flxColumn2);
            var flxAddRoleRow2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAddRoleRow2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "90%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRoleRow2.setDefaultUnit(kony.flex.DP);
            var lblDescription = new kony.ui.Label({
                "id": "lblDescription",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Description",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtRoleDescription = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextAreaFocus",
                "height": "102dp",
                "id": "txtRoleDescription",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0dp",
                "numberOfVisibleLines": 3,
                "skin": "skntxtdescfffccc8pxradius",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxAddRoleRow2.add(lblDescription, txtRoleDescription);
            var flxAddRoleButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddRoleButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "40dp",
                "skin": "slFbox",
                "top": "4dp",
                "width": "32%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRoleButtons.setDefaultUnit(kony.flex.DP);
            var btnCreate = new kony.ui.Button({
                "bottom": "0dp",
                "centerY": "50dp",
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "40dp",
                "id": "btnCreate",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknbtnprimaryFFFFFF411062",
                "text": "Create",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "centerY": "50dp",
                "focusSkin": "sknbtnsecondaryFFFFFF411062",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "skin": "sknbtnsecondaryFFFFFF411062",
                "text": "Cancel",
                "top": "0",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddRoleButtons.add(btnCreate, btnCancel);
            flxCreateRoleContent.add(flxAddRoleRow1, flxAddRoleRow2, flxAddRoleButtons);
            flxCreateRole.add(flxCreateRoleContent);
            flxLeft.add(flxTop, flxCreateRole);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "25%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks1 = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks": {
                        "height": "100%"
                    },
                    "flxQuickLinks1": {
                        "width": "100%"
                    },
                    "flxQuickLinks2": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks3": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks4": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "lblQuickLinks": {
                        "top": "0dp"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Role"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage Role"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRight.add(flxQuickLinks1);
            flxCreateRoleMain.add(flxLeft, flxRight);
            var flxManageRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "88%",
                "id": "flxManageRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageRole.setDefaultUnit(kony.flex.DP);
            var flxLeftManageRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeftManageRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "75%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftManageRole.setDefaultUnit(kony.flex.DP);
            var flxTopManageRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTopManageRole",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopManageRole.setDefaultUnit(kony.flex.DP);
            var lblManageRole = new kony.ui.Label({
                "id": "lblManageRole",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl000000font28px",
                "text": "Manage Role",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopManageRole.add(lblManageRole);
            var flxManageRoleBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "80%",
                "id": "flxManageRoleBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "21dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageRoleBody.setDefaultUnit(kony.flex.DP);
            var segManageRoles = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [
                    [{
                            "imgSortActions": "sort_down_solid.png",
                            "imgSortDuration": "sort_down_solid.png",
                            "imgSortName": "sort_down_solid.png",
                            "imgSortRole": "sort_down_solid.png",
                            "lblActions": "ACTION",
                            "lblRoleDescriptionHeader": "ROLE DESCRIPTION",
                            "lblRoleIDHeader": "ROLE ID",
                            "lblRoleNameHeader": "ROLE NAME"
                        },
                        [{
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "RoleId": "Button",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblEditRole": "Edit",
                            "lblRoleDescription": "Label",
                            "lblRoleID": "Label",
                            "lblRoleName": "Label",
                            "lblViewRole": "View"
                        }]
                    ]
                ],
                "groupCells": false,
                "height": "100%",
                "id": "segManageRoles",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknflxnofff",
                "rowTemplate": "flxManageRoles",
                "sectionHeaderTemplate": "flxHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "RoleId": "RoleId",
                    "flxActions": "flxActions",
                    "flxEditRole": "flxEditRole",
                    "flxHeader": "flxHeader",
                    "flxManageRoles": "flxManageRoles",
                    "flxRoleDescription": "flxRoleDescription",
                    "flxRoleID": "flxRoleID",
                    "flxRoleName": "flxRoleName",
                    "flxRolesListHeader": "flxRolesListHeader",
                    "flxRows": "flxRows",
                    "flxSeparator": "flxSeparator",
                    "flxViewRole": "flxViewRole",
                    "imgEditRole": "imgEditRole",
                    "imgSortActions": "imgSortActions",
                    "imgSortDuration": "imgSortDuration",
                    "imgSortName": "imgSortName",
                    "imgSortRole": "imgSortRole",
                    "imgViewRole": "imgViewRole",
                    "lblActions": "lblActions",
                    "lblEditRole": "lblEditRole",
                    "lblRoleDescription": "lblRoleDescription",
                    "lblRoleDescriptionHeader": "lblRoleDescriptionHeader",
                    "lblRoleID": "lblRoleID",
                    "lblRoleIDHeader": "lblRoleIDHeader",
                    "lblRoleName": "lblRoleName",
                    "lblRoleNameHeader": "lblRoleNameHeader",
                    "lblViewRole": "lblViewRole"
                },
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxManageRoleBody.add(segManageRoles);
            flxLeftManageRole.add(flxTopManageRole, flxManageRoleBody);
            var flxRightManageRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRightManageRole",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "25%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightManageRole.setDefaultUnit(kony.flex.DP);
            var flxQuickLink = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLink",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks": {
                        "height": "100%"
                    },
                    "flxQuickLinks1": {
                        "width": "100%"
                    },
                    "flxQuickLinks2": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks3": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks4": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "lblQuickLinks": {
                        "top": "0dp"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Role"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage Role"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightManageRole.add(flxQuickLink);
            flxManageRole.add(flxLeftManageRole, flxRightManageRole);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "appFooter": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "copyrightFooter": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(appFooter, copyrightFooter);
            flxBodyRole.add(flxBreadCrumbManageRole, flxCreateRoleMain, flxManageRole, flxFooter);
            flxBodyScroll.add(flxBodyRole);
            flxMainContent.add(flxMessageContainer, flxBodyScroll);
            flxMainContainer.add(flxHeaderNew, flxMainContent);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew1.flxUserRoleName": {
                    "centerY": "",
                    "top": "35%"
                },
                "headerNew1": {
                    "height": "100%"
                },
                "headerNew1.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew1.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew1.imgUserImage": {
                    "src": "userimg.png"
                },
                "msgContainer.imgClose": {
                    "src": "close_white_solid.png"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgArrow2": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "src": "home_solid.png"
                },
                "BreadCrum.lblBreadcrum1": {
                    "text": "Dashboard"
                },
                "flxQuickLinks": {
                    "left": "0dp"
                },
                "flxQuickLinks.flxQuickLinks1": {
                    "zIndex": 2
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuickLinks.imgQuickLinks3": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.imgQuickLinks4": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "Create Role"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Manage Role"
                },
                "flxQuickLinks1": {
                    "height": "100%",
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks2": {
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks3": {
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks4": {
                    "width": "100%"
                },
                "flxQuickLinks1.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks1.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuickLinks1.lblQuickLinks": {
                    "top": "0dp"
                },
                "flxQuickLinks1.lblQuickLinks1": {
                    "text": "Create Role"
                },
                "flxQuickLinks1.lblQuickLinks2": {
                    "text": "Manage Role"
                },
                "flxQuickLink": {
                    "height": "100%"
                },
                "flxQuickLink.flxQuickLinks1": {
                    "width": "100%"
                },
                "flxQuickLink.flxQuickLinks2": {
                    "width": "100%"
                },
                "flxQuickLink.flxQuickLinks3": {
                    "width": "100%"
                },
                "flxQuickLink.flxQuickLinks4": {
                    "width": "100%"
                },
                "flxQuickLink.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLink.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuickLink.lblQuickLinks": {
                    "top": "0dp"
                },
                "flxQuickLink.lblQuickLinks1": {
                    "text": "Create Role"
                },
                "flxQuickLink.lblQuickLinks2": {
                    "text": "Manage Role"
                },
                "appFooter": {
                    "centerY": "",
                    "top": "0dp"
                },
                "copyrightFooter": {
                    "centerY": "",
                    "top": "0dp"
                }
            }
            this.add(flxMainContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmRoleManagement,
            "enabledForIdleTimeout": false,
            "id": "frmRoleManagement",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknfrmbgimg",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_b84482c8b10540829b68808a8e1e522b,
            "retainScrollPosition": false
        }]
    }
});