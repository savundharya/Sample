define("AdminFlow/frmViewAllAssessment", function() {
    return function(controller) {
        function addWidgetsfrmViewAllAssessment() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderNew = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeaderNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderNew.setDefaultUnit(kony.flex.DP);
            var headerNew1 = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxUserRoleName": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "35%"
                    },
                    "headerNew": {
                        "height": "100%",
                        "isVisible": true
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderNew.add(headerNew1);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "110dp",
                "id": "flxHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var headerNew = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "110dp",
                "id": "headerNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(headerNew);
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": false,
                "height": "82%",
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxBodyScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "0%",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxBodyScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyScroll.setDefaultUnit(kony.flex.DP);
            var flxBody = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBody.setDefaultUnit(kony.flex.DP);
            var flxBreadCrumbManageRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8%",
                "id": "flxBreadCrumbManageRole",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "28dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadCrumbManageRole.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false,
                        "src": "right_arrow_solid.png"
                    },
                    "imgHome": {
                        "src": "home_solid.png"
                    },
                    "lblBreadcrum1": {
                        "text": "Dashboard"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightQuicklinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRightQuicklinks",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40px",
                "width": "60%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightQuicklinks.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks": {
                        "left": "0dp"
                    },
                    "flxQuickLinks1": {
                        "zIndex": 2
                    },
                    "flxQuickLinks2": {
                        "isVisible": false
                    },
                    "flxQuickLinks3": {
                        "isVisible": false
                    },
                    "flxQuickLinks4": {
                        "isVisible": false
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "imgQuickLinks3": {
                        "src": "managerole.png"
                    },
                    "imgQuickLinks4": {
                        "src": "managerole.png"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Role"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage Role"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightQuicklinks.add(flxQuickLinks);
            flxBreadCrumbManageRole.add(BreadCrum, flxRightQuicklinks);
            var flxBodyMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "74%",
                "id": "flxBodyMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyMain.setDefaultUnit(kony.flex.DP);
            var lblManageRole1 = new kony.ui.Label({
                "id": "lblManageRole1",
                "isVisible": false,
                "left": "0%",
                "skin": "sknlbl000000font28px",
                "text": "Manage Role",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "90%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxTop.setDefaultUnit(kony.flex.DP);
            var lblManageRole = new kony.ui.Label({
                "id": "lblManageRole",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl000000font28px",
                "text": "View All Assessment",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDownloadReport = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDownloadReport",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0",
                "width": "50%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadReport.setDefaultUnit(kony.flex.DP);
            var lblDownloadReport = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDownloadReport",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl41106213px",
                "text": "Download Report",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgDownload = new kony.ui.Image2({
                "centerY": "50%",
                "height": "16dp",
                "id": "imgDownload",
                "isVisible": true,
                "left": "0",
                "right": "10dp",
                "skin": "slImage",
                "src": "download.png",
                "top": "0",
                "width": "16dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownloadReport.add(lblDownloadReport, imgDownload);
            flxTop.add(lblManageRole, flxDownloadReport);
            var flxManageAll = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxManageAll",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "maxHeight": "85%",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "21dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageAll.setDefaultUnit(kony.flex.DP);
            var segManageAllAssessment = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [
                    [{
                            "imgSortAssignee": "sort_down_solid.png",
                            "imgSortDuration": "sort_down_solid.png",
                            "imgSortName": "sort_down_solid.png",
                            "imgSortRole": "sort_down_solid.png",
                            "imgSortStatus": "sort_down_solid.png",
                            "lblAssessmentName": "ASSESSMENT NAME",
                            "lblAssigneeName": "ASSIGNEE NAME",
                            "lblDuration": "DURATION",
                            "lblRole": "ROLE",
                            "lblStatus": "STATUS"
                        },
                        [{
                            "btnAssessmentName": "btn",
                            "lblAssessmentName": "",
                            "lblAssigneeName": "",
                            "lblDuration": "",
                            "lblRole": "",
                            "lblStatus": ""
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segManageAllAssessment",
                "isVisible": true,
                "left": "0",
                "maxHeight": "300dp",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknflxnofff",
                "rowTemplate": "flxAssessmentList",
                "sectionHeaderTemplate": "flxAssessmentListHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnAssessmentName": "btnAssessmentName",
                    "flxAssessmentList": "flxAssessmentList",
                    "flxAssessmentListHeader": "flxAssessmentListHeader",
                    "flxAssessmentName": "flxAssessmentName",
                    "flxAssigneeName": "flxAssigneeName",
                    "flxDuration": "flxDuration",
                    "flxLabels": "flxLabels",
                    "flxRole": "flxRole",
                    "flxSeparator": "flxSeparator",
                    "flxStatus": "flxStatus",
                    "flxgroupheaders": "flxgroupheaders",
                    "imgSortAssignee": "imgSortAssignee",
                    "imgSortDuration": "imgSortDuration",
                    "imgSortName": "imgSortName",
                    "imgSortRole": "imgSortRole",
                    "imgSortStatus": "imgSortStatus",
                    "lblAssessmentName": "lblAssessmentName",
                    "lblAssigneeName": "lblAssigneeName",
                    "lblDuration": "lblDuration",
                    "lblRole": "lblRole",
                    "lblStatus": "lblStatus"
                },
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxStatusFilterPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxStatusFilterPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "89%",
                "isModalContainer": false,
                "skin": "sknflxShadow",
                "top": "5dp",
                "width": "10%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatusFilterPopup.setDefaultUnit(kony.flex.DP);
            var segFilterStatus = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}],
                "groupCells": false,
                "id": "segFilterStatus",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxFilterPopup",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatusFilterPopup.add(segFilterStatus);
            var flxRoleFilterPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRoleFilterPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "68%",
                "isModalContainer": false,
                "skin": "sknflxShadow",
                "top": "5dp",
                "width": "18%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRoleFilterPopup.setDefaultUnit(kony.flex.DP);
            var segFilterRole = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}],
                "groupCells": false,
                "id": "segFilterRole",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxFilterPopup",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRoleFilterPopup.add(segFilterRole);
            flxManageAll.add(segManageAllAssessment, flxStatusFilterPopup, flxRoleFilterPopup);
            flxLeft.add(flxTop, flxManageAll);
            flxBodyMain.add(lblManageRole1, flxLeft);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "appFooter": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "copyrightFooter": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(appFooter, copyrightFooter);
            flxBody.add(flxBreadCrumbManageRole, flxBodyMain, flxFooter);
            flxBodyScroll.add(flxBody);
            flxMainContent.add(flxBodyScroll);
            flxMainContainer.add(flxHeaderNew, flxHeader, flxMainContent);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew1.flxUserRoleName": {
                    "centerY": "",
                    "top": "35%"
                },
                "headerNew1": {
                    "height": "100%"
                },
                "headerNew1.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew1.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew1.imgUserImage": {
                    "src": "userimg.png"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgArrow2": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "src": "home_solid.png"
                },
                "BreadCrum.lblBreadcrum1": {
                    "text": "Dashboard"
                },
                "flxQuickLinks": {
                    "left": "0dp"
                },
                "flxQuickLinks.flxQuickLinks1": {
                    "zIndex": 2
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuickLinks.imgQuickLinks3": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.imgQuickLinks4": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "Create Role"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Manage Role"
                },
                "appFooter": {
                    "centerY": "",
                    "top": "0dp"
                },
                "copyrightFooter": {
                    "centerY": "",
                    "top": "0dp"
                }
            }
            this.add(flxMainContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmViewAllAssessment,
            "enabledForIdleTimeout": false,
            "id": "frmViewAllAssessment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknfrmbgimg",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_a5c198ec78e9421a9a61b6db545e718c,
            "retainScrollPosition": false
        }]
    }
});