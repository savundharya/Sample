var userId = " ";
var roleIDValue;
var state;
define("UserManagement/userfrmUserManageController", ["AppToolBox", "animations"], (AppToolBox, animations) => ({
    onNavigate: function(flow) {
        this.view.preShow = this.preShow.bind(this, flow);
        this.view.postShow = this.postShow;
    },
    preShow: function(flow) {
        this.view.flxDropDownValues.setVisibility(false);
        this.view.lblManageUser.text = "Manage User";
        this.view.flxDopDownHeader.onClick = this.viewDropDowns;
        this.view.segDropDown.onRowClick = this.setTxtBoxValue;
        this.view.txtBoxDropDown.setEnabled(false);
        this.getAllUsers();
        this.view.flxQuicksLinks.flxQuickLinks1.isVisible = true;
        this.view.flxManageUser.isVisible = true;
        this.view.flxCreateUserMain.isVisible = false;
        this.view.flxQuicksLinks.flxQuickLinks1.onClick = this.createUser.bind(this);
        this.view.flxQuickLinks1.flxQuickLinks1.onClick = this.createUser.bind(this);
        this.view.flxQuickLinks1.flxQuickLinks2.onClick = this.preShow.bind(this);
        this.view.btnCreate.onClick = this.emailValidation.bind(this);
        this.view.btnEdit.onClick = this.emailValidation.bind(this);
        this.view.txtBoxUserName.onTextChange = this.fieldValidations.bind(this);
        this.view.txtBoxEmail.onTextChange = this.emailValueValidation.bind(this);
        this.view.btnCancel.onClick = this.onCancelClick.bind(this);
        //this.view.msgContainer.imgClose.onTouchStart = this.cancelAck.bind(this);
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navToBread.bind(this);
        this.view.msgContainer.imgClose.onTouchStart = this.hideMessage;
        this.view.msgContainer.flxMessageContainer.skin = "sknmessagepop";
        this.view.flxPopup1.btnDelete.onClick = () => {
            this.deactiveUser();
            this.view.flxPopup.isVisible = false;
        };
        this.view.flxPopup1.btnCancel.onClick = this.view.flxPopup1.imgClose.onTouchStart = () => {
            this.view.flxPopup.isVisible = false;
        };
        if (!AppToolBox.util.isNil(flow)) {
            if (flow === "addUser") {
                this.createUser();
            } else if (flow === "manageUser") {}
        }
    },
    hideMessage: function() {
        animations.hideMessage(this.view.flxMessageContainer);
    },
    navToBread: function() {
        if (this.view.BreadCrum.lblBreadcrum1.text === "Dashboard") {
            AppToolBox.navigation.navigateTo("frmAdminDash");
        } else if (this.view.BreadCrum.lblBreadcrum1.text === "Manage User") {
            AppToolBox.navigation.navigateTo("frmUserManage");
        }
    },
    setTxtBoxValue: function() {
        this.view.txtBoxDropDown.text = this.view.segDropDown.selectedRowItems[0].lblFilter;
        this.view.flxDropDownValues.isVisible = false;
        this.fieldValidations();
    },
    viewDropDowns: function() {
        if (this.view.flxDropDownValues.isVisible) {
            this.view.flxDropDownValues.isVisible = false;
        } else {
            this.view.flxDropDownValues.isVisible = true;
        }
    },
    createUser: function() {
        this.view.flxDropDownValues.setVisibility(false);
        state = "create";
        this.view.lblCreateRole.text = "Create User";
        this.view.BreadCrum.lblBreadcrum1.text = "Manage User";
        this.view.flxDopDownHeader.setEnabled(true);
        this.setRole();
        this.view.flxQuickLinks1.flxQuickLinks1.setVisibility(false);
        this.view.flxQuickLinks1.flxQuickLinks2.setVisibility(true);
        this.view.flxQuickLinks1.lblQuickLinks2.text = "Manage User";
        this.view.flxManageUser.isVisible = false;
        this.view.flxCreateUserMain.isVisible = true;
        this.view.txtBoxEmail.text = "";
        this.view.txtBoxUserName.text = "";
        this.view.txtBoxDropDown.text = "";
        this.view.btnCreate.setVisibility(true);
        this.view.btnEdit.setVisibility(false);
        this.view.flxDropDown.setVisibility(true);
        this.view.txtBoxUserName.setEnabled(true);
        this.view.txtBoxEmail.setEnabled(true);
        this.fieldValidations();
        this.view.lblInvalidEmail.isVisible = false;
        this.view.txtBoxUserName.skin = "skntxtcccccc8pxradiusfff";
        this.view.txtBoxEmail.skin = "skntxtcccccc8pxradiusfff";
        this.view.txtBoxDropDown.skin = "skntxtcccccc8pxradiusfff";
    },
    emailValidation: function() {
        var emailValue = this.view.txtBoxEmail.text;
        //var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        var validRegex = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if (emailValue.match(validRegex)) {
            this.storeUser();
        } else {
            //alert("false");
            this.view.lblInvalidEmail.isVisible = true;
        }
    },
    emailValueValidation: function() {
        if (this.view.lblInvalidEmail.isVisible === true) {
            this.view.lblInvalidEmail.isVisible = false;
        }
        this.fieldValidations();
    },
    onCancelClick: function() {
        this.view.txtBoxEmail.text = "";
        this.view.txtBoxUserName.text = "";
        //this.view.lstboxUserRole.selectedKey = "Placeholder";
        this.preShow();
    },
    cancelAck: function() {
        this.view.flxMessageContainer.isVisible = false;
    },
    storeUser: function() {
        var scope = this;
        var params;
        var roleID = this.view.txtBoxDropDown.text.toUpperCase();
        roleID = roleID.replace(" ", "_");
        var emailID = this.view.txtBoxEmail.text;
        var Name = this.view.txtBoxUserName.text;
        if (!AppToolBox.util.isNil(emailID) && !AppToolBox.util.isNil(Name) && !AppToolBox.util.isNil(roleID)) {
            kony.application.showLoadingScreen();
            if (state === "create") {
                const credentails = {
                    userName: emailID
                };
                let LoginMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("LoginModule");
                LoginMod.presentationController.login(credentails, this.getUserdetailsSC, this.getUserdetailsFC);
            } else if (state === "edit") {
                params = {
                    "Name": this.view.txtBoxUserName.text,
                    "ID": userId
                };
                var msg = Name + " has been edited Successfully";
                this.view.msgContainer.setMessage(msg);
                var DashBoardModule1 = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
                DashBoardModule1.presentationController.updateUser(params);
            }
        } else {
            //this.showMsg();
        }
    },
    getUserdetailsSC: function(response) {
        if (!AppToolBox.util.isNil(response) && AppToolBox.util.isNil(response.user)) {
            let roleID = this.view.txtBoxDropDown.text.toUpperCase();
            roleID = roleID.replace(" ", "_");
            const password = this.generatePasswd();
            let params = {
                "EmailID": this.view.txtBoxEmail.text,
                "Name": this.view.txtBoxUserName.text,
                "Password": password,
                "RoleID": roleID,
                "ID": userId
            };
            this.view.msgContainer.setMessage(`User ${this.view.txtBoxUserName.text} has been added Successfully`);
            var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
            DashBoardModule.presentationController.createUser(params);
        } else {
            kony.application.dismissLoadingScreen();
            this.showErr("EmailID already exists");
        }
    },
    getUserdetailsFC: function() {
        kony.application.dismissLoadingScreen();
        this.showErr("EmailID already exists");
    },
    ResetNewUser: function() {
        kony.application.dismissLoadingScreen();
        //this.view.flxMessageContainer.isVisible = true;
        this.view.msgContainer.showMessage(this.view.flxMessageContainer, this);
        this.preShow();
        //this.callTimer();
    },
    generatePasswd: function() {
        var length = 8,
            charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789",
            retVal = "";
        for (var i = 0, n = charset.length; i < length; ++i) {
            retVal += charset.charAt(Math.floor(Math.random() * n));
        }
        return retVal;
    },
    displayErrorMsg: function(errMsg) {
        kony.application.dismissLoadingScreen();
        this.view.msgContainer.setMessage(errMsg);
        this.view.msgContainer.showMessage(this.view.flxMessageContainer, this);
        //this.view.flxMessageContainer.isVisible = true;
        this.preShow();
        //this.callTimer();
    },
    showErr: function(errMsg) {
        const scope = this;
        scope.view.msgContainer.setMessage(errMsg);
        scope.view.msgContainer.showMessage(scope.view.flxMessageContainer, scope);
        scope.view.msgContainer.flxMessageContainer.skin = "sknflxF37070error";
        scope.view.msgContainer.skin = "sknflxF37070error";
    },
    callTimer: function() {
        kony.timer.schedule("timer4", this.timerCallBack, 5, false);
    },
    timerCallBack: function() {
        this.view.flxMessageContainer.isVisible = false;
    },
    setRole: function() {
        var allRoles = [];
        var dataMap = {
            "lblFilter": "lblFilter"
        };
        this.view.segDropDown.widgetDataMap = dataMap;
        var Role = AppToolBox.store.getItem("userRolesResponse");
        for (var i = 0; i < Role.length; i++) {
            if (!AppToolBox.util.isNil(Role[i]) && !AppToolBox.util.isNil(Role[i].RoleName)) {
                var role = Role[i].RoleName.replace("_", " ");
                var roles = {
                    lblFilter: role
                };
                allRoles.push(roles);
            }
        }
        this.view.segDropDown.setData(allRoles);
        kony.application.dismissLoadingScreen();
    },
    fieldValidations: function() {
        var userNameLength = this.view.txtBoxUserName.text.length;
        var emailLength = this.view.txtBoxEmail.text.length;
        // var selectedKeys = this.view.lstboxUserRole.selectedKey;
        var selectedKeys = this.view.txtBoxDropDown.text.length;
        if (userNameLength !== 0 && emailLength !== 0 && selectedKeys !== 0) {
            this.view.btnCreate.skin = "sknbtnprimaryFFFFFF411062";
            this.view.btnCreate.setEnabled(true);
            this.view.btnEdit.skin = "sknbtnprimaryFFFFFF411062";
            this.view.btnEdit.setEnabled(true);
        } else {
            this.view.btnCreate.skin = "sknbtnsecondaryFFFFFF411062";
            this.view.btnCreate.setEnabled(false);
            this.view.btnEdit.skin = "sknbtnsecondaryFFFFFF411062";
            this.view.btnEdit.setEnabled(false);
        }
    },
    getAllUsers: function() {
        var params = {};
        kony.application.showLoadingScreen();
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.fetchAllUsers(params);
    },
    viewUser: function() {
        this.view.flxDropDownValues.setVisibility(false);
        this.view.flxQuickLinks1.lblQuickLinks2.text = "Manage User";
        this.view.BreadCrum.lblBreadcrum1.text = "Manage User";
        this.view.flxDopDownHeader.setEnabled(false);
        this.view.flxManageUser.isVisible = false;
        this.view.flxCreateUserMain.isVisible = true;
        this.view.flxQuickLinks1.flxQuickLinks1.isVisible = true;
        this.view.flxQuickLinks1.flxQuickLinks2.isVisible = true;
        this.view.btnCreate.setVisibility(false);
        this.view.btnEdit.setVisibility(false);
        this.view.flxDropDown.setVisibility(true);
        this.view.txtBoxUserName.setEnabled(false);
        this.view.txtBoxEmail.setEnabled(false);
        var index = this.view.segManageUser.selectedRowIndex[1];
        var selectedData = this.view.segManageUser.selectedRowItems;
        this.view.lblCreateRole.text = "User Detail - " + selectedData[0].lblUserName;
        this.view.txtBoxUserName.text = selectedData[0].lblUserName;
        this.view.txtBoxEmail.text = selectedData[0].lblEmail;
        var roleName = selectedData[0].RoleName;
        this.view.txtBoxDropDown.text = selectedData[0].RoleName;
        this.view.txtBoxUserName.skin = "skntxteeedisabled";
        this.view.txtBoxEmail.skin = "skntxteeedisabled";
        this.view.txtBoxDropDown.skin = "skntxteeedisabled";
    },
    editUser: function() {
        this.view.txtBoxUserName.skin = "skntxtcccccc8pxradiusfff";
        this.view.txtBoxEmail.skin = "skntxteeedisabled";
        this.view.txtBoxDropDown.skin = "skntxteeedisabled";
        this.view.btnEdit.skin = "sknbtndisabledeee666";
        this.view.flxDropDownValues.setVisibility(false);
        state = "edit";
        this.view.flxQuickLinks1.lblQuickLinks2.text = "Manage User";
        this.view.BreadCrum.lblBreadcrum1.text = "Manage User";
        this.view.flxDopDownHeader.setEnabled(false);
        this.setRole();
        this.view.flxManageUser.isVisible = false;
        this.view.flxCreateUserMain.isVisible = true;
        this.view.flxQuickLinks1.flxQuickLinks1.isVisible = true;
        this.view.flxQuickLinks1.flxQuickLinks2.isVisible = true;
        this.view.btnCreate.setVisibility(false);
        this.view.btnEdit.setVisibility(true);
        this.view.txtBoxUserName.setEnabled(true);
        this.view.txtBoxEmail.setEnabled(false);
        var index = this.view.segManageUser.selectedRowIndex[1];
        var selectedData = this.view.segManageUser.selectedRowItems;
        this.view.lblCreateRole.text = "Edit User - " + selectedData[0].lblUserName;
        this.view.txtBoxUserName.text = selectedData[0].lblUserName;
        this.view.txtBoxEmail.text = selectedData[0].lblEmail;
        var selectedRoleID = roleIdValue[index].RoleID;
        userId = roleIdValue[index].ID;
        var roleName = selectedData[0].RoleName;
        this.view.txtBoxDropDown.text = selectedData[0].RoleName;
        this.view.lblInvalidEmail.isVisible = false;
        this.view.btnEdit.skin = "sknbtndisabledeee666";
        this.view.btnEdit.setEnabled(false);
    },
    deactivateUser: function() {
        this.view.flxPopup.isVisible = true;
    },
    deactiveUser: function() {
        AppToolBox.store.setItem("SelectedUser", this.view.segManageUser.selectedRowItems);
        var userID = this.view.segManageUser.selectedRowItems[0].ID;
        let params = {
            "ID": userID,
            "isActive": "false",
            "Flow": "DeactiveUser"
        };
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.updateUser(params);
    },
    showMsg: function() {
        this.preShow();
        var data = AppToolBox.store.getItem("SelectedUser");
        var msg = data[0].lblUserName + " user deactivated Successfully";
        this.view.msgContainer.setMessage(msg);
        this.view.msgContainer.showMessage(this.view.flxMessageContainer, this);
        //this.view.flxMessageContainer.isVisible = true;
        //this.callTimer();
    },
    setAllUsers: function(response) {
        var Users = [];
        var scopeObj = this;
        response.reverse();
        roleIdValue = response;
        var dataMap = {
            lblUserName: "lblUserName",
            lblEmail: "lblEmail",
            lblRoleName: "lblRoleName",
            lblAssessmentName: "lblAssessmentName",
            lblDuration: "lblDuration",
            lblRole: "lblRole",
            flxViewRole: "flxViewRole",
            flxEditRole: "flxEditRole",
            flxDeactiveUserbtn: "flxDeactivate"
        };
        this.view.segManageUser.widgetDataMap = dataMap;
        var Role = AppToolBox.store.getItem("userRolesResponse");
        var RoleName;
        for (var i = 0; i < response.length; i++) {
            if (!AppToolBox.util.isNil(response[i].EmailID)) {
                for (var j = 0; j < Role.length; j++) {
                    if (Role[j].ID === response[i].RoleID) {
                        RoleName = Role[j].RoleName.replace("_", " ");
                    }
                }
                var AllUsers = {
                    lblUserName: response[i].Name,
                    lblEmail: response[i].EmailID,
                    ID: response[i].ID,
                    lblRoleName: RoleName,
                    RoleName: RoleName,
                    flxViewRole: {
                        "onClick": function() {
                            scopeObj.viewUser();
                        }
                    },
                    flxEditRole: {
                        "onClick": function() {
                            scopeObj.editUser();
                        }
                    },
                    flxDeactivate: {
                        "onClick": function() {
                            scopeObj.deactivateUser();
                        }
                    }
                };
                Users.push(AllUsers);
            }
        }
        //var allUsers = [[{lblUserName:"User Name",lblUserID:"Email ID",lblRoleID:"User Role"},Users]];
        var allUsers = [
            [{
                lblAssessmentName: "USER NAME",
                lblDuration: "EMAIL ID",
                lblRole: "ROLE"
            }, Users]
        ];
        this.view.segManageUser.setData(allUsers);
        kony.application.dismissLoadingScreen();
    },
}));
define("UserManagement/frmUserManageControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_cc11c81d9475401fb9fbc1858e3e107a: function AS_Form_cc11c81d9475401fb9fbc1858e3e107a(eventobject) {
        var self = this;
    }
});
define("UserManagement/frmUserManageController", ["UserManagement/userfrmUserManageController", "UserManagement/frmUserManageControllerActions"], function() {
    var controller = require("UserManagement/userfrmUserManageController");
    var controllerActions = ["UserManagement/frmUserManageControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
