define("DashBoard/frmAssessment", function() {
    return function(controller) {
        function addWidgetsfrmAssessment() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var headerNew = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxUserRoleName": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "35%"
                    },
                    "headerNew": {
                        "height": "100%",
                        "isVisible": true
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(headerNew);
            var flxMainContentLayout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "82%",
                "id": "flxMainContentLayout",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContentLayout.setDefaultUnit(kony.flex.DP);
            var flxMidScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMidScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMidScroll.setDefaultUnit(kony.flex.DP);
            var flxMainLayout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainLayout",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainLayout.setDefaultUnit(kony.flex.DP);
            var flxMessageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxMessageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "-100dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageContainer.setDefaultUnit(kony.flex.DP);
            var msgContainer = new com.evaluationPortal.msgContainer.msgContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "msgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "sknmessagepop",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgClose": {
                        "src": "close_white_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMessageContainer.add(msgContainer);
            var flxBreadcrum = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "55dp",
                "id": "flxBreadcrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadcrum.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxBreadcrum": {
                        "height": "100%"
                    },
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false
                    },
                    "imgHome": {
                        "height": "100%",
                        "isVisible": true,
                        "src": "home_solid.png",
                        "width": "1%"
                    },
                    "lblBreadcrum1": {
                        "text": "My Assessments"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBreadcrum.add(BreadCrum);
            var flxContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "66dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxContainer.setDefaultUnit(kony.flex.DP);
            var flxLeftContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLeftContainer",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftContainer.setDefaultUnit(kony.flex.DP);
            var flxAssessmentTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentTitle",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentTitle.setDefaultUnit(kony.flex.DP);
            var flxAssessmentHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentHeader.setDefaultUnit(kony.flex.DP);
            var flxHeaderName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxHeaderName",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "60%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderName.setDefaultUnit(kony.flex.DP);
            var lblAssessmentHeader = new kony.ui.Label({
                "id": "lblAssessmentHeader",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl000000font28px",
                "text": "Best Buy App",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnAssessmentStatus = new kony.ui.Button({
                "focusSkin": "sknbtn7E6FFF",
                "height": "18dp",
                "id": "btnAssessmentStatus",
                "isVisible": true,
                "left": "6dp",
                "skin": "sknbtn7E6FFF",
                "text": "Submitted",
                "top": "10dp",
                "width": "71dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxHeaderName.add(lblAssessmentHeader, btnAssessmentStatus);
            var flxCertificate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCertificate",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "0",
                "width": "13.00%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCertificate.setDefaultUnit(kony.flex.DP);
            var flxDownloadCertificate = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxDownloadCertificate",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "right": "0dp",
                "skin": "sknflx4ECC48radius7px",
                "top": "0",
                "width": "123dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadCertificate.setDefaultUnit(kony.flex.DP);
            var ImgCertificate = new kony.ui.Image2({
                "centerY": "50%",
                "height": "18dp",
                "id": "ImgCertificate",
                "isVisible": true,
                "left": "11dp",
                "skin": "slImage",
                "src": "certificate.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblDownloadCertificate = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblDownloadCertificate",
                "isVisible": true,
                "left": "10dp",
                "skin": "sknlblFFFBFB12px",
                "text": "Download Certificate",
                "width": "101dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownloadCertificate.add(ImgCertificate, lblDownloadCertificate);
            flxCertificate.add(flxDownloadCertificate);
            flxAssessmentHeader.add(flxHeaderName, flxCertificate);
            flxAssessmentTitle.add(flxAssessmentHeader);
            var flxMainData = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainData",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainData.setDefaultUnit(kony.flex.DP);
            var flxMainContents = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxMainContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "23dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContents.setDefaultUnit(kony.flex.DP);
            var flxRows = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRows",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "31dp",
                "isModalContainer": false,
                "right": "31dp",
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRows.setDefaultUnit(kony.flex.DP);
            var flxSecondRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSecondRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSecondRow.setDefaultUnit(kony.flex.DP);
            var flxAssessmentNames = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentNames",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentNames.setDefaultUnit(kony.flex.DP);
            var lblAssessmentName = new kony.ui.Label({
                "id": "lblAssessmentName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Assessment Name",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtAssessmentName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtAssessmentName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntxteeedisabled",
                "text": "Best Buy App",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxAssessmentNames.add(lblAssessmentName, txtAssessmentName);
            var flxDuration = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDuration",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDuration.setDefaultUnit(kony.flex.DP);
            var lblDuration = new kony.ui.Label({
                "id": "lblDuration",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Duration",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtDuration = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtDuration",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "placeholder": "Placeholder",
                "secureTextEntry": false,
                "skin": "skntxteeedisabled",
                "text": "60 days",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxDuration.add(lblDuration, txtDuration);
            flxSecondRow.add(flxAssessmentNames, flxDuration);
            var flxThirdRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxThirdRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxThirdRow.setDefaultUnit(kony.flex.DP);
            var flxAssessmentInstruction = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentInstruction",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentInstruction.setDefaultUnit(kony.flex.DP);
            var lblAssessmentInstruction = new kony.ui.Label({
                "id": "lblAssessmentInstruction",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Assessment Instruction",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtAreaAssessmentInstruction = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextAreaFocus",
                "height": "100dp",
                "id": "txtAreaAssessmentInstruction",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "numberOfVisibleLines": 3,
                "placeholder": "Placeholder",
                "skin": "skntxtareaF4F4F4disabled",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
                "padding": [2, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxAssessmentInstruction.add(lblAssessmentInstruction, txtAreaAssessmentInstruction);
            flxThirdRow.add(flxAssessmentInstruction);
            var flxAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessment.setDefaultUnit(kony.flex.DP);
            var flxFourthRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFourthRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFourthRow.setDefaultUnit(kony.flex.DP);
            var CopyflxAssessmentFiles0ca4435176dc943 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "CopyflxAssessmentFiles0ca4435176dc943",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            CopyflxAssessmentFiles0ca4435176dc943.setDefaultUnit(kony.flex.DP);
            var CopylblAssessmentFiles0b7c513aabf1e4b = new kony.ui.Label({
                "id": "CopylblAssessmentFiles0b7c513aabf1e4b",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl13px666666",
                "text": "Assessment Files",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDownload = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDownload",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "80%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownload.setDefaultUnit(kony.flex.DP);
            var flxDownloads = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDownloads",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0%",
                "skin": "slFbox",
                "top": "0",
                "width": "15%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloads.setDefaultUnit(kony.flex.DP);
            var lblDownload = new kony.ui.Label({
                "id": "lblDownload",
                "isVisible": true,
                "right": "0",
                "skin": "sknLblcccccc",
                "text": "Download",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxLine = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "1dp",
                "id": "flxLine",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "right": "0%",
                "skin": "sknFlxDarkPurple",
                "top": "0",
                "width": "75%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLine.setDefaultUnit(kony.flex.DP);
            flxLine.add();
            flxDownloads.add(lblDownload, flxLine);
            flxDownload.add(flxDownloads);
            CopyflxAssessmentFiles0ca4435176dc943.add(CopylblAssessmentFiles0b7c513aabf1e4b, flxDownload);
            flxFourthRow.add(CopyflxAssessmentFiles0ca4435176dc943);
            var flxFifthRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFifthRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFifthRow.setDefaultUnit(kony.flex.DP);
            var flxDownloadAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDownloadAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadAssessment.setDefaultUnit(kony.flex.DP);
            var flxDownloadAssessmentContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxDownloadAssessmentContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDownloadAssessmentContainer.setDefaultUnit(kony.flex.DP);
            var imgFileType = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgFileType",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxFileUploadName = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxFileUploadName",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFileUploadName.setDefaultUnit(kony.flex.DP);
            var lblAssessmentFileName = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblAssessmentFileName",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl000000opacity80",
                "text": "Assessment File",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxFileUploadName.add(lblAssessmentFileName);
            var imgDownloadFile = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDownloadFile",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "download.png",
                "top": "0",
                "width": "20dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDownloadAssessmentContainer.add(imgFileType, flxFileUploadName, imgDownloadFile);
            flxDownloadAssessment.add(flxDownloadAssessmentContainer);
            flxFifthRow.add(flxDownloadAssessment);
            flxAssessment.add(flxFourthRow, flxFifthRow);
            var flxComment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxComment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxComment.setDefaultUnit(kony.flex.DP);
            var flxSixthRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSixthRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSixthRow.setDefaultUnit(kony.flex.DP);
            var flxComments = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxComments",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxComments.setDefaultUnit(kony.flex.DP);
            var lblComments = new kony.ui.Label({
                "id": "lblComments",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Comments",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxComments.add(lblComments);
            flxSixthRow.add(flxComments);
            var flxSeventhRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxSeventhRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxCCCCCCff8pxborder",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSeventhRow.setDefaultUnit(kony.flex.DP);
            var flxCommentsLayout = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90dp",
                "id": "flxCommentsLayout",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCommentsLayout.setDefaultUnit(kony.flex.DP);
            var flxNames = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerY": "50%",
                "clipBounds": false,
                "height": "53dp",
                "id": "flxNames",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "21dp",
                "isModalContainer": false,
                "skin": "sknflxF37070",
                "top": "0dp",
                "width": "51dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNames.setDefaultUnit(kony.flex.DP);
            var lblChatName = new kony.ui.Label({
                "centerX": "50%",
                "centerY": "50%",
                "height": "53dp",
                "id": "lblChatName",
                "isVisible": true,
                "skin": "sknlblfff16px",
                "text": "GN",
                "top": "0",
                "width": "51dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNames.add(lblChatName);
            var txtComments = new kony.ui.TextArea2({
                "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "defTextAreaFocus",
                "height": "80dp",
                "id": "txtComments",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
                "left": "17dp",
                "numberOfVisibleLines": 3,
                "placeholder": "Add a comment here...",
                "skin": "sknTxtAreaffffff",
                "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
                "width": "88%"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [5, 2, 2, 2],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextAreaPlaceholder"
            });
            flxCommentsLayout.add(flxNames, txtComments);
            flxSeventhRow.add(flxCommentsLayout);
            flxComment.add(flxSixthRow, flxSeventhRow);
            var flxSubmitted = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "68dp",
                "id": "flxSubmitted",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSubmitted.setDefaultUnit(kony.flex.DP);
            var flxApplicantFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxApplicantFiles",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "13dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFiles.setDefaultUnit(kony.flex.DP);
            var flxRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRow1.setDefaultUnit(kony.flex.DP);
            var flxUploadFileContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxUploadFileContainer",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer.setDefaultUnit(kony.flex.DP);
            var imgApplicantFIleType1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgApplicantFIleType1",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApplicantFileName1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxApplicantFileName1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFileName1.setDefaultUnit(kony.flex.DP);
            var lblFileUploadName = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblFileUploadName",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknlbl000000opacity80",
                "text": "File 1",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFileName1.add(lblFileUploadName);
            var imgDeleteFile1 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDeleteFile1",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "delete_solid.png",
                "top": "0",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer.add(imgApplicantFIleType1, flxApplicantFileName1, imgDeleteFile1);
            var flxUploadFileContainer1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxUploadFileContainer1",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2%",
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer1.setDefaultUnit(kony.flex.DP);
            var imgApplicantFIleType2 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgApplicantFIleType2",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApplicantFileName2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxApplicantFileName2",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFileName2.setDefaultUnit(kony.flex.DP);
            var lblFileUploadName1 = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblFileUploadName1",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknlbl000000opacity80",
                "text": "File 2",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFileName2.add(lblFileUploadName1);
            var imgDeleteFile2 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDeleteFile2",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "delete_solid.png",
                "top": "0",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer1.add(imgApplicantFIleType2, flxApplicantFileName2, imgDeleteFile2);
            flxRow1.add(flxUploadFileContainer, flxUploadFileContainer1);
            var flxUploadFileContainer2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "58dp",
                "id": "flxUploadFileContainer2",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxEEEEEEborderccc",
                "top": "13dp",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer2.setDefaultUnit(kony.flex.DP);
            var imgApplicantFIleType3 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "28dp",
                "id": "imgApplicantFIleType3",
                "isVisible": true,
                "left": "17dp",
                "skin": "slImage",
                "src": "zipfile.png",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxApplicantFileName3 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "50%",
                "id": "flxApplicantFileName3",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxApplicantFileName3.setDefaultUnit(kony.flex.DP);
            var lblFileUploadName2 = new kony.ui.Label({
                "centerY": "50%",
                "height": "50%",
                "id": "lblFileUploadName2",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknlbl000000opacity80",
                "text": "File 3",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxApplicantFileName3.add(lblFileUploadName2);
            var imgDeleteFile3 = new kony.ui.Image2({
                "centerY": "50%",
                "height": "20dp",
                "id": "imgDeleteFile3",
                "isVisible": true,
                "right": "17dp",
                "skin": "slImage",
                "src": "delete_solid.png",
                "top": "0",
                "width": "20dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxUploadFileContainer2.add(imgApplicantFIleType3, flxApplicantFileName3, imgDeleteFile3);
            flxApplicantFiles.add(flxRow1, flxUploadFileContainer2);
            flxSubmitted.add(flxApplicantFiles);
            var flxEightRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxEightRow",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": false,
                "left": "0",
                "isModalContainer": false,
                "right": "0dp",
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "zIndex": 10,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxEightRow.setDefaultUnit(kony.flex.DP);
            var flxAttachFiles = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAttachFiles",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAttachFiles.setDefaultUnit(kony.flex.DP);
            var imgAttachFiles = new kony.ui.Image2({
                "height": "15dp",
                "id": "imgAttachFiles",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "attach.png",
                "width": "15dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxAttachFilesContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAttachFilesContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "7dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAttachFilesContent.setDefaultUnit(kony.flex.DP);
            var btnAttach = new kony.ui.Button({
                "focusSkin": "sknbtnattachfiles",
                "id": "btnAttach",
                "isVisible": true,
                "left": "0",
                "skin": "sknbtnattachfiles",
                "text": "Attach Files",
                "top": 0,
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAttachFilesContent.add(btnAttach);
            flxAttachFiles.add(imgAttachFiles, flxAttachFilesContent);
            var flxsubmit = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxsubmit",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": 0,
                "width": "88%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxsubmit.setDefaultUnit(kony.flex.DP);
            var flxPost = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "42dp",
                "id": "flxPost",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "16dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "89dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPost.setDefaultUnit(kony.flex.DP);
            var btnPostComment = new kony.ui.Button({
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "42dp",
                "id": "btnPostComment",
                "isVisible": true,
                "right": "0",
                "skin": "sknbtnprimaryFFFFFF411062",
                "text": "Post",
                "top": "0",
                "width": "89dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var imgPost = new kony.ui.Image2({
                "centerY": "50%",
                "id": "imgPost",
                "isVisible": true,
                "right": "14dp",
                "skin": "slImage",
                "src": "post.png",
                "top": "0",
                "width": "15dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxPost.add(btnPostComment, imgPost);
            var btnCompleteAssessment = new kony.ui.Button({
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "42dp",
                "id": "btnCompleteAssessment",
                "isVisible": false,
                "left": "16dp",
                "right": "0",
                "skin": "sknbtnprimaryFFFFFF411062",
                "text": "Download & Start Assessment",
                "top": "0",
                "width": "276dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnFinish = new kony.ui.Button({
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "42dp",
                "id": "btnFinish",
                "isVisible": true,
                "left": "16dp",
                "right": "0",
                "skin": "sknbtnprimaryFFFFFF411062",
                "text": "Finish The Assessment",
                "top": "0",
                "width": "198dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "focusSkin": "sknbtnsecondaryFFFFFF411062",
                "height": "42dp",
                "id": "btnCancel",
                "isVisible": true,
                "left": "16dp",
                "right": "0",
                "skin": "sknbtnsecondaryFFFFFF411062",
                "text": "Cancel",
                "top": "0",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxsubmit.add(flxPost, btnCompleteAssessment, btnFinish, btnCancel);
            flxEightRow.add(flxAttachFiles, flxsubmit);
            var flxNinethRow = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxNinethRow",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "30dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNinethRow.setDefaultUnit(kony.flex.DP);
            var flxChatContent = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "horizontalScrollIndicator": true,
                "id": "flxChatContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "maxHeight": "500dp",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxChatContent.setDefaultUnit(kony.flex.DP);
            var flxChatMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxChatMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxChatMain.setDefaultUnit(kony.flex.DP);
            var chatBoxContents = new com.evaluationPortal.chat.chatBoxContents({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "chatBoxContents",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "chatBoxContents": {
                        "width": kony.flex.USE_PREFFERED_SIZE
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxChatMain.add(chatBoxContents);
            flxChatContent.add(flxChatMain);
            flxNinethRow.add(flxChatContent);
            var flxCancel = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCancel",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "18dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCancel.setDefaultUnit(kony.flex.DP);
            var btnCancelNew = new kony.ui.Button({
                "focusSkin": "sknbtnsecondaryFFFFFF411062",
                "height": "42dp",
                "id": "btnCancelNew",
                "isVisible": false,
                "right": "0%",
                "skin": "sknbtnsecondaryFFFFFF411062",
                "text": "Cancel",
                "top": "0dp",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxCancel.add(btnCancelNew);
            var flxSpace = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "30dp",
                "id": "flxSpace",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxSpace.setDefaultUnit(kony.flex.DP);
            flxSpace.add();
            flxRows.add(flxSecondRow, flxThirdRow, flxAssessment, flxComment, flxSubmitted, flxEightRow, flxNinethRow, flxCancel, flxSpace);
            flxMainContents.add(flxRows);
            flxMainData.add(flxMainContents);
            flxLeftContainer.add(flxAssessmentTitle, flxMainData);
            var flxRightContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "250dp",
                "id": "flxRightContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "25%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightContainer.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks2": {
                        "isVisible": false
                    },
                    "flxQuickLinks3": {
                        "isVisible": false
                    },
                    "flxQuickLinks4": {
                        "isVisible": false
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "map_solid.png"
                    },
                    "lblQuickLinks1": {
                        "text": "My Assessments"
                    },
                    "lblQuickLinks2": {
                        "text": "Map Assessment"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightContainer.add(flxQuickLinks);
            flxContainer.add(flxLeftContainer, flxRightContainer);
            var flxAssessmentStatusPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentStatusPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "41%",
                "isModalContainer": false,
                "skin": "sknflxShadow",
                "top": "765dp",
                "width": "250dp",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentStatusPopup.setDefaultUnit(kony.flex.DP);
            var segAssessmentStatus = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{}, {}, {}, {}],
                "groupCells": false,
                "id": "segAssessmentStatus",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxFilterPopup",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssessmentStatusPopup.add(segAssessmentStatus);
            flxMainLayout.add(flxMessageContainer, flxBreadcrum, flxContainer, flxAssessmentStatusPopup);
            var flxFooterMenu = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooterMenu",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooterMenu.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxAssessment": {
                        "isVisible": false
                    },
                    "flxRoleManagement": {
                        "isVisible": false
                    },
                    "flxUserManagement": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooterMenu.add(appFooter, copyrightFooter);
            flxMidScroll.add(flxMainLayout, flxFooterMenu);
            flxMainContentLayout.add(flxMidScroll);
            flxMain.add(flxHeader, flxMainContentLayout);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew.flxUserRoleName": {
                    "centerY": "",
                    "top": "35%"
                },
                "headerNew": {
                    "height": "100%"
                },
                "headerNew.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew.imgUserImage": {
                    "src": "userimg.png"
                },
                "msgContainer.imgClose": {
                    "src": "close_white_solid.png"
                },
                "BreadCrum.flxBreadcrum": {
                    "height": "100%"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "height": "100%",
                    "src": "home_solid.png",
                    "width": "1%"
                },
                "BreadCrum.lblBreadcrum1": {
                    "text": "My Assessments"
                },
                "chatBoxContents": {
                    "width": kony.flex.USE_PREFFERED_SIZE
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "map_solid.png"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "My Assessments"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Map Assessment"
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmAssessment,
            "enabledForIdleTimeout": false,
            "id": "frmAssessment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknfrmbgimg",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "retainScrollPosition": false
        }]
    }
});