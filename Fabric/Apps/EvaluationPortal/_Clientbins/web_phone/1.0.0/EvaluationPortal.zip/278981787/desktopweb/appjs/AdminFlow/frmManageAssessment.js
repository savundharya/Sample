define("AdminFlow/frmManageAssessment", function() {
    return function(controller) {
        function addWidgetsfrmManageAssessment() {
            this.setDefaultUnit(kony.flex.DP);
            var flxManageAssessment = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxManageAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageAssessment.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "segManageassessBackground",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 3,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var headerNew1 = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "headerNew": {
                        "height": "100%"
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(headerNew1);
            var flxMiddle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": false,
                "height": "82%",
                "id": "flxMiddle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddle.setDefaultUnit(kony.flex.DP);
            var flxMessageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "7%",
                "id": "flxMessageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "sknflxBottom",
                "top": "-13%",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageContainer.setDefaultUnit(kony.flex.DP);
            var msgContainer = new com.evaluationPortal.msgContainer.msgContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "msgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxMessageContainer": {
                        "height": "100%",
                        "left": "-3dp",
                        "top": "0dp"
                    },
                    "imgClose": {
                        "src": "close_white_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMessageContainer.add(msgContainer);
            var flxMiddleScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMiddleScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddleScroll.setDefaultUnit(kony.flex.DP);
            var flxBreadcrum = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "5%",
                "id": "flxBreadcrum",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "28dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadcrum.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false
                    },
                    "imgHome": {
                        "src": "home_solid.png"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxBreadcrum.add(BreadCrum);
            var flxBodyManageAssessment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxBodyManageAssessment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyManageAssessment.setDefaultUnit(kony.flex.DP);
            var flxAssessmentList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "70%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentList.setDefaultUnit(kony.flex.DP);
            var flxManageAssessmentTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "50dp",
                "id": "flxManageAssessmentTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageAssessmentTitle.setDefaultUnit(kony.flex.DP);
            var lblAssessmentManage = new kony.ui.Label({
                "centerY": "44%",
                "id": "lblAssessmentManage",
                "isVisible": true,
                "left": 0,
                "skin": "sknManageAssessHeading",
                "text": "Manage Assessment",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxManageAssessmentTitle.add(lblAssessmentManage);
            var flxManageAssessmentList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "490dp",
                "id": "flxManageAssessmentList",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknmanageAssess",
                "top": "10dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageAssessmentList.setDefaultUnit(kony.flex.DP);
            var manageTable = new com.evaluationPortal.manageTable({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "manageTable",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "manageTable": {
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared",
                        "left": "0dp",
                        "top": "0dp",
                        "width": "100%"
                    },
                    "segManageTable": {
                        "centerX": "viz.val_cleared",
                        "data": [
                            [{
                                    "imgSortActions": "sort_down_solid.png",
                                    "imgSortDuration": "sort_down_solid.png",
                                    "imgSortName": "sort_down_solid.png",
                                    "imgSortRole": "sort_down_solid.png",
                                    "lblActions": "ACTION",
                                    "lblAssessmentName": "ASSESSMENT NAM",
                                    "lblDuration": "DURATION",
                                    "lblRole": "ROLE"
                                },
                                [{
                                    "btnDelete": "Delete",
                                    "btnEdit": "Edit",
                                    "btnField1": "Best Buy App",
                                    "btnView": "View",
                                    "imgDeletebtn": "vector__4_.png",
                                    "imgEditIcon": "vector__3_.png",
                                    "imgEyeIcon": "vector__2_.png",
                                    "lblDeletebtn": "Delete",
                                    "lblEditbtn": "Edit",
                                    "lblField2": "20 Days",
                                    "lblField3": "Consultant",
                                    "lblViewbtn": "View"
                                }, {
                                    "btnDelete": "Delete",
                                    "btnEdit": "Edit",
                                    "btnField1": "Every Day  - Retail",
                                    "btnView": "View",
                                    "imgDeletebtn": "vector__4_.png",
                                    "imgEditIcon": "vector__3_.png",
                                    "imgEyeIcon": "vector__2_.png",
                                    "lblDeletebtn": "Delete",
                                    "lblEditbtn": "Edit",
                                    "lblField2": "40 Days",
                                    "lblField3": "Trainee",
                                    "lblViewbtn": "View"
                                }, {
                                    "btnDelete": "Delete",
                                    "btnEdit": "Edit",
                                    "btnField1": "Every Day - Onboarding",
                                    "btnView": "View",
                                    "imgDeletebtn": "vector__4_.png",
                                    "imgEditIcon": "vector__3_.png",
                                    "imgEyeIcon": "vector__2_.png",
                                    "lblDeletebtn": "Delete",
                                    "lblEditbtn": "Edit",
                                    "lblField2": "22 Days",
                                    "lblField3": "Consultant",
                                    "lblViewbtn": "View"
                                }, {
                                    "btnDelete": "Delete",
                                    "btnEdit": "Edit",
                                    "btnField1": "Retail Banking",
                                    "btnView": "View",
                                    "imgDeletebtn": "vector__4_.png",
                                    "imgEditIcon": "vector__3_.png",
                                    "imgEyeIcon": "vector__2_.png",
                                    "lblDeletebtn": "Delete",
                                    "lblEditbtn": "Edit",
                                    "lblField2": "90 Days",
                                    "lblField3": "Trainee",
                                    "lblViewbtn": "View"
                                }, {
                                    "btnDelete": "Delete",
                                    "btnEdit": "Edit",
                                    "btnField1": "E-Shopping App",
                                    "btnView": "View",
                                    "imgDeletebtn": "vector__4_.png",
                                    "imgEditIcon": "vector__3_.png",
                                    "imgEyeIcon": "vector__2_.png",
                                    "lblDeletebtn": "Delete",
                                    "lblEditbtn": "Edit",
                                    "lblField2": "70 Days",
                                    "lblField3": "Consultant",
                                    "lblViewbtn": "View"
                                }, {
                                    "btnDelete": "Delete",
                                    "btnEdit": "Edit",
                                    "btnField1": "Best Buy App",
                                    "btnView": "View",
                                    "imgDeletebtn": "vector__4_.png",
                                    "imgEditIcon": "vector__3_.png",
                                    "imgEyeIcon": "vector__2_.png",
                                    "lblDeletebtn": "Delete",
                                    "lblEditbtn": "Edit",
                                    "lblField2": "20 Days",
                                    "lblField3": "Consultant",
                                    "lblViewbtn": "View"
                                }, {
                                    "btnDelete": "Delete",
                                    "btnEdit": "Edit",
                                    "btnField1": "Every Day  - Retail",
                                    "btnView": "View",
                                    "imgDeletebtn": "vector__4_.png",
                                    "imgEditIcon": "vector__3_.png",
                                    "imgEyeIcon": "vector__2_.png",
                                    "lblDeletebtn": "Delete",
                                    "lblEditbtn": "Edit",
                                    "lblField2": "40 Days",
                                    "lblField3": "Trainee",
                                    "lblViewbtn": "View"
                                }]
                            ]
                        ],
                        "height": "100%",
                        "left": "1%",
                        "top": "0dp",
                        "width": "98%"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxManageAssessmentList.add(manageTable);
            flxAssessmentList.add(flxManageAssessmentTitle, flxManageAssessmentList);
            var flxQuickLinksMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "400dp",
                "id": "flxQuickLinksMain",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "1%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "30%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinksMain.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "2dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxLinks": {
                        "width": "100%"
                    },
                    "flxQuickLinks": {
                        "centerX": "viz.val_cleared",
                        "left": "2dp",
                        "right": "0",
                        "width": "100%"
                    },
                    "flxQuickLinks1": {
                        "width": "100%"
                    },
                    "flxQuickLinks2": {
                        "width": "100%"
                    },
                    "flxQuickLinks3": {
                        "isVisible": false
                    },
                    "flxQuickLinks4": {
                        "isVisible": false
                    },
                    "flxQuickLinksMain": {
                        "width": "90%"
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "map_solid.png"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Assessment"
                    },
                    "lblQuickLinks2": {
                        "text": "Map Assessment"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxQuickLinksMain.add(flxQuickLinks);
            flxBodyManageAssessment.add(flxAssessmentList, flxQuickLinksMain);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": 0,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {}
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(appFooter, copyrightFooter);
            flxMiddleScroll.add(flxBreadcrum, flxBodyManageAssessment, flxFooter);
            flxMiddle.add(flxMessageContainer, flxMiddleScroll);
            flxMain.add(flxHeader, flxMiddle);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknDeletePopup",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var flxPopup1 = new com.evaluationPortal.popup.flxPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxPopup1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxPopup": {
                        "isVisible": true
                    },
                    "imgClose": {
                        "src": "close_black_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup1.btnDelete.onClick = controller.AS_Button_e620709af19b48fbb59d88fd5ad02471;
            flxPopup.add(flxPopup1);
            flxManageAssessment.add(flxMain, flxPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew1": {
                    "height": "100%"
                },
                "headerNew1.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew1.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew1.imgUserImage": {
                    "src": "userimg.png"
                },
                "msgContainer.flxMessageContainer": {
                    "height": "100%",
                    "left": "-3dp",
                    "top": "0dp"
                },
                "msgContainer.imgClose": {
                    "src": "close_white_solid.png"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "src": "home_solid.png"
                },
                "manageTable": {
                    "centerX": "",
                    "centerY": "",
                    "left": "0dp",
                    "top": "0dp",
                    "width": "100%"
                },
                "manageTable.segManageTable": {
                    "centerX": "",
                    "data": [
                        [{
                                "imgSortActions": "sort_down_solid.png",
                                "imgSortDuration": "sort_down_solid.png",
                                "imgSortName": "sort_down_solid.png",
                                "imgSortRole": "sort_down_solid.png",
                                "lblActions": "ACTION",
                                "lblAssessmentName": "ASSESSMENT NAM",
                                "lblDuration": "DURATION",
                                "lblRole": "ROLE"
                            },
                            [{
                                "btnDelete": "Delete",
                                "btnEdit": "Edit",
                                "btnField1": "Best Buy App",
                                "btnView": "View",
                                "imgDeletebtn": "vector__4_.png",
                                "imgEditIcon": "vector__3_.png",
                                "imgEyeIcon": "vector__2_.png",
                                "lblDeletebtn": "Delete",
                                "lblEditbtn": "Edit",
                                "lblField2": "20 Days",
                                "lblField3": "Consultant",
                                "lblViewbtn": "View"
                            }, {
                                "btnDelete": "Delete",
                                "btnEdit": "Edit",
                                "btnField1": "Every Day  - Retail",
                                "btnView": "View",
                                "imgDeletebtn": "vector__4_.png",
                                "imgEditIcon": "vector__3_.png",
                                "imgEyeIcon": "vector__2_.png",
                                "lblDeletebtn": "Delete",
                                "lblEditbtn": "Edit",
                                "lblField2": "40 Days",
                                "lblField3": "Trainee",
                                "lblViewbtn": "View"
                            }, {
                                "btnDelete": "Delete",
                                "btnEdit": "Edit",
                                "btnField1": "Every Day - Onboarding",
                                "btnView": "View",
                                "imgDeletebtn": "vector__4_.png",
                                "imgEditIcon": "vector__3_.png",
                                "imgEyeIcon": "vector__2_.png",
                                "lblDeletebtn": "Delete",
                                "lblEditbtn": "Edit",
                                "lblField2": "22 Days",
                                "lblField3": "Consultant",
                                "lblViewbtn": "View"
                            }, {
                                "btnDelete": "Delete",
                                "btnEdit": "Edit",
                                "btnField1": "Retail Banking",
                                "btnView": "View",
                                "imgDeletebtn": "vector__4_.png",
                                "imgEditIcon": "vector__3_.png",
                                "imgEyeIcon": "vector__2_.png",
                                "lblDeletebtn": "Delete",
                                "lblEditbtn": "Edit",
                                "lblField2": "90 Days",
                                "lblField3": "Trainee",
                                "lblViewbtn": "View"
                            }, {
                                "btnDelete": "Delete",
                                "btnEdit": "Edit",
                                "btnField1": "E-Shopping App",
                                "btnView": "View",
                                "imgDeletebtn": "vector__4_.png",
                                "imgEditIcon": "vector__3_.png",
                                "imgEyeIcon": "vector__2_.png",
                                "lblDeletebtn": "Delete",
                                "lblEditbtn": "Edit",
                                "lblField2": "70 Days",
                                "lblField3": "Consultant",
                                "lblViewbtn": "View"
                            }, {
                                "btnDelete": "Delete",
                                "btnEdit": "Edit",
                                "btnField1": "Best Buy App",
                                "btnView": "View",
                                "imgDeletebtn": "vector__4_.png",
                                "imgEditIcon": "vector__3_.png",
                                "imgEyeIcon": "vector__2_.png",
                                "lblDeletebtn": "Delete",
                                "lblEditbtn": "Edit",
                                "lblField2": "20 Days",
                                "lblField3": "Consultant",
                                "lblViewbtn": "View"
                            }, {
                                "btnDelete": "Delete",
                                "btnEdit": "Edit",
                                "btnField1": "Every Day  - Retail",
                                "btnView": "View",
                                "imgDeletebtn": "vector__4_.png",
                                "imgEditIcon": "vector__3_.png",
                                "imgEyeIcon": "vector__2_.png",
                                "lblDeletebtn": "Delete",
                                "lblEditbtn": "Edit",
                                "lblField2": "40 Days",
                                "lblField3": "Trainee",
                                "lblViewbtn": "View"
                            }]
                        ]
                    ],
                    "height": "100%",
                    "left": "1%",
                    "top": "0dp",
                    "width": "98%"
                },
                "flxQuickLinks.flxLinks": {
                    "width": "100%"
                },
                "flxQuickLinks": {
                    "centerX": "",
                    "left": "2dp",
                    "right": "0",
                    "width": "100%"
                },
                "flxQuickLinks.flxQuickLinks1": {
                    "width": "100%"
                },
                "flxQuickLinks.flxQuickLinks2": {
                    "width": "100%"
                },
                "flxQuickLinks.flxQuickLinksMain": {
                    "width": "90%"
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "map_solid.png"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "Create Assessment"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Map Assessment"
                },
                "flxPopup1.imgClose": {
                    "src": "close_black_solid.png"
                }
            }
            this.add(flxManageAssessment);
        };
        return [{
            "addWidgets": addWidgetsfrmManageAssessment,
            "enabledForIdleTimeout": false,
            "id": "frmManageAssessment",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "CopyslForm0ad0a686b246344",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_i3bb2168d56c4de199207ca3abec8670,
            "retainScrollPosition": false
        }]
    }
});