var storeMessages = {};
var filesResponse = false;
define("Evaluator/userfrmApprovalAssessmentController", ["AppToolBox", "Utils"], (AppToolBox, Utils) => ({
    onNavigate: function() {
        this.view.preShow = this.preShow;
        this.view.postShow = this.postShow;
    },
    preShow: function() {
        const data = AppToolBox.store.getItem("RowData");
        filesResponse = false;
        kony.application.showLoadingScreen("sknDeletePopup", "Please wait while loading the files..", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {});
        this.view.lblAssessmentName.text = data.lblAssessmentName.text;
        this.view.btnAssessmentStatus.text = data.status;
        this.view.txtUserName.text = data.lblDuration;
        this.view.txtDuration.text = data.Duration;
        this.view.txtAreaAssessmentInstruction.text = data.assessmentInstruction;
        this.view.txtComments.text = "";
        this.view.imgUploadAction.setVisibility(true);
        this.view.flxSubmitted.setVisibility(false);
        this.view.flxApplicantFile1.setVisibility(false);
        this.view.flxApplicantFile2.setVisibility(false);
        this.view.flxRow2.setVisibility(false);
        this.view.txtDuration.setEnabled(false);
        this.view.txtUserName.setEnabled(false);
        this.view.txtAssessmentName.setEnabled(false);
        this.view.txtSubmittedDate.setEnabled(false);
        this.view.txtAreaAssessmentInstruction.setEnabled(false);
        this.checkStatus(data.status);
        this.view.BreadCrum.lblBreadcrum1.text = "Manage Assigned Assessment";
        this.view.btnCancel.onClick = () => {
            AppToolBox.navigation.navigateTo("frmAssignedAssessment");
        }
        this.view.DropDown.segDropDown.onRowClick = () => {
            this.view.DropDown.txtBoxDropDown.text = this.view.DropDown.segDropDown.selectedRowItems[0].lblFilter;
            this.view.DropDown.flxDropDownValues.isVisible = false;
        }
        this.view.imgUploadAction.onTouchEnd = this.downloadKit;
        this.view.DropDown.txtBoxDropDown.placeholder = "Select assessment status";
        this.view.DropDown.txtBoxDropDown.text = "";
        this.view.btnSubmit.onClick = this.updateAssessmentStatus.bind(this, data);
        let param = {
            "FlowType": "CountAssess",
            "FormDetails": "frmApprovalAssessment"
        };
        this.fetchAssessmentFile({
            Filter: "AssessmentID eq " + data.assessID,
        });
        this.fetchSubmittedFiles(data.AppID);
        AppToolBox.store.setItem("ChatID", "");
        this.view.btnPost.onClick = this.createMessageDetailsChat;
        var params = {
            "Filter": "EmailID eq " + AppToolBox.store.getItem("userDetails").EmailID
        };
        this.getChatID(data.AppID);
        this.view.flxChatMain.setVisibility(false);
        this.view.lblChatName.text = this.trimUserName(AppToolBox.store.getItem("userDetails").Name);
        this.view.onDeviceBack = function() {};
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navToAssignedAssessment.bind(this);
        this.view.flxQuickLinks.flxQuickLinks1.onClick = this.navToAssignedAssessment.bind(this);
    },
    navToAssignedAssessment: function() {
        AppToolBox.navigation.navigateTo("frmAssignedAssessment");
    },
    fetchAssessmentFile: function(params) {
        const scope = this;
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ApplicationFileModule");
        DashMod.presentationController.fetchAssessFile(params);
    },
    downloadKit: function() {
        Utils.ConvertBlobToFile(AssessFile);
    },
    fetchSubmittedFiles: function(AppID) {
        var params = {
            "Filter": "ApplicationID eq " + AppID
        };
        var AppFileMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ApplicationFileModule");
        AppFileMod.presentationController.fetchAppFile(params);
    },
    setAssessmentFiles: function({
        ApplicationFile1,
        ApplicationFile2,
        ApplicationFile3
    }) {
        try {
            filesResponse = true;
            kony.application.dismissLoadingScreen();
            const scope = this;
            !AppToolBox.util.isNil(ApplicationFile1) || !AppToolBox.util.isNil(ApplicationFile2) || !AppToolBox.util.isNil(ApplicationFile3) ? scope.view.flxSubmitted.setVisibility(true) : scope.view.flxSubmitted.setVisibility(false);
            AppToolBox.util.isNil(ApplicationFile1) ? scope.view.flxApplicantFile1.setVisibility(false) : scope.view.flxApplicantFile1.setVisibility(true);
            scope.view.imgDownloadFile1.onTouchEnd = scope.download.bind(scope, ApplicationFile1, "ApplicationFile1");
            AppToolBox.util.isNil(ApplicationFile2) ? scope.view.flxApplicantFile2.setVisibility(false) : scope.view.flxApplicantFile2.setVisibility(true);
            scope.view.imgDownloadFile2.onTouchEnd = scope.download.bind(scope, ApplicationFile2, "ApplicationFile2");
            AppToolBox.util.isNil(ApplicationFile3) ? scope.view.flxRow2.setVisibility(false) : scope.view.flxRow2.setVisibility(true);
            scope.view.imgDownloadFile3.onTouchEnd = scope.download.bind(scope, ApplicationFile3, "ApplicationFile3");
            scope.view.flxDownloadAllMain.onClick = () => {
                !AppToolBox.util.isNil(ApplicationFile1) ? scope.download(ApplicationFile1, "ApplicationFile1") : "";
                !AppToolBox.util.isNil(ApplicationFile2) ? scope.download(ApplicationFile2, "ApplicationFile2") : "";
                !AppToolBox.util.isNil(ApplicationFile3) ? scope.download(ApplicationFile3, "ApplicationFile3") : "";
            }
        } catch (e) {
            kony.print("Catch of setAssessmentFiles" + e.message);
        }
    },
    download: function(AppFile, fileName) {
        //     kony.application.showLoadingScreen();
        kony.application.showLoadingScreen("slTextWhite", "Please wait while loading the files..", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {});
        !AppToolBox.util.isNil(AppFile) ? Utils.ConvertBlobToFile(AppFile, fileName) : "";
    },
    updateAssessmentStatus: function(data) {
        const appStatus = [{
            status: "Approved",
            id: "STATUS005"
        }, {
            status: "Rejected",
            id: "STATUS006"
        }, {
            status: "In-Progress",
            id: "STATUS002"
        }, {
            status: "Overdue",
            id: "STATUS003"
        }];
        const status = appStatus.find(el => el.status === this.view.DropDown.txtBoxDropDown.text);
        if (!AppToolBox.util.isNil(status)) {
            const params = {
                "ApplicationID": data.AppID,
                "ApplicationStatus": status.id,
                "AssessmentID": data.assessID,
                "AssessmentName": data.lblAssessmentName.text
            };
            const EvaluatorMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("EvaluatorModule");
            EvaluatorMod.presentationController.triggerEmailCompleted(params);
        }
    },
    checkStatus: function(status) {
        const scope = this;
        if (status === "SUBMITTED") {
            scope.view.DropDown.setVisibility(true);
            scope.view.btnSubmit.setVisibility(true);
            scope.view.flxSubmittedDate.setVisibility(true);
            scope.view.txtSubmittedDate.text = AppToolBox.store.getItem("RowData").submittedDate;
        } else {
            scope.view.DropDown.setVisibility(false);
            scope.view.btnSubmit.setVisibility(false);
            scope.view.flxSubmittedDate.setVisibility(false);
        }
    },
    displayDownloadImg: function() {
        const scope = this;
        // scope.view.imgUploadAction.setVisibility(true);
    },
    trimUserName: function(name) {
        let userName = name.split(" ");
        return userName.length === 2 ? `${userName[0].substring(0,1)}${userName[1].substring(0,1)}` : `${userName[0].substring(0,1)}`;
    },
    getChatID: function(appID) {
        const ID = AppToolBox.store.getItem("userDetails").ID;
        const params = {
            "Filter": `EvaluatorID eq ${ID} and ApplicationID eq ${appID}`
        }
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getChatDetails(params);
    },
    setChatID: function(response) {
        if (AppToolBox.util.isNil(response.chattable)) {
            this.view.flxComment.setVisibility(false);
            this.view.flxPost.setVisibility(false);
            return;
        }
        this.view.flxComment.setVisibility(true);
        this.view.flxPost.setVisibility(true);
        AppToolBox.store.setItem("ChatID", response.chattable[0].ID);
        const appID = AppToolBox.store.getItem("RowData").AppID;
        const params = {
            "ApplicationID": appID,
            "userID": AppToolBox.store.getItem("userDetails").ID
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getMessageDetailsChat(params);
    },
    setMessageDetails: function(response) {
        storeMessages = response;
        !AppToolBox.util.isNil(response.messages) ? this.view.flxChatMain.setVisibility(true) : this.view.flxChatMain.setVisibility(false)
        let param = {
            "Filter": "ID eq " + AppToolBox.store.getItem("RowData").userID + " or ID eq " + AppToolBox.store.getItem("userDetails").ID
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.fetchUserChat(param);
    },
    mapMessageDetails: function(response) {
        toUser = response.user[1].ID;
        const trainee = response.user[0].RoleID === "TRAINEE" ? response.user[0].Name : response.user[1].Name;
        const evaluator = response.user[0].RoleID === "EVALUATOR" ? response.user[0].Name : response.user[1].Name;
        const dataMap = {
            lblChatBoxProfileName: "lblChatBoxProfileName",
            lblRole: "lblRole",
            lblDuration: "lblDuration",
            lblChatBoxRowMessages: "lblChatBoxRowMessages",
            lblProfileName: "lblProfileName",
            flxChatBoxProfileImg: "flxChatBoxProfileImg"
        };
        let messageDetails = [];
        storeMessages.messages.reverse().map(msg => {
            var messageDetailsdata = {
                lblChatBoxProfileName: msg.Sender === "Evaluator" ? evaluator : trainee,
                flxChatBoxProfileImg: {
                    skin: msg.Sender === "Evaluator" ? "sknflxF37070" : "sknflx7E6FFF"
                },
                lblRole: msg.Sender === "User" ? "Trainee" : "Evaluator",
                lblChatBoxRowMessages: msg.Message,
                lblDuration: this.getChatTime(msg.CreatedTs),
                lblProfileName: msg.Sender === "Evaluator" ? this.trimUserName(evaluator) : this.trimUserName(trainee),
            };
            messageDetails.push(messageDetailsdata);
        })
        this.view.chatBoxContents.segchatBoxContents.widgetDataMap = dataMap;
        this.view.chatBoxContents.segchatBoxContents.setData(messageDetails);
        this.view.flxChatMain.setVisibility(true);
        if (filesResponse === true) {
            kony.application.dismissLoadingScreen();
        }
    },
    createMessageDetailsChat: function(response) {
        var scope = this;
        if (AppToolBox.util.isNil(scope.view.txtComments.text) || AppToolBox.util.isNil(AppToolBox.store.getItem("ChatID"))) {
            scope.view.txtComments.text = "";
            return;
        }
        const fromUser = AppToolBox.store.getItem("userDetails").ID;
        const toUser = AppToolBox.store.getItem("RowData").userID;
        var params = {
            "ChatID": AppToolBox.store.getItem("ChatID"),
            "FromUser": fromUser,
            "ToUser": toUser,
            "Message": scope.view.txtComments.text,
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.createMessage(params);
        kony.application.showLoadingScreen();
    },
    refreshChat: function(response) {
        this.view.txtComments.text = "";
        const appID = AppToolBox.store.getItem("RowData").AppID;
        const params = {
            "ApplicationID": appID,
            "userID": AppToolBox.store.getItem("userDetails").ID
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getMessageDetailsChat(params);
    },
    hideChat: function() {
        // kony.application.dismissLoadingScreen();
        this.view.chatBoxContents.segchatBoxContents.setData([]);
        this.view.flxChatMain.setVisibility(false);
    },
    getChatTime: function(oldDate) {
        const scope = this;
        oldDate = new Date(oldDate);
        const currDate = new Date();
        let days = scope.getDifferenceInDays(oldDate, currDate)
        let hrs = scope.getDifferenceInHours(oldDate, currDate);
        let min = scope.getDifferenceInMinutes(oldDate, currDate);
        let sec = scope.getDifferenceInSeconds(oldDate, currDate);
        if (min < 5) {
            return ("Few mins ago..")
        } else if (min > 5 && hrs < 1) {
            return (`${Math.floor(min)} mins ago`)
        } else if (hrs > 1 && days <= 1) {
            return (`${Math.floor(hrs)} hours ago`)
        } else {
            return (`${Math.floor(days)} days ago`)
        }
    },
    getDifferenceInDays: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / (1000 * 60 * 60 * 24);
    },
    getDifferenceInHours: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / (1000 * 60 * 60);
    },
    getDifferenceInMinutes: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / (1000 * 60);
    },
    getDifferenceInSeconds: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / 1000;
    }
}));
define("Evaluator/frmApprovalAssessmentControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Evaluator/frmApprovalAssessmentController", ["Evaluator/userfrmApprovalAssessmentController", "Evaluator/frmApprovalAssessmentControllerActions"], function() {
    var controller = require("Evaluator/userfrmApprovalAssessmentController");
    var controllerActions = ["Evaluator/frmApprovalAssessmentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
