var uploadFiles = [];
var storeMessages = {};
var fileResponse = false;
define("DashBoard/userfrmAssessmentController", ["AppToolBox", "Utils", "animations"], (AppToolBox, Utils, animations) => ({
    onNavigate: function() {
        this.view.preShow = this.preShow;
    },
    preShow: function() {
        let scope = this;
        kony.application.showLoadingScreen("sknDeletePopup", "Please wait while loading the files..", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {});
        let userData = this.getUserData();
        uploadFiles = [];
        fileResponse = false;
        scope.view.flxSubmitted.height = "0dp";
        scope.view.lblAssessmentHeader.text = AppToolBox.store.getItem("segData").assessmentName;
        scope.view.txtAssessmentName.text = AppToolBox.store.getItem("segData").assessmentName;
        scope.view.txtAreaAssessmentInstruction.text = AppToolBox.store.getItem("segData").assessmentInstructions;
        scope.view.txtDuration.text = AppToolBox.store.getItem("segData").duration;
        scope.view.txtComments.text = "";
        scope.view.txtComments.onTextChange = (text) => {
            scope.view.txtComments.text.length >= 1 ? scope.view.btnPostComment.setEnabled(true) : scope.view.btnPostComment.setEnabled(false);
        }
        scope.view.txtAssessmentName.setEnabled(false);
        scope.view.txtDuration.setEnabled(false);
        scope.view.btnAssessmentStatus.setEnabled(false);
        scope.view.txtAreaAssessmentInstruction.setEnabled(false);
        scope.view.flxDownloadCertificate.setVisibility(false);
        scope.view.btnPostComment.setEnabled(false);
        scope.view.imgDownloadFile.setVisibility(true);
        scope.view.flxUploadFileContainer.setVisibility(false);
        scope.view.flxUploadFileContainer1.setVisibility(false);
        scope.view.flxUploadFileContainer2.setVisibility(false);
        scope.view.msgContainer.flxMessageContainer.skin = "sknmessagepop";
        let ID = AppToolBox.store.getItem("segData").applicationID;
        AppToolBox.store.setItem("ApplicationID", ID);
        scope.view.btnAttach.onClick = this.uploadClickNew;
        scope.view.btnCancel.onClick = () => {
            AppToolBox.navigation.navigateTo("frmUserDashboard");
        }
        scope.view.btnCancelNew.onClick = () => {
            AppToolBox.navigation.navigateTo("frmUserDashboard");
        }
        scope.view.flxQuickLinks.flxQuickLinks1.onClick = () => {
            AppToolBox.navigation.navigateTo("frmUserDashboard");
        }
        scope.view.BreadCrum.lblBreadcrum1.text = "My Assessment";
        scope.view.BreadCrum.lblBreadcrum1.onTouchStart = () => {
            AppToolBox.navigation.navigateTo("frmUserDashboard");
        }
        scope.updateFormUINew(userData);
        scope.view.lblChatName.text = scope.trimUserName(userData.Name);
        scope.view.btnPostComment.onClick = this.createMessageDetailsChat;
        var params = {
            "Filter": "EmailID eq " + AppToolBox.store.getItem("userDetails").EmailID
        };
        scope.getChatID();
        scope.fetchRoleId();
        scope.view.btnCancel.setVisibility(true);
        scope.view.flxNinethRow.setVisibility(false);
        scope.view.btnCancelNew.setVisibility(false);
        scope.view.onDeviceBack = function() {};
    },
    downloadAsssessment: function(userData) {
        this.startAssessment(userData);
    },
    startAssessment: function(userData) {
        this.updateApplicationStatus(userData);
    },
    callIntegration: function(files) {
        let userData = this.getUserData();
        var params = {};
        params = {
            Name: userData.Name,
            ApplicationID: AppToolBox.store.getItem("ApplicationID"),
            AssessmentID: AppToolBox.store.getItem("segData").assessmentID,
            AssessmentName: AppToolBox.store.getItem("segData").assessmentName,
            SubmitApplication: true,
            ApplicantComments: this.view.txtComments.text,
        };
        // kony.application.showLoadingScreen();
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.setApplicationDetails(params);
    },
    updateApplicationStatus: function(userData) {
        // kony.application.showLoadingScreen();
        const today = new Date();
        const yyyy = today.getFullYear();
        let mm = today.getMonth() + 1; // Months start at 0!
        let dd = today.getDate();
        if (dd < 10) dd = "0" + dd;
        if (mm < 10) mm = "0" + mm;
        const formattedToday = yyyy + "-" + mm + "-" + dd;
        var params = {
            ID: AppToolBox.store.getItem("ApplicationID"),
            ApplicationStatus: "STATUS002",
            StartDate: formattedToday,
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.startAssessment(params);
    },
    getUserData: function() {
        var Data = {
            userID: AppToolBox.store.getItem("userDetails").ID,
            assessmentID: AppToolBox.store.getItem("segData").assessmentID,
            Name: AppToolBox.store.getItem("userDetails").Name,
            assessmentInstructions: AppToolBox.store.getItem("segData").assessmentInstructions,
        };
        return Data;
    },
    updateFormUINew: function(dataObj) {
        if (!AppToolBox.util.isNil(dataObj)) {
            if (!AppToolBox.util.isNil(dataObj.userID) && !AppToolBox.util.isNil(dataObj.assessmentID)) {
                this.setAssessmentStatusNew(AppToolBox.store.getItem("segData"));
                this.fetchAssessFile({
                    Filter: "AssessmentID eq " + dataObj.assessmentID,
                });
            }
        }
    },
    setAssessmentDetailsNew: function(details) {
        if (!AppToolBox.util.isNil(details)) {
            this.view.txtAreaAssessmentInstruction.text = details.assessmentInstructions;
            this.view.txtDuration.text = AppToolBox.store.getItem("segData").duration;
        } else {
            this.displayErrorMsg("No data found");
        }
    },
    setAssessmentStatusNew: function(dataObj) {
        if (!AppToolBox.util.isNil(dataObj.applicationID)) {
            !AppToolBox.util.isNil(dataObj.status) ? this.showOrHideContainerNew(dataObj.status) : "-";
        } else {
            this.showOrHideContainerNew(" ");
        }
    },
    showOrHideContainerNew: function(status) {
        let scope = this;
        const userData = scope.getUserData();
        const appStatus = AppToolBox.store.getItem("AppStatusResponse");
        const statusSkins = {
            "INITIATED": "sknbtn5797FC",
            "INPROGRESS": "sknbtnFFCC29",
            "SUBMITTED": "sknbtn7E6FFF",
            "COMPLETED": "sknbtn4ECC48",
            "OVERDUE": "sknbtnF37070",
            "FAILED": "sknbtnF37070",
        }
        status = !AppToolBox.util.isNil(appStatus.find(el => el.ID === status)) ? appStatus.find(el => el.ID === status).Status : status;
        scope.view.btnAssessmentStatus.text = status;
        scope.view.btnAssessmentStatus.skin = statusSkins[status];
        scope.view.btnFinish.onClick = this.submitOnclickNew;
        if (status === "INITIATED") {
            scope.view.btnCancel.setVisibility(true);
            scope.view.btnCompleteAssessment.setVisibility(true);
            scope.view.btnFinish.setVisibility(false);
            scope.view.flxPost.setVisibility(true);
            scope.view.flxAttachFiles.setVisibility(false);
            scope.view.btnCompleteAssessment.onClick = this.downloadAsssessment.bind(this, userData);
            scope.view.imgDownloadFile.onTouchStart = this.downloadKit;
        } else if (status === "INPROGRESS") {
            scope.view.btnCancel.setVisibility(false);
            scope.view.btnCompleteAssessment.setVisibility(false);
            scope.view.btnFinish.setVisibility(true);
            scope.view.flxPost.setVisibility(true);
            scope.view.flxAttachFiles.setVisibility(true);
            scope.view.txtComments.text = "";
            scope.view.imgDownloadFile.onTouchStart = this.downloadKit;
        } else if (status === "SUBMITTED" || status === "COMPLETED" || status === "FAILED") {
            scope.view.flxAttachFiles.setVisibility(false);
            scope.view.flxSubmitted.height = "0dp";
            scope.view.flxUploadFileContainer.setVisibility(false);
            scope.view.flxUploadFileContainer1.setVisibility(false);
            scope.view.flxUploadFileContainer2.setVisibility(false);
            scope.view.btnCancel.setVisibility(true);
            scope.view.btnCompleteAssessment.setVisibility(false);
            scope.view.btnFinish.setVisibility(false);
            scope.view.flxPost.setVisibility(true);
            scope.view.txtComments.text = "";
            scope.view.imgDownloadFile.onTouchStart = this.downloadKit;
        }
        if (status === "COMPLETED") {
            scope.view.flxDownloadCertificate.setVisibility(true);
        }
    },
    fetchAssessFile: function(params) {
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("ApplicationFileModule");
        DashMod.presentationController.fetchAssessFile(params);
    },
    displayDownloadImg: function() {
        const scope = this;
        filesResponse = true;
        kony.application.dismissLoadingScreen();
    },
    displayErrorMsg: function(error) {
        const scope = this;
        scope.view.msgContainer.flxMessageContainer.skin = "sknflxF37070error";
        scope.view.msgContainer.skin = "sknflxF37070error";
        scope.view.msgContainer.setMessage(error);
        animations.showMessageNew(scope.view.flxMessageContainer, this);
        kony.application.dismissLoadingScreen();
    },
    displaySuccessMsg: function(text) {
        const scope = this;
        scope.view.msgContainer.flxMessageContainer.skin = "sknmessagepop";
        scope.view.msgContainer.skin = "sknmessagepop";
        scope.view.msgContainer.setMessage(text);
        animations.showMessageNew(scope.view.flxMessageContainer, this);
        kony.application.dismissLoadingScreen();
    },
    downloadKit: function() {
        Utils.ConvertBlobToFile(AssessFile);
    },
    submitOnclickNew: function() {
        const scope = this;
        if (!AppToolBox.util.isNil(uploadFiles) && uploadFiles.length >= 1) {
            scope.callIntegration();
        } else {
            scope.displayErrorMsg("Please upload required files to submit");
        }
    },
    uploadClickNew: function() {
        const scope = this;
        if (uploadFiles.length + 1 === 1 || uploadFiles.length + 1 === 2) {
            scope.view.flxSubmitted.height = "68dp";
        } else if (uploadFiles.length + 1 === 3) {
            scope.view.flxSubmitted.height = "146dp";
        }
        if (uploadFiles.length + 1 <= 3) {
            const config = {
                selectMultipleFiles: true,
                filter: ["application/zip"],
            };
            kony.io.FileSystem.browse(config, scope.browseFilesCallbackNew);
        } else {
            scope.displayErrorMsg("Max upload files reached");
        }
    },
    browseFilesCallbackNew: function(event, fileArray) {
        const scope = this;
        let base64 = "";
        let fileName = "";
        if (uploadFiles.length + 1 === 1) {
            scope.view.flxUploadFileContainer.setVisibility(true);
            fileName = fileArray[0].name;
            scope.view.lblFileUploadName.text = fileName;
            this.view.imgDeleteFile1.onTouchStart = function() {
                scope.view.flxUploadFileContainer.setVisibility(false);
                scope.view.flxUploadFileContainer2.isVisible === false && scope.view.flxUploadFileContainer1.isVisible === false ? scope.view.flxSubmitted.height = "0dp" : scope.view.flxSubmitted.height = "146dp"
                uploadFiles = uploadFiles.filter(file => {
                    return file.fileName !== scope.view.lblFileUploadName.text;
                })
            };
        }
        if (uploadFiles.length + 1 === 2) {
            scope.view.flxUploadFileContainer.isVisible === false ? scope.view.flxUploadFileContainer.setVisibility(true) : scope.view.flxUploadFileContainer1.setVisibility(true);
            fileName = fileArray[0].name;
            scope.view.lblFileUploadName1.text = fileName;
            this.view.imgDeleteFile2.onTouchStart = function() {
                scope.view.flxUploadFileContainer1.setVisibility(false);
                scope.view.flxUploadFileContainer2.isVisible === false ? scope.view.flxSubmitted.height = "0dp" : scope.view.flxSubmitted.height = "146dp";
                uploadFiles = uploadFiles.filter(file => {
                    return file.fileName !== scope.view.lblFileUploadName1.text;
                })
            };
        }
        if (uploadFiles.length + 1 === 3) {
            scope.view.flxUploadFileContainer.isVisible === false ? scope.view.flxUploadFileContainer.setVisibility(true) : scope.view.flxUploadFileContainer2.setVisibility(true);
            fileName = fileArray[0].name;
            scope.view.lblFileUploadName2.text = fileName;
            this.view.imgDeleteFile3.onTouchStart = function() {
                scope.view.flxUploadFileContainer2.setVisibility(false);
                scope.view.flxUploadFileContainer.isVisible === true || scope.view.flxUploadFileContainer1.isVisible === true ? scope.view.flxSubmitted.height = "68dp" : scope.view.flxSubmitted.height = "0dp";
                uploadFiles = uploadFiles.filter(file => {
                    return file.fileName !== scope.view.lblFileUploadName2.text;
                })
            };
        }
        Utils.convertAlltoBase64(fileArray, function(base64Array) {
            base64 = base64Array[0];
            uploadFiles.push({
                "base64": base64,
                "fileName": fileName
            });
        });
    },
    callBackTimer: function() {
        kony.timer.schedule("MessagePopupTimer", this.hideMessage, 5, false);
    },
    diffDays: function(date2) {
        var dt1 = new Date(date2);
        var dt2 = new Date();
        var diff = Math.floor(
            (Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24));
        return diff;
    },
    trimUserName: function(name) {
        let userName = name.split(" ");
        return userName.length === 2 ? `${userName[0].substring(0,1)}${userName[1].substring(0,1)}` : `${userName[0].substring(0,1)}`;
    },
    fetchRoleId: function() {
        let scope = this;
        var userData = this.getUserData();
        var ID = AppToolBox.store.getItem("segData").applicationID;
        AppToolBox.store.setItem("ApplicationID", ID);
        var params = {
            "ApplicationID": ID,
            "userID": userData.userID
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getMessageDetailsChat(params);
    },
    getChatID: function() {
        const userData = this.getUserData();
        const params = {
            "Filter": `UserID eq ${userData.userID} and ApplicationID eq ${AppToolBox.store.getItem("segData").applicationID}`
        }
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getChatDetails(params);
    },
    setChatID: function(response) {
        const scope = this;
        if (AppToolBox.util.isNil(response.chattable)) {
            scope.view.flxPost.setVisibility(false);
            scope.view.flxComment.setVisibility(false);
            return;
        }
        scope.view.flxPost.setVisibility(true);
        scope.view.flxComment.setVisibility(true);
        AppToolBox.store.setItem("ChatID", response.chattable[0].ID);
        AppToolBox.store.setItem("Evaluator", response.chattable[0].EvaluatorID);
    },
    setMessageDetails: function(response) {
        storeMessages = response;
        let param = {
            "Filter": "ID eq " + AppToolBox.store.getItem("Evaluator") + " or ID eq " + AppToolBox.store.getItem("userDetails").ID
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.fetchUserChat(param);
    },
    mapMessageDetails: function(response) {
        const scope = this;
        const trainee = response.user[0].RoleID === "TRAINEE" ? response.user[0].Name : response.user[1].Name;
        const evaluator = response.user[0].RoleID === "EVALUATOR" ? response.user[0].Name : response.user[1].Name;
        const dataMap = {
            lblChatBoxProfileName: "lblChatBoxProfileName",
            lblRole: "lblRole",
            lblDuration: "lblDuration",
            lblChatBoxRowMessages: "lblChatBoxRowMessages",
            lblProfileName: "lblProfileName",
            flxChatBoxProfileImg: "flxChatBoxProfileImg"
        };
        let messageDetails = [];
        storeMessages.messages.reverse().map(msg => {
            var messageDetailsdata = {
                lblChatBoxProfileName: msg.Sender === "Evaluator" ? evaluator : trainee,
                flxChatBoxProfileImg: {
                    skin: msg.Sender === "Evaluator" ? "sknflx7E6FFF" : "sknflxF37070"
                },
                lblRole: msg.Sender === "User" ? "Trainee" : "Evaluator",
                lblChatBoxRowMessages: msg.Message,
                lblDuration: this.getChatTime(msg.CreatedTs),
                lblProfileName: msg.Sender === "Evaluator" ? this.trimUserName(evaluator) : this.trimUserName(trainee),
            };
            messageDetails.push(messageDetailsdata);
        })
        scope.view.chatBoxContents.segchatBoxContents.widgetDataMap = dataMap;
        scope.view.chatBoxContents.segchatBoxContents.setData(messageDetails);
        scope.view.flxNinethRow.setVisibility(true);
        scope.view.btnCancelNew.setVisibility(true);
        scope.view.btnCancel.setVisibility(false);
        if (filesResponse === true) {
            kony.application.dismissLoadingScreen();
        }
    },
    createMessageDetailsChat: function(response) {
        const scope = this;
        const fromUser = AppToolBox.store.getItem("userDetails").ID;
        var params = {
            "ChatID": AppToolBox.store.getItem("ChatID"),
            "FromUser": fromUser,
            "ToUser": AppToolBox.store.getItem("Evaluator"),
            "Message": scope.view.txtComments.text,
        };
        const DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.createMessage(params);
        // kony.application.showLoadingScreen();
    },
    refreshChat: function(response) {
        let scope = this;
        var userData = this.getUserData();
        scope.view.txtComments.text = "";
        var ID = AppToolBox.store.getItem("segData").applicationID;
        AppToolBox.store.setItem("ApplicationID", ID);
        var params = {
            "ApplicationID": ID,
            "userID": AppToolBox.store.getItem("userDetails").ID
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getMessageDetailsChat(params);
    },
    hideChat: function() {
        const scope = this;
        // kony.application.dismissLoadingScreen();
        scope.view.chatBoxContents.segchatBoxContents.setData([]);
        scope.view.flxNinethRow.setVisibility(false);
        scope.view.btnCancel.setVisibility(true);
    },
    hideMessage: function() {
        animations.hideMessageNew(this.view.flxMessageContainer);
        kony.timer.cancel("MessagePopupTimer");
    },
    getChatTime: function(oldDate) {
        const scope = this;
        oldDate = new Date(oldDate);
        const currDate = new Date();
        let days = scope.getDifferenceInDays(oldDate, currDate)
        let hrs = scope.getDifferenceInHours(oldDate, currDate);
        let min = scope.getDifferenceInMinutes(oldDate, currDate);
        let sec = scope.getDifferenceInSeconds(oldDate, currDate);
        if (min < 5) {
            return ("Few mins ago..")
        } else if (min > 5 && hrs < 1) {
            return (`${Math.floor(min)} mins ago`)
        } else if (hrs > 1 && days < 1) {
            return (`${Math.floor(hrs)} hours ago`)
        } else if (Math.floor(days) === 1) {
            return (`${Math.floor(days)} day ago`)
        } else {
            return (`${Math.floor(days)} days ago`)
        }
    },
    getDifferenceInDays: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / (1000 * 60 * 60 * 24);
    },
    getDifferenceInHours: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / (1000 * 60 * 60);
    },
    getDifferenceInMinutes: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / (1000 * 60);
    },
    getDifferenceInSeconds: function(date1, date2) {
        const diffInMs = date2 - date1;
        return diffInMs / 1000;
    }
}));
define("DashBoard/frmAssessmentControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("DashBoard/frmAssessmentController", ["DashBoard/userfrmAssessmentController", "DashBoard/frmAssessmentControllerActions"], function() {
    var controller = require("DashBoard/userfrmAssessmentController");
    var controllerActions = ["DashBoard/frmAssessmentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
