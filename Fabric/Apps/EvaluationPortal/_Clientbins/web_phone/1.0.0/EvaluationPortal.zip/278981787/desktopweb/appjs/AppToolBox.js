define([], function() {
    function AppToolBox() {
        this.appInstance = null;
    }
    AppToolBox.util = AppToolBox.util || {};
    AppToolBox.util.isNil = function(object) {
        kony.print("AppToolBox.js.isNil " + object);
        var isEmpty = true;
        //is array, map or null
        if (typeof object === "object") {
            kony.print("AppToolBox.js.isNil-isObject");
            if (object === undefined || object === null || object.length === 0 || AppToolBox.util.isEmptyObject(object) === true) {
                isEmpty = true;
            } else {
                isEmpty = false;
            }
        }
        //is string
        else if (typeof object === "string") {
            kony.print("AppToolBox.js.isNil-isString");
            if (object === undefined || object === null || object == "undefined" || object == "null" || object === "") {
                isEmpty = true;
            } else {
                isEmpty = false;
            }
        }
        //other, probably number
        else if (object === undefined || object === null || isNaN(object)) {
            kony.print("AppToolBox.js.isNil-isOther");
            isEmpty = true;
        } else {
            isEmpty = false;
        }
        kony.print("AppToolBox.js.isNil-isEmpty " + isEmpty);
        return isEmpty;
    };
    AppToolBox.util.isEmptyObject = function(object) {
        try {
            for (var key in object) {
                if (object.hasOwnProperty(key)) return false;
            }
        } catch (e) {}
        return true;
    };
    AppToolBox.util.trimLeft = function(string, charlist) {
        if (charlist === undefined) charlist = "s";
        return string.replace(new RegExp("^[" + charlist + "]+"), "");
    };
    AppToolBox.util.isPositiveInteger = function(str) {
        var n = Math.floor(Number(str));
        return n !== Infinity && String(n) === str && n >= 0;
    };
    AppToolBox.util.isZero = function(str) {
        var n = parseInt(str);
        return isNaN(n) || n === 0;
    };
    AppToolBox.i18n = {
        //Retrieves the localised string of the current locale and replaces {1-n} with the provided arguments
        getText: function(key, args) {
            var i18nString = kony.i18n.getLocalizedString(key);
            if (AppToolBox.util.isNil(i18nString) === false) {
                var completedString = AppToolBox.util.fillTextWithParameters(i18nString, args);
                return completedString;
            } else {
                return key;
            }
        },
    };
    AppToolBox.date = {
        getCurrentDate: function() {
            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = "0" + dd;
            }
            if (mm < 10) {
                mm = "0" + mm;
            }
            return yyyy + "-" + mm + "-" + dd;
        },
        getDatePlusMinusMonths: function(months) {
            var today = new Date();
            today.setMonth(today.getMonth() + months);
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = "0" + dd;
            }
            if (mm < 10) {
                mm = "0" + mm;
            }
            return yyyy + "-" + mm + "-" + dd;
        },
        getDatePlusMinusDays: function(days) {
            var today = new Date();
            today.setDate(today.getDate() + days);
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = "0" + dd;
            }
            if (mm < 10) {
                mm = "0" + mm;
            }
            return yyyy + "-" + mm + "-" + dd;
        },
        getDateFormated: function(today) {
            today.setDate(today.getDate());
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
            if (dd < 10) {
                dd = "0" + dd;
            }
            if (mm < 10) {
                mm = "0" + mm;
            }
            return yyyy + "-" + mm + "-" + dd;
        },
        getMonthString: function(month) {
            const monthNames = ["", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", ];
            return monthNames[parseInt(month)];
        },
    };
    AppToolBox.loading = {
        show: function(msg) {
            kony.application.showLoadingScreen(null, msg, constants.LOADING_SCREEN_POSITION_ONLY_CENTER, true, true, {
                shouldShowLabelInBottom: "true",
                separatorHeight: 50,
                progressIndicatorColor: "20623b00",
            });
        },
        hint: function() {
            if (!AppToolBox.isLoadingShown) {
                kony.application.showLoadingScreen(null, "", constants.LOADING_SCREEN_POSITION_ONLY_CENTER, false, true, {
                    shouldShowLabelInBottom: "true",
                    separatorHeight: 50,
                    progressIndicatorColor: "20623b00",
                });
                AppToolBox.isLoadingShown = true;
            }
        },
        dismiss: function() {
            AppToolBox.isLoadingShown = false;
            kony.application.dismissLoadingScreen();
        },
    };
    AppToolBox.store = {
        getItem: function(key) {
            var value = kony.store.getItem(key);
            value = AppToolBox.util.isNil(value) === true ? null : value;
            return value;
        },
        setItem(key, value) {
            kony.store.setItem(key, value);
        },
        removeItem(key) {
            kony.store.removeItem(key);
        },
        clear() {
            kony.store.clear();
        },
    };
    AppToolBox.encrypt = function(inputString) {
        try {
            let algo = "aes";
            let encryptDecryptKey = kony.crypto.newKey("passphrase", 128, {
                passphrasetext: ["Aspiresystemsbfs"],
                subalgo: "aes",
                passphrasehashalgo: "md5"
            });
            let prptobj = {
                padding: "pkcs5",
                mode: "ecb",
            }
            let myEncryptedTextRaw = kony.crypto.encrypt(algo, encryptDecryptKey, inputString, prptobj);
            let myEncryptedText = kony.convertToBase64(myEncryptedTextRaw);
            let x = "Encrypted text = " + myEncryptedText.toString();
            kony.print(x + "  " + myEncryptedText + " " + myEncryptedTextRaw);
            return myEncryptedTextRaw;
        } catch (err) {
            alert("Error in callbackDecryptAes : " + err);
        }
    };
    AppToolBox.decrypt = function(value) {
        try {
            let algo = "aes";
            let encryptDecryptKey = kony.crypto.newKey("passphrase", 128, {
                passphrasetext: ["Aspiresystemsbfs"],
                subalgo: "aes",
                passphrasehashalgo: "md5",
            });
            let prptobj = {
                padding: "pkcs5",
                mode: "ecb",
            };
            let myClearText = kony.crypto.decrypt(algo, "Aspiresystemsbfs", value, prptobj);
            let decryptedStr = myClearText.toString();
            return decryptedStr;
        } catch (err) {
            alert("Error in callbackDecryptAes : " + err);
        }
    };
    AppToolBox.navigation = {
        navigateTo: function(formId) {
            new kony.mvc.Navigation(formId).navigate();
        },
        navigateToPreviousForm: function() {
            var ntf = new kony.mvc.Navigation(kony.application.getPreviousForm().id);
            ntf.navigate();
        },
        getPreviousFormId: function() {
            return kony.application.getPreviousForm().id;
        },
        getCurrentFormId: function() {
            return kony.application.getCurrentForm().id;
        },
    };
    AppToolBox.filterUser = function(value) {
        var user = [];
        for (var i = 0; i < value.length; i++) {
            if (value[i].isActive === "true") {
                user.push(value[i]);
            }
        }
        return user;
    };
    AppToolBox.filterApp = function(res) {
        var user = AppToolBox.store.getItem("UserDetailCount");
        var app = [];
        for (var i = 0; i < res.length; i++) {
            for (var j = 0; j < user.length; j++) {
                if (res[i].UserID === user[j].ID) {
                    app.push(res[i]);
                }
            }
        }
        return app;
    };
    return AppToolBox;
});