define("Evaluator/userfrmEvaluatorDashController", ["AppToolBox"], (AppToolBox) => ({
    onNavigate: function() {
        this.view.preShow = this.preShow;
        this.view.postShow = this.postShow;
    },
    preShow: function() {
        kony.application.showLoadingScreen();
        this.view.flxChart.setVisibility(true);
        const scope = this;
        const userDetails = AppToolBox.store.getItem("userDetails");
        const params = {
            "EvaluatorID": userDetails.ID
        };
        //     this.view.flxChart.setVisibility(visible);
        this.fetchAppStatus;
        scope.view.onDeviceBack = function() {};
        const DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.getAllApp(params);
        scope.view.segAssessmentList.onRowClick = this.navToApproval.bind(this);
        scope.view.flxQuickLinks1.flxQuickLinks1.onClick = scope.navToForm.bind(scope, "frmAssignedAssessment");
        scope.view.lstBoxStatus.selectedKey = "lbl1";
        scope.view.lstBoxStatus.onSelection = scope.setAssessmentList;
        scope.view.lblViewAll.onTouchStart = scope.navToForm.bind(scope, "frmAssignedAssessment");
    },
    navToForm: function(form) {
        kony.application.showLoadingScreen();
        const nav = new kony.mvc.Navigation(form);
        // nav.navigate("ALLSTATUS");
        nav.navigate(this.view.lstBoxStatus.selectedKeyValue[1].toString().toUpperCase());
    },
    navToApproval: function() {
        var selectedData = this.view.segAssessmentList.selectedRowItems[0];
        AppToolBox.store.setItem("RowData", selectedData);
        AppToolBox.navigation.navigateTo("frmApprovalAssessment");
    },
    onHide: function() {
        kony.application.showLoadingScreen();
        this.view.flxChart.remove(this.view.multiseriesverticalbar);
        kony.application.dismissLoadingScreen();
    },
    fetchAppStatus: function() {
        var widgetArray = [];
        StatusArray = [];
        roleArray = [];
        barDetailArray = [];
        RoleResponse = AppToolBox.store.getItem("userRolesResponse");
        AppStatusResponse = AppToolBox.store.getItem("AppStatusResponse");
        for (var role = 0; role < RoleResponse.length; role++) {
            roleArray[role] = RoleResponse[role].RoleName;
        }
        widgetArray = this.view.flxChart.widgets();
        if (widgetArray.length > 1) {
            this.onHide();
        }
        statusClrCode = ["#3ea6f0", "#f3c11b", "#e05151", "#8a38f5", "#28c758", "#d20006"];
        kony.application.dismissLoadingScreen();
        selectedStatus = "All_User";
        chartArray = [];
        array3 = [];
        array = [];
        array4 = [];
        for (var t = 0; t < RoleResponse.length; t++) {
            for (var q = 0; q < AppStatusResponse.length; q++) {
                StatusArray[q] = AppStatusResponse[q].Status;
                cd = '' + t + q;
                chartArray[cd] = 0;
            }
        }
        var date = new Date();
        var current_date = date.getFullYear() + "-" + (date.getMonth() + 1) + "-" + date.getDate();
        current_date = current_date.toString();
        len = AppToolBox.store.getItem("applicationData").length;
        if (AppToolBox.store.getItem("applicationData").length > 0) {
            for (var j = 0; j < len; j++) {
                var applicationStatus = AppToolBox.store.getItem("applicationData")[j].ApplicationStatus;
                var roleID = AppToolBox.store.getItem("applicationData")[j].RoleID;
                for (var a = 0; a < RoleResponse.length; a++) {
                    for (var b = 0; b < AppStatusResponse.length; b++) {
                        if ((roleID === roleArray[a]) && (applicationStatus === StatusArray[b])) {
                            size = '' + (RoleResponse.length) + (AppStatusResponse.length);
                            var abc = '' + a + b;
                            chartArray[abc] = chartArray[abc] + 1;
                            //               }
                        }
                    }
                }
            }
            for (var g = 0; g < RoleResponse.length; g++) {
                m = new Map();
                compare = roleArray[g];
                if ((roleArray[g] === "ADMIN")) {} else if (roleArray[g] === "EVALUATOR") {} else {
                    var axisLabel = roleArray[g].toLowerCase().replace("_", " ");
                    labelCap = axisLabel.charAt(0).toUpperCase();
                    axisLabel = labelCap + axisLabel.slice(1);
                    m.set("label", axisLabel);
                    //           var label=roleArray[g].toLowerCase();
                    //         m.set("label",label.replace("_"," "));
                    for (var f = 0; f < AppStatusResponse.length; f++) {
                        var ab = '' + g + f;
                        const v = f + 1;
                        var u = ":";
                        m.set("value" + v, chartArray[ab]);
                        array4.push(chartArray[ab]);
                    }
                    obj = Object.fromEntries(m);
                    var jsonString = JSON.stringify(obj);
                    array.push(obj);
                }
            }
            m = new Map();
            m.set("label", "Total");
            arrayTotal = [];
            for (var n = 0; n < AppStatusResponse.length; n++) {
                val1 = 0;
                total = [];
                value = [];
                for (l = 0; l < RoleResponse.length; l++) {
                    var nl = '' + l + n;
                    val1 = chartArray[nl] + val1;
                }
                l = 0;
                const num = Number(n) + 1;
                m.set("value" + num, val1);
                arrayTotal.push(val1);
            }
            const obj2 = Object.fromEntries(m);
            array.push(obj2);
            max1 = Math.max(...arrayTotal);
        }
        chartDataSize = array.length;
        selectedStatus = selectedStatus.replace(" ", "_");
        if (selectedStatus === "All_User") {
            //         count1=count1+1;
            this.view.flxChart.setVisibility(true);
            this.showAllUserChart(max1);
            //        this.showChart(max1);
        }
    },
    showAllUserChart: function(max1) {
        //     multiseriesverticalbar = new com.konymp.multiseriesverticalbar(
        //       {
        //         "autogrowMode": kony.flex.AUTOGROW_NONE,
        //         "clipBounds": true,
        //         "height": "98%",
        //         "id": "multiseriesverticalbar",
        //         "isVisible": true,
        //         "layoutType": kony.flex.FREE_FORM,
        //         "left": "1%",
        //         "masterType": constants.MASTER_TYPE_USERWIDGET,
        //         "skin": "CopyCopyslFbox1",
        //         "top": "0%",
        //         "width": "98%"
        //       }, {}, {});
        barDetailArray = [];
        var maxvalue = max1.toString();
        for (var color = 0; color < AppStatusResponse.length; color++) {
            const colorMap = new Map();
            var bardata = '';
            bardata = "{color" + ":}";
            //       colorMap.set("color", this.generateRandomColor());
            colorMap.set("color", statusClrCode[color]);
            var legendName = StatusArray[color].toLowerCase();
            var legendCaps = legendName.charAt(0).toUpperCase();
            legendName = legendCaps + StatusArray[color].toLowerCase().slice(1);
            colorMap.set("legendName", legendName);
            const obj2 = Object.fromEntries(colorMap);
            barDetailArray.push(obj2);
        }
        kony.application.dismissLoadingScreen();
        this.view.multiseriesverticalbar.seriesBarDistance = "32";
        this.view.multiseriesverticalbar.barWidth = "25";
        this.view.multiseriesverticalbar.chartTitle = "";
        this.view.multiseriesverticalbar.xAxisTitle = " ";
        this.view.multiseriesverticalbar.yAxisTitle = "";
        this.view.multiseriesverticalbar.highValue = maxvalue;
        this.view.multiseriesverticalbar.enableGrid = true;
        var dataSet = array;
        var barDetails = barDetailArray;
        this.view.multiseriesverticalbar.createChart(dataSet, barDetails);
        this.view.multiseriesverticalbar.chartData = {
            "data": dataSet
        };
        this.view.multiseriesverticalbar.barDetails = {
            //       "data": barDetailArray};
            "data": barDetailArray
        };
        //     this.view.flxChart.add(multiseriesverticalbar);
    },
    setAssessmentList: function() {
        const scope = this;
        let appStatus = scope.view.lstBoxStatus.selectedKeyValue[1].toUpperCase();
        scope.view.flxStatusFilterPopup.isVisible = false;
        scope.view.flxRoleFilterPopup.isVisible = false;
        const data = AppToolBox.store.getItem("applicationData") && AppToolBox.store.getItem("applicationData").reverse();
        const status = AppToolBox.store.getItem("AppStatusResponse");
        let AssessmentList = [];
        const dataMap = {
            lblAssessmentName: "lblAssessmentName",
            lblDuration: "lblDuration",
            lblAssigneeName: "lblAssigneeName",
            lblRole: "lblRole",
            lblStatus: "lblStatus",
            flxStatus: "flxStatus",
            flxRole: "flxRole",
            flxAssigneeName: "flxAssigneeName",
            imgSortRole: "imgSortRole",
            imgSortAssignee: "imgSortAssignee",
            imgSortStatus: "imgSortStatus"
        };
        let userName;
        let appName;
        let assessID;
        let submittedDate = null;
        scope.view.segAssessmentList.widgetDataMap = dataMap;
        let applications = data.map(app => {
            userName = app.Name;
            let assessmentName = {
                "text": app.AssessmentName,
                "isVisible": true
            };
            let Details;
            let date = app.StartDate;
            let Duration = app.Duration;
            if (app.ApplicationStatus === "INITIATED") {
                Details = "Duration: " + Duration + " Days";
            } else if (app.ApplicationStatus === "INPROGRESS") {
                var RemainDays = Duration - scope.diffDays(date);
                Details = "Remaining Days: " + Math.abs(RemainDays) + " Days";
            } else if (app.ApplicationStatus === "OVERDUE") {
                var OverdueDays = Duration - scope.diffDays(date);
                Details = "Time Lag: " + Math.abs(OverdueDays) + " Days";
            } else if (app.ApplicationStatus === "FAILED") {
                Details = "Rejected On: " + scope.formatDate(app.UpdatedTs.slice(0, 10)); + " Days";
            } else if (app.ApplicationStatus === "COMPLETED") {
                submittedDate = scope.formatDate(app.UpdatedTs.slice(0, 10));
                Details = "Approved On: " + submittedDate;
            } else if (app.ApplicationStatus === "SUBMITTED") {
                submittedDate = scope.formatDate(app.UpdatedTs.slice(0, 10));
                Details = "Submitted On: " + submittedDate;
            }
            assessmentName = {
                "text": app.AssessmentName,
                "skin": "sknlblbreadcrumb411062"
            };
            var Role = app.Role.replace("_", " ");
            var statusskn = app.ApplicationStatus === "INITIATED" ? "sknlblFFFBFBbg7E6FFF" : app.ApplicationStatus === "INPROGRESS" ? "sknlblFFFBFBbgFFCC29" : app.ApplicationStatus === "OVERDUE" || app.ApplicationStatus === "FAILED" ? "sknlblFFFBFBbgF37070" : "sknlblFFFBFBbg4ECC48";
            var AssessLst = {
                lblAssessmentName: assessmentName,
                lblDuration: userName,
                lblAssigneeName: Role,
                lblRole: Details,
                submittedDate: submittedDate,
                Duration: Duration,
                assessID: app.AssessmentID,
                role: app.Role,
                AppID: app.ApplicationID,
                status: app.ApplicationStatus,
                assessmentInstruction: app.AssessmentInstruction,
                userID: app.UserID,
                lblStatus: {
                    text: app.ApplicationStatus === "INPROGRESS" ? "In-progress" : app.ApplicationStatus.charAt(0) + app.ApplicationStatus.slice(1).toLowerCase(),
                    skin: statusskn
                }
            };
            return AssessLst;
        })
        if (appStatus !== "ALL STATUS") {
            applications = applications.filter(app => {
                return app.status === appStatus;
            })
        }
        applications.length > 5 ? scope.view.lblViewAll.setVisibility(true) : scope.view.lblViewAll.setVisibility(false);
        applications = applications.slice(0, 5);
        var allUsers = [
            [{
                lblAssessmentName: "ASSESSMENT NAME",
                lblDuration: "ASSIGNEE NAME",
                lblAssigneeName: "ASSIGNEE ROLE",
                lblRole: "DETAILS",
                lblStatus: "STATUS",
                imgSortAssignee: {
                    "isVisible": false
                },
                imgSortRole: {
                    "isVisible": false
                },
                imgSortStatus: {
                    "isVisible": false
                }
            }, applications]
        ];
        this.view.segAssessmentList.setData(allUsers);
        kony.application.dismissLoadingScreen();
    },
    diffDays: function(date2) {
        var dt1 = new Date(date2);
        var dt2 = new Date();
        var diff = Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24));
        return diff;
    },
    formatDate: function(date) {
        const [year, month, day] = date.split('-');
        const result = [day, month, year].join('/');
        return result;
    },
}));
define("Evaluator/frmEvaluatorDashControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
});
define("Evaluator/frmEvaluatorDashController", ["Evaluator/userfrmEvaluatorDashController", "Evaluator/frmEvaluatorDashControllerActions"], function() {
    var controller = require("Evaluator/userfrmEvaluatorDashController");
    var controllerActions = ["Evaluator/frmEvaluatorDashControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
