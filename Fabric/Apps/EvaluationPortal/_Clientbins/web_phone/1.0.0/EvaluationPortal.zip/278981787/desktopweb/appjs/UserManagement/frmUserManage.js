define("UserManagement/frmUserManage", function() {
    return function(controller) {
        function addWidgetsfrmUserManage() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMainContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMainContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContainer.setDefaultUnit(kony.flex.DP);
            var flxHeaderNew = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeaderNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "zIndex": 3,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderNew.setDefaultUnit(kony.flex.DP);
            var headerNew1 = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxUserRoleName": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "35%"
                    },
                    "headerNew": {
                        "height": "100%",
                        "isVisible": true
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderNew.add(headerNew1);
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": false,
                "height": "82%",
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxMessageContainer = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "7%",
                "id": "flxMessageContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "-2dp",
                "isModalContainer": false,
                "skin": "sknflxBottom",
                "top": "-13%",
                "width": "100%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMessageContainer.setDefaultUnit(kony.flex.DP);
            var msgContainer = new com.evaluationPortal.msgContainer.msgContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "msgContainer",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxMessageContainer": {
                        "height": "100%",
                        "left": "-3dp",
                        "top": "0dp"
                    },
                    "imgClose": {
                        "src": "close_white_solid.png"
                    },
                    "lblMessage": {
                        "text": "Deepika Bala User deactivated successfully"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxMessageContainer.add(msgContainer);
            var flxBodyScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bottom": "0%",
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxBodyScroll",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyScroll.setDefaultUnit(kony.flex.DP);
            var flxBodyUser = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "100%",
                "id": "flxBodyUser",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "3%",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyUser.setDefaultUnit(kony.flex.DP);
            var flxBreadCrumbManageUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8%",
                "id": "flxBreadCrumbManageUser",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "28dp",
                "width": "94%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBreadCrumbManageUser.setDefaultUnit(kony.flex.DP);
            var BreadCrum = new com.evaluationPortal.breadCrum.BreadCrum({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "BreadCrum",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "imgArrow1": {
                        "src": "right_arrow_solid.png"
                    },
                    "imgArrow2": {
                        "isVisible": false,
                        "src": "right_arrow_solid.png"
                    },
                    "imgHome": {
                        "src": "home_solid.png"
                    },
                    "lblBreadcrum1": {
                        "text": "Dashboard"
                    },
                    "lblBreadcrum2": {
                        "isVisible": false
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var flxRightQuicklinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRightQuicklinks",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "80%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "40px",
                "width": "60%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightQuicklinks.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks": {
                        "left": "0dp"
                    },
                    "flxQuickLinks1": {
                        "zIndex": 2
                    },
                    "flxQuickLinks2": {
                        "isVisible": false
                    },
                    "flxQuickLinks3": {
                        "isVisible": false
                    },
                    "flxQuickLinks4": {
                        "isVisible": false
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "imgQuickLinks3": {
                        "src": "managerole.png"
                    },
                    "imgQuickLinks4": {
                        "src": "managerole.png"
                    },
                    "lblQuickLinks1": {
                        "text": "Create Role"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage Role"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightQuicklinks.add(flxQuickLinks);
            flxBreadCrumbManageUser.add(BreadCrum, flxRightQuicklinks);
            var flxCreateUserMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "85%",
                "id": "flxCreateUserMain",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateUserMain.setDefaultUnit(kony.flex.DP);
            var flxLeft = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeft",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "75%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeft.setDefaultUnit(kony.flex.DP);
            var flxTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTop",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxTop.setDefaultUnit(kony.flex.DP);
            var lblCreateRole = new kony.ui.Label({
                "id": "lblCreateRole",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl000000font28px",
                "text": "Create User",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTop.add(lblCreateRole);
            var flxCreateUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxCreateUser",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknflxfff15pxradius",
                "top": "21dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateUser.setDefaultUnit(kony.flex.DP);
            var flxCreateUserContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "40dp",
                "clipBounds": false,
                "id": "flxCreateUserContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxCreateUserContent.setDefaultUnit(kony.flex.DP);
            var flxAddRoleRow1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAddRoleRow1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "34dp",
                "width": "90%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRoleRow1.setDefaultUnit(kony.flex.DP);
            var flxColumn1 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxColumn1",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn1.setDefaultUnit(kony.flex.DP);
            var lblUserName = new kony.ui.Label({
                "id": "lblUserName",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "User Name",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBoxUserName = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "skntxtcccccc8pxradiusfff",
                "height": "44dp",
                "id": "txtBoxUserName",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "skin": "skntxtcccccc8pxradiusfff",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            flxColumn1.add(lblUserName, txtBoxUserName);
            var flxColumn2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxColumn2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "2%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxColumn2.setDefaultUnit(kony.flex.DP);
            var lblEmail = new kony.ui.Label({
                "id": "lblEmail",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Email ID",
                "top": "0",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var txtBoxEmail = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtBoxEmail",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0",
                "secureTextEntry": false,
                "skin": "skntxtcccccc8pxradiusfff",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "13dp",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "defTextBoxPlaceholder"
            });
            var lblInvalidEmail = new kony.ui.Label({
                "id": "lblInvalidEmail",
                "isVisible": false,
                "left": "0",
                "skin": "sknlblLatoReg16pxPurple",
                "text": "Invalid Email.",
                "top": "10dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxColumn2.add(lblEmail, txtBoxEmail, lblInvalidEmail);
            flxAddRoleRow1.add(flxColumn1, flxColumn2);
            var flxAddRoleRow2 = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "clipBounds": false,
                "id": "flxAddRoleRow2",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "25dp",
                "width": "90%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRoleRow2.setDefaultUnit(kony.flex.DP);
            var lblRoleID = new kony.ui.Label({
                "id": "lblRoleID",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl13px666666",
                "text": "Role",
                "top": "0dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxDropDown = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDropDown",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "13dp",
                "width": "49%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDown.setDefaultUnit(kony.flex.DP);
            var flxDopDownHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "44dp",
                "id": "flxDopDownHeader",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDopDownHeader.setDefaultUnit(kony.flex.DP);
            var txtBoxDropDown = new kony.ui.TextBox2({
                "autoCapitalize": constants.TEXTBOX_AUTO_CAPITALIZE_NONE,
                "centerY": "50%",
                "focusSkin": "defTextBoxFocus",
                "height": "44dp",
                "id": "txtBoxDropDown",
                "isVisible": true,
                "keyBoardStyle": constants.TEXTBOX_KEY_BOARD_STYLE_DEFAULT,
                "left": "0%",
                "placeholder": "Select a Role",
                "secureTextEntry": false,
                "skin": "skntxtcccccc8pxradiusfff",
                "textInputMode": constants.TEXTBOX_INPUT_MODE_ANY,
                "top": "0%",
                "width": "100%"
            }, {
                "containerHeightMode": constants.TEXTBOX_FONT_METRICS_DRIVEN_HEIGHT,
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [3, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "autoCorrect": false,
                "placeholderSkin": "skntxtplaceholderfff"
            });
            var imgDropdownArrow = new kony.ui.Image2({
                "centerY": "50%",
                "height": "26dp",
                "id": "imgDropdownArrow",
                "isVisible": true,
                "left": "85%",
                "skin": "slImage",
                "src": "polygon_6.png",
                "top": "22dp",
                "width": "44dp",
                "zIndex": 1
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDopDownHeader.add(txtBoxDropDown, imgDropdownArrow);
            flxDropDown.add(flxDopDownHeader);
            flxAddRoleRow2.add(lblRoleID, flxDropDown);
            var flxAddRoleButtons = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAddRoleButtons",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "reverseLayoutDirection": true,
                "isModalContainer": false,
                "right": "40dp",
                "skin": "slFbox",
                "top": "4dp",
                "width": "32%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAddRoleButtons.setDefaultUnit(kony.flex.DP);
            var btnCreate = new kony.ui.Button({
                "bottom": "0dp",
                "centerY": "50dp",
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "40dp",
                "id": "btnCreate",
                "isVisible": true,
                "left": "11dp",
                "skin": "sknbtnprimaryFFFFFF411062",
                "text": "Create",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnEdit = new kony.ui.Button({
                "bottom": "0dp",
                "centerY": "50dp",
                "focusSkin": "sknbtnprimaryFFFFFF411062",
                "height": "40dp",
                "id": "btnEdit",
                "isVisible": false,
                "left": "11dp",
                "skin": "sknbtnsecondaryFFFFFF411062",
                "text": "Submit",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var btnCancel = new kony.ui.Button({
                "centerY": "50dp",
                "focusSkin": "sknbtnsecondaryFFFFFF411062",
                "height": "40dp",
                "id": "btnCancel",
                "isVisible": true,
                "skin": "sknbtnsecondaryFFFFFF411062",
                "text": "Cancel",
                "top": "0",
                "width": "131dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_CENTER,
                "displayText": true,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAddRoleButtons.add(btnCreate, btnEdit, btnCancel);
            flxCreateUserContent.add(flxAddRoleRow1, flxAddRoleRow2, flxAddRoleButtons);
            flxCreateUser.add(flxCreateUserContent);
            flxLeft.add(flxTop, flxCreateUser);
            var flxRight = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRight",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "25%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRight.setDefaultUnit(kony.flex.DP);
            var flxQuickLinks1 = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks": {
                        "height": "100%"
                    },
                    "flxQuickLinks1": {
                        "width": "100%"
                    },
                    "flxQuickLinks2": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks3": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks4": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "imgQuickLinks3": {
                        "src": "managerole.png"
                    },
                    "imgQuickLinks4": {
                        "src": "managerole.png"
                    },
                    "lblQuickLinks": {
                        "top": "0dp"
                    },
                    "lblQuickLinks1": {
                        "text": "Create User"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage User"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRight.add(flxQuickLinks1);
            flxCreateUserMain.add(flxLeft, flxRight);
            var flxManageUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "20dp",
                "clipBounds": false,
                "height": "100%",
                "id": "flxManageUser",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageUser.setDefaultUnit(kony.flex.DP);
            var flxLeftManageUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxLeftManageUser",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "75%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLeftManageUser.setDefaultUnit(kony.flex.DP);
            var flxTopManageUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "40dp",
                "id": "flxTopManageUser",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxTopManageUser.setDefaultUnit(kony.flex.DP);
            var lblManageUser = new kony.ui.Label({
                "id": "lblManageUser",
                "isVisible": true,
                "left": "0%",
                "skin": "sknlbl000000font28px",
                "text": "Manage User",
                "top": "0px",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxTopManageUser.add(lblManageUser);
            var flxManageUserBody = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "90%",
                "id": "flxManageUserBody",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "21dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageUserBody.setDefaultUnit(kony.flex.DP);
            var segManageUser = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [
                    [{
                            "imgSortActions": "sort_down_solid.png",
                            "imgSortDuration": "sort_down_solid.png",
                            "imgSortName": "sort_down_solid.png",
                            "imgSortRole": "sort_down_solid.png",
                            "lblActions": "ACTION",
                            "lblEmailIDHeader": "EMAIL ID",
                            "lblRoleHeader": "ROLE",
                            "lblUserNameHeader": "USER NAME"
                        },
                        [{
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }, {
                            "imgDeletebtn": "x__1_.png",
                            "imgEditRole": "vector__3_.png",
                            "imgViewRole": "vector__2_.png",
                            "lblDeletebtn": "Deactivate",
                            "lblEditRole": "Edit",
                            "lblEmail": "Label",
                            "lblRoleName": "Label",
                            "lblUserName": "Label",
                            "lblViewRole": "View"
                        }]
                    ]
                ],
                "groupCells": false,
                "height": "100%",
                "id": "segManageUser",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknflxnofff",
                "rowTemplate": "flxUserManagement",
                "sectionHeaderTemplate": "flxManageUserHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxActions": "flxActions",
                    "flxDeactiveUserbtn": "flxDeactiveUserbtn",
                    "flxEditRole": "flxEditRole",
                    "flxEmailID": "flxEmailID",
                    "flxManageUserHeader": "flxManageUserHeader",
                    "flxRoleName": "flxRoleName",
                    "flxRows": "flxRows",
                    "flxSeperatHead": "flxSeperatHead",
                    "flxUserListHeader": "flxUserListHeader",
                    "flxUserManagement": "flxUserManagement",
                    "flxUserName": "flxUserName",
                    "flxViewRole": "flxViewRole",
                    "imgDeletebtn": "imgDeletebtn",
                    "imgEditRole": "imgEditRole",
                    "imgSortActions": "imgSortActions",
                    "imgSortDuration": "imgSortDuration",
                    "imgSortName": "imgSortName",
                    "imgSortRole": "imgSortRole",
                    "imgViewRole": "imgViewRole",
                    "lblActions": "lblActions",
                    "lblDeletebtn": "lblDeletebtn",
                    "lblEditRole": "lblEditRole",
                    "lblEmail": "lblEmail",
                    "lblEmailIDHeader": "lblEmailIDHeader",
                    "lblRoleHeader": "lblRoleHeader",
                    "lblRoleName": "lblRoleName",
                    "lblUserName": "lblUserName",
                    "lblUserNameHeader": "lblUserNameHeader",
                    "lblViewRole": "lblViewRole"
                },
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxManageUserBody.add(segManageUser);
            flxLeftManageUser.add(flxTopManageUser, flxManageUserBody);
            var flxRightManageUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxRightManageUser",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "25%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRightManageUser.setDefaultUnit(kony.flex.DP);
            var flxQuicksLinks = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuicksLinks",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxQuickLinks": {
                        "height": "100%"
                    },
                    "flxQuickLinks1": {
                        "width": "100%"
                    },
                    "flxQuickLinks2": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks3": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinks4": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "imgQuickLinks1": {
                        "src": "add_solid.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "lblQuickLinks": {
                        "top": "0dp"
                    },
                    "lblQuickLinks1": {
                        "text": "Create User"
                    },
                    "lblQuickLinks2": {
                        "text": "Manage Role"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxRightManageUser.add(flxQuicksLinks);
            flxManageUser.add(flxLeftManageUser, flxRightManageUser);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3%",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "appFooter": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "copyrightFooter": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(appFooter, copyrightFooter);
            flxBodyUser.add(flxBreadCrumbManageUser, flxCreateUserMain, flxManageUser, flxFooter);
            var flxDropDownValues = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "39%",
                "id": "flxDropDownValues",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "6.50%",
                "isModalContainer": false,
                "skin": "sknflxShadow",
                "top": "340dp",
                "width": "30%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDropDownValues.setDefaultUnit(kony.flex.DP);
            var segDropDown = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "data": [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}],
                "groupCells": false,
                "height": "100%",
                "id": "segDropDown",
                "isVisible": true,
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxFilterPopup",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0dp",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {},
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxDropDownValues.add(segDropDown);
            flxBodyScroll.add(flxBodyUser, flxDropDownValues);
            flxMainContent.add(flxMessageContainer, flxBodyScroll);
            var flxPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "centerY": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "sknDeletePopup",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxPopup.setDefaultUnit(kony.flex.DP);
            var flxPopup1 = new com.evaluationPortal.popup.flxPopup({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxPopup1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "btnDelete": {
                        "text": "Deactivate"
                    },
                    "flxPopup": {
                        "isVisible": true
                    },
                    "imgClose": {
                        "src": "close_black_solid.png"
                    },
                    "lblPopupHeader": {
                        "text": "Deactivate User"
                    },
                    "lblPopupMessage": {
                        "text": "Are you sure you want to deactivate this User?"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxPopup.add(flxPopup1);
            flxMainContainer.add(flxHeaderNew, flxMainContent, flxPopup);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew1.flxUserRoleName": {
                    "centerY": "",
                    "top": "35%"
                },
                "headerNew1": {
                    "height": "100%"
                },
                "headerNew1.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew1.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew1.imgUserImage": {
                    "src": "userimg.png"
                },
                "msgContainer.flxMessageContainer": {
                    "height": "100%",
                    "left": "-3dp",
                    "top": "0dp"
                },
                "msgContainer.imgClose": {
                    "src": "close_white_solid.png"
                },
                "msgContainer.lblMessage": {
                    "text": "Deepika Bala User deactivated successfully"
                },
                "BreadCrum.imgArrow1": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgArrow2": {
                    "src": "right_arrow_solid.png"
                },
                "BreadCrum.imgHome": {
                    "src": "home_solid.png"
                },
                "BreadCrum.lblBreadcrum1": {
                    "text": "Dashboard"
                },
                "flxQuickLinks": {
                    "left": "0dp"
                },
                "flxQuickLinks.flxQuickLinks1": {
                    "zIndex": 2
                },
                "flxQuickLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuickLinks.imgQuickLinks3": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.imgQuickLinks4": {
                    "src": "managerole.png"
                },
                "flxQuickLinks.lblQuickLinks1": {
                    "text": "Create Role"
                },
                "flxQuickLinks.lblQuickLinks2": {
                    "text": "Manage Role"
                },
                "flxQuickLinks1": {
                    "height": "100%",
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks2": {
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks3": {
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks4": {
                    "width": "100%"
                },
                "flxQuickLinks1.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuickLinks1.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuickLinks1.imgQuickLinks3": {
                    "src": "managerole.png"
                },
                "flxQuickLinks1.imgQuickLinks4": {
                    "src": "managerole.png"
                },
                "flxQuickLinks1.lblQuickLinks": {
                    "top": "0dp"
                },
                "flxQuickLinks1.lblQuickLinks1": {
                    "text": "Create User"
                },
                "flxQuickLinks1.lblQuickLinks2": {
                    "text": "Manage User"
                },
                "flxQuicksLinks": {
                    "height": "100%"
                },
                "flxQuicksLinks.flxQuickLinks1": {
                    "width": "100%"
                },
                "flxQuicksLinks.flxQuickLinks2": {
                    "width": "100%"
                },
                "flxQuicksLinks.flxQuickLinks3": {
                    "width": "100%"
                },
                "flxQuicksLinks.flxQuickLinks4": {
                    "width": "100%"
                },
                "flxQuicksLinks.imgQuickLinks1": {
                    "src": "add_solid.png"
                },
                "flxQuicksLinks.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuicksLinks.lblQuickLinks": {
                    "top": "0dp"
                },
                "flxQuicksLinks.lblQuickLinks1": {
                    "text": "Create User"
                },
                "flxQuicksLinks.lblQuickLinks2": {
                    "text": "Manage Role"
                },
                "appFooter": {
                    "centerY": "",
                    "top": "0dp"
                },
                "copyrightFooter": {
                    "centerY": "",
                    "top": "0dp"
                },
                "flxPopup1.btnDelete": {
                    "text": "Deactivate"
                },
                "flxPopup1.imgClose": {
                    "src": "close_black_solid.png"
                },
                "flxPopup1.lblPopupHeader": {
                    "text": "Deactivate User"
                },
                "flxPopup1.lblPopupMessage": {
                    "text": "Are you sure you want to deactivate this User?"
                }
            }
            this.add(flxMainContainer);
        };
        return [{
            "addWidgets": addWidgetsfrmUserManage,
            "enabledForIdleTimeout": false,
            "id": "frmUserManage",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknfrmbgimg",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_cc11c81d9475401fb9fbc1858e3e107a,
            "retainScrollPosition": false
        }]
    }
});