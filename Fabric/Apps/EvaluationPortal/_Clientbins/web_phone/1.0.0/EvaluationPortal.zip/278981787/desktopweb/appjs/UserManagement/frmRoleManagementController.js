define("UserManagement/userfrmRoleManagementController", ["AppToolBox", "animations"], (AppToolBox, animations) => ({
    onNavigate: function(flow) {
        this.view.preShow = this.preShow.bind(this, flow);
        this.view.postShow = this.postShow;
        this.view.onDeviceBack = () => {};
    },
    preShow: function(flow) {
        this.view.txtBoxRoleID.skin = "skntxtcccccc8pxradiusfff";
        this.view.txtBoxRoleName.skin = "skntxtcccccc8pxradiusfff";
        this.view.txtRoleDescription.skin = "skntxtcccccc8pxradiusfff";
        this.view.txtBoxRoleName.restrictCharactersSet = "~#^|$%&*!@_-=+/?<>{}:;`[]'()^[^\"]*$^[^\\]*$";
        this.view.msgContainer.imgClose.onTouchStart = this.hideMessage;
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navigationBreadcrum;
        if (flow === "addRole") {
            this.view.flxCreateRoleMain.setVisibility(true);
            this.view.flxManageRole.setVisibility(false);
            this.view.flxQuickLinks1.flxQuickLinks1.setVisibility(false);
            this.view.flxQuickLinks1.flxQuickLinks2.setVisibility(true);
            this.view.BreadCrum.lblBreadcrum1.text = "Manage Role";
            this.view.lblCreateRole.text = "Create Role";
            this.view.btnCreate.setVisibility(true);
            this.view.btnCreate.setEnabled(false);
            this.view.btnCreate.skin = "sknbtndisabledeee666";
            this.view.txtBoxRoleID.onTextChange = this.fieldValidation;
            this.view.txtBoxRoleName.onTextChange = this.fieldValidation;
            this.view.txtRoleDescription.onTextChange = this.fieldValidation;
        } else if (flow === "manageRole") {
            this.view.flxCreateRoleMain.setVisibility(false);
            this.view.flxManageRole.setVisibility(true);
            this.view.flxQuickLinks1.flxQuickLinks1.setVisibility(true);
            this.view.flxQuickLinks1.flxQuickLinks2.setVisibility(false);
            this.view.BreadCrum.lblBreadcrum1.text = "Dashboard";
            this.view.BreadCrum.imgArrow2.setVisibility(false);
            this.view.BreadCrum.lblBreadcrum2.setVisibility(false);
        }
        this.setUserRoles();
        this.view.btnCreate.onClick = this.createUserRole.bind(this, "create");
        this.view.btnCancel.onClick = () => {
            //this.view.flxCreateRoleMain.setVisibility(false);
            //this.view.flxManageRole.setVisibility(true);
            this.preShow("manageRole");
            this.resetData();
        };
        this.view.flxQuickLinks1.flxQuickLinks1.onClick = this.view.flxQuickLink.flxQuickLinks1.onClick = () => {
            this.preShow("addRole");
            this.resetData();
        };
        this.view.flxQuickLinks1.flxQuickLinks2.onClick = () => {
            this.preShow("manageRole");
        };
    },
    navigationBreadcrum: function() {
        var breadcrumValue = this.view.BreadCrum.lblBreadcrum1.text;
        if (breadcrumValue === "Manage Role") this.preShow("manageRole");
        else if (breadcrumValue === "Dashboard") AppToolBox.navigation.navigateTo("frmAdminDash");
    },
    resetData: function() {
        let scope = this;
        scope.view.txtBoxRoleID.text = "";
        scope.view.txtBoxRoleName.text = "";
        scope.view.txtRoleDescription.text = "";
        scope.view.txtBoxRoleID.setEnabled(true);
        scope.view.txtBoxRoleName.setEnabled(true);
        scope.view.txtRoleDescription.setEnabled(true);
        scope.view.btnCreate.text = "Create";
        scope.view.btnCancel.text = "Cancel";
        scope.view.btnCancel.setVisibility(true);
        scope.view.lblCreateRole.text = "Create Role";
        scope.view.txtBoxRoleID.skin = "skntxtcccccc8pxradiusfff";
        scope.view.txtBoxRoleName.skin = "skntxtcccccc8pxradiusfff";
        scope.view.txtRoleDescription.skin = "skntxtcccccc8pxradiusfff";
    },
    getUserRoles: function() {
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.fetchAllUserRole({});
    },
    setUserRoles: function() {
        const userRoles = AppToolBox.store.getItem("userRolesResponse");
        let widgetData = {
            lblRoleID: "roleID",
            lblRoleName: "roleName",
            lblRoleDescription: "roleDescription",
            flxViewRole: "flxViewRole",
            flxEditRole: "flxEditRole",
            imgViewRole: "imgViewRole",
            imgEditRole: "imgEditRole",
            lblRoleIDHeader: "lblRoleID",
            lblRoleNameHeader: "lblRoleName",
            lblRoleDescriptionHeader: "lblRoleDescription",
        };
        this.view.segManageRoles.widgetDataMap = widgetData;
        let segData = [];
        let headerData = {
            lblRoleID: {
                isVisible: true,
                text: "Role ID"
            },
            lblRoleName: {
                isVisible: true,
                text: "Role Name"
            },
            lblRoleDescription: {
                isVisible: true,
                text: "Role Description"
            },
        };
        userRoles.reverse().map((el) => {
            let rowData = {
                roleID: el.ID,
                roleName: el.RoleName,
                roleDescription: el.RoleDescription,
                flxViewRole: {
                    isVisible: true,
                    onClick: this.editRole.bind(this, el, "view"),
                },
                flxEditRole: {
                    isVisible: true,
                    onClick: this.editRole.bind(this, el, "edit"),
                },
                imgViewRole: {
                    src: "vector__2_.png"
                },
                imgEditRole: {
                    src: "vector__3_.png"
                },
            };
            segData.push(rowData);
        });
        this.view.segManageRoles.setData([
            [headerData, segData]
        ]);
    },
    createUserRole: function(flow) {
        let scope = this;
        let ID = scope.view.txtBoxRoleID.text;
        let RoleName = scope.view.txtBoxRoleName.text;
        let RoleDescription = scope.view.txtRoleDescription.text;
        let userroles = AppToolBox.store.getItem("userRolesResponse");
        userroles = !AppToolBox.util.isNil(userroles) ? userroles.map((el) => el.ID) : userroles;
        if (!AppToolBox.util.isNil(ID) && !AppToolBox.util.isNil(RoleName) && !AppToolBox.util.isNil(RoleDescription)) {
            let params = {};
            params.ID = ID;
            params.RoleName = RoleName;
            params.RoleDescription = RoleDescription;
            if (flow === "create") {
                if (userroles.indexOf(scope.view.txtBoxRoleID.text) !== 0) {
                    let DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
                    DashBoardModule.presentationController.createUserRole(params);
                } else {
                    scope.displayErrorMsg('User Role already exists');
                }
            } else if (flow === "edit") {
                let DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
                DashBoardModule.presentationController.updateUserRole(params);
            }
        } else {
            scope.displayErrorMsg('Please enter all the required fields');
        }
    },
    editRole: function(data, type) {
        const scope = this;
        scope.view.BreadCrum.lblBreadcrum1.text = "Manage Role";
        scope.view.flxCreateRoleMain.setVisibility(true);
        scope.view.flxManageRole.setVisibility(false);
        scope.view.flxQuickLinks1.flxQuickLinks1.setVisibility(false);
        scope.view.flxQuickLinks1.flxQuickLinks2.setVisibility(true);
        scope.view.txtBoxRoleID.text = data.ID;
        scope.view.txtBoxRoleName.text = data.RoleName;
        scope.view.txtRoleDescription.text = data.RoleDescription;
        if (type === "view") {
            scope.view.txtBoxRoleID.setEnabled(false);
            scope.view.txtBoxRoleName.setEnabled(false);
            scope.view.txtRoleDescription.setEnabled(false);
            scope.view.txtBoxRoleID.skin = "skntxteeedisabled";
            scope.view.txtBoxRoleName.skin = "skntxteeedisabled";
            scope.view.txtRoleDescription.skin = "skntxteeedisabled";
            scope.view.btnCreate.setVisibility(false);
            scope.view.btnCancel.text = "Back";
            scope.view.lblCreateRole.text = `Role Detail - ${data.ID}`;
        } else {
            scope.view.btnCreate.text = "Submit";
            scope.view.btnCancel.text = "Cancel";
            scope.view.lblCreateRole.text = `Role Detail - ${data.ID}`;
            scope.view.txtBoxRoleID.setEnabled(false);
            scope.view.txtBoxRoleName.setEnabled(true);
            scope.view.txtRoleDescription.setEnabled(true);
            scope.view.btnCreate.setVisibility(true);
            scope.view.btnCreate.setEnabled(false);
            scope.view.btnCreate.skin = "sknbtndisabledeee666";
            scope.view.txtBoxRoleID.onTextChange = this.editValidation.bind(this, data);
            scope.view.txtBoxRoleName.onTextChange = this.editValidation.bind(this, data);
            scope.view.txtRoleDescription.onTextChange = this.editValidation.bind(this, data);
            scope.view.txtBoxRoleID.skin = "skntxteeedisabled";
            scope.view.txtBoxRoleName.skin = "skntxtcccccc8pxradiusfff";
            scope.view.txtRoleDescription.skin = "skntxtcccccc8pxradiusfff";
            scope.view.btnCreate.onClick = this.createUserRole.bind(this, "edit");
        }
    },
    fieldValidation: function() {
        const scope = this;
        !AppToolBox.util.isNil(scope.view.txtBoxRoleID.text) && !AppToolBox.util.isNil(scope.view.txtBoxRoleName.text) && !AppToolBox.util.isNil(scope.view.txtRoleDescription.text) ? scope.setButtonStatus(true) : scope.setButtonStatus(false);
    },
    editValidation: function(data) {
        const scope = this;
        if (scope.view.txtBoxRoleID.text !== data.ID || scope.view.txtBoxRoleName.text !== data.RoleName || scope.view.txtRoleDescription.text !== data.RoleDescription) {
            scope.setButtonStatus(true);
            return;
        }
        scope.setButtonStatus(false);
    },
    setButtonStatus: function(status) {
        const scope = this;
        if (status === true) {
            scope.view.btnCreate.setEnabled(true);
            scope.view.btnCreate.skin = "sknbtnprimaryFFFFFF411062";
        } else {
            scope.view.btnCreate.setEnabled(false);
            scope.view.btnCreate.skin = "sknbtndisabledeee666";
        }
    },
    displayErrorMsg: function(error) {
        const scope = this;
        scope.view.msgContainer.flxMessageContainer.skin = "sknflxF37070error";
        scope.view.msgContainer.skin = "sknflxF37070error";
        scope.view.msgContainer.setMessage(error);
        scope.view.msgContainer.showMessage(this.view.flxMessageContainer, this);
    },
    displaySuccessMsg: function(text) {
        const scope = this;
        scope.view.msgContainer.flxMessageContainer.skin = "sknmessagepop";
        scope.view.msgContainer.skin = "sknmessagepop";
        scope.view.msgContainer.setMessage(text);
        scope.view.msgContainer.showMessage(this.view.flxMessageContainer, this);
    },
    hideMessage: function() {
        animations.hideMessage(this.view.flxMessageContainer);
    },
}));
define("UserManagement/frmRoleManagementControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_b84482c8b10540829b68808a8e1e522b: function AS_Form_b84482c8b10540829b68808a8e1e522b(eventobject) {
        var self = this;
    }
});
define("UserManagement/frmRoleManagementController", ["UserManagement/userfrmRoleManagementController", "UserManagement/frmRoleManagementControllerActions"], function() {
    var controller = require("UserManagement/userfrmRoleManagementController");
    var controllerActions = ["UserManagement/frmRoleManagementControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
