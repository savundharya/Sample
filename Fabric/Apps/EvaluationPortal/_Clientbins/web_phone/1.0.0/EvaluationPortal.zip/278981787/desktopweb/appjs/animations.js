define(function() {
    function animations() {
        this.appInstance = null;
    }
    animations.loginAnim = function(scope) {
        scope.view.flxLeft.animate(kony.ui.createAnimation({
            "0": {
                "left": "-37%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            },
            "100": {
                "left": "4%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 1.5,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 1.5
        });
        scope.view.flxRightMain.animate(kony.ui.createAnimation({
            "0": {
                "left": "100%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            },
            "100": {
                "left": "52%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 1.5,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 1.5
        });
    }
    animations.uploadSlide = function(scope, scopeObj) {
        scopeObj.animate(kony.ui.createAnimation({
            "0": {
                "width": "0%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            },
            "100": {
                "width": "97%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 5
        }, {
            "animationEnd": scope.animationCallbackFn
        });
    }
    animations.showMessage = function(scopeObj, scope) {
        scopeObj.animate(kony.ui.createAnimation({
            "100": {
                "top": "-1%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 2
        }, {
            "animationEnd": scope.callBackTimer(scopeObj)
        })
    }
    animations.hideMessage = function(scopeObj) {
        scopeObj.animate(kony.ui.createAnimation({
            "100": {
                "top": "-13%",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 2
        })
    }
    animations.showMessageNew = function(scopeObj, scope) {
        scopeObj.animate(kony.ui.createAnimation({
            "100": {
                "top": "-10dp",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 2
        }, {
            "animationEnd": scope.callBackTimer(scopeObj)
        })
    }
    animations.hideMessageNew = function(scopeObj) {
        scopeObj.animate(kony.ui.createAnimation({
            "100": {
                "top": "-100dp",
                "stepConfig": {
                    "timingFunction": kony.anim.EASE
                }
            }
        }), {
            "delay": 0,
            "iterationCount": 1,
            "fillMode": kony.anim.FILL_MODE_FORWARDS,
            "duration": 2
        })
    }
    return animations;
});