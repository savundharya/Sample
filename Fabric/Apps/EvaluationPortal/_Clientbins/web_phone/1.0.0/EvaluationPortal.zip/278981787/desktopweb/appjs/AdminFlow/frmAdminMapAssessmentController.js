const selectedSeg = new Set();
var evalList = [];
var unAssignedList = [];
define("AdminFlow/userfrmAdminMapAssessmentController", ["AppToolBox", "animations"], (AppToolBox, animations) => ({
    onNavigate: function() {
        this.view.preShow = this.preShow;
        this.view.postShow = this.postShow;
    },
    preShow: function() {
        var scope = this;
        scope.view.onDeviceBack = function() {};
        this.view.DropDown.reset();
        this.view.DropDown1.reset();
        //this.view.txtSearch.setEnabled(false);
        //this.view.txtSearchBox.setEnabled(false);
        scope.view.DropDown1.flxTxtBoxContainer.setEnabled(true);
        this.view.txtSearchBox.onTextChange = this.searchEvaluator;
        this.view.txtSearch.onTextChange = this.searchUnAssigned;
        this.resetNewRole();
        kony.application.showLoadingScreen();
        AppToolBox.store.setItem("selectedEval", "");
        this.setRole();
        this.getEvaluator();
        this.view.flxUnassignedPeople.setVisibility(false);
        this.view.DropDown.segDropDown.onRowClick = this.fetchRoleAssessment;
        this.view.DropDown1.segDropDown.onRowClick = this.fetchAssignedUsers;
        this.view.DropDown1.txtBoxDropDown.placeholder = "Select Assessment";
        this.view.DropDown.txtBoxDropDown.placeholder = "Select A Role";
        this.viewOrDisableAssignBtn();
        this.view.btnCancel.onClick = () => {
            this.resetNewRole();
            this.view.BreadCrum.navigateToHome(AppToolBox);
        };
        //this.view.btnAssign.skin = "sknBtnAssignmentDisabled";
        //this.view.chckBoxEvaluator.onSelection = this.viewOrDisableAssignBtn;
        //this.view.segUnAssignedUsers.onRowClick = this.selectUsers;
        this.view.segEvaluatorSearchOptions.onRowClick = this.selectEval;
        this.view.btnAssign.onClick = this.assignUser;
        this.view.flxQuickLinks.flxQuickLinks1.onClick = this.navigateToFormParams.bind(this, "frmCreateAssessment", "create");
        this.view.flxQuickLinks.flxQuickLinks2.onClick = this.navigateToForm.bind(this, "frmManageAssessment");
        this.view.BreadCrum.lblBreadcrum1.text = "Manage Assessment";
        this.view.BreadCrum.lblBreadcrum1.onTouchStart = this.navigateToForm.bind(this, "frmManageAssessment");
        this.view.DropDown.flxDropDownValues.isVisible = false;
    },
    searchEvaluator: function() {
        var searchEval = [];
        if (!AppToolBox.util.isNil(this.view.txtSearchBox.text)) {
            for (var i = 0; i < evalList.length; i++) {
                if (evalList[i].lblEvaluatorserch.toLowerCase().includes(this.view.txtSearchBox.text.toLowerCase())) {
                    searchEval.push(evalList[i]);
                }
            }
        } else {
            this.view.segEvaluatorSearchOptions.setData(evalList);
            return;
        }
        this.view.segEvaluatorSearchOptions.setData(searchEval);
    },
    searchUnAssigned: function() {
        var searchUnAssigned = [];
        if (!AppToolBox.util.isNil(this.view.txtSearch.text)) {
            for (var i = 0; i < unAssignedList.length; i++) {
                if (unAssignedList[i].lblUserName.text.toLowerCase().includes(this.view.txtSearch.text.toLowerCase())) {
                    searchUnAssigned.push(unAssignedList[i]);
                }
            }
        } else {
            this.view.segUnassignedPeople.setData(unAssignedList);
            return;
        }
        this.view.segUnassignedPeople.setData(searchUnAssigned);
    },
    navigateToFormParams: function(formName, flow) {
        let nav = new kony.mvc.Navigation(formName);
        nav.navigate(flow);
    },
    navigateToForm: function(frmName) {
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.navigateTo(frmName);
    },
    getEvaluator: function() {
        var filter;
        filter = "RoleID eq EVALUATOR";
        let param = {
            "Filter": filter,
            "Flow": "AdminMap"
        };
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.fetchUserDetails(param);
    },
    selectEval: function() {
        AppToolBox.store.setItem("selectedEval", this.view.segEvaluatorSearchOptions.selectedRowItems[0].ID);
        var rowIndex = this.view.segEvaluatorSearchOptions.selectedRowIndex[1];
        var sectionIndex = this.view.segEvaluatorSearchOptions.selectedRowIndex[0];
        if (!AppToolBox.util.isNil((AppToolBox.store.getItem("prevAssessSegData")))) {
            var prevData = AppToolBox.store.getItem("prevAssessSegData");
            if (rowIndex !== prevData.rowIndex) {
                this.setToUnclickedState(AppToolBox.store.getItem("prevAssessSegData"));
            } else {
                return;
            }
        }
        var data = this.view.segEvaluatorSearchOptions.selectedRowItems[0];
        data.flxEvaluatorSegment.skin = "sknHoverEvaluator";
        this.view.segEvaluatorSearchOptions.setDataAt(data, rowIndex, sectionIndex);
        AppToolBox.store.setItem("prevAssessSegData", {
            "data": data,
            "rowIndex": rowIndex,
            "sectionIndex": sectionIndex
        });
        this.viewOrDisableAssignBtn();
    },
    viewOrDisableAssignBtn: function() {
        var selectedEval = AppToolBox.store.getItem("selectedEval");
        var dataset = this.view.segUnassignedPeople.data;
        var selectedCount = 0;
        for (var count = 0; count < dataset.length; count++) {
            if (dataset[count].imgSelection === "checked.png") {
                selectedCount++;
            }
        }
        // if(AppToolBox.util.isNil(this.view.chckBoxEvaluator.selectedKeys) || AppToolBox.util.isNil(selectedEval) || this.view.DropDown.txtBoxDropDown.text === "" || this.view.DropDown1.txtBoxDropDown.text === ""){
        if (selectedCount <= 0 || AppToolBox.util.isNil(selectedEval) || this.view.DropDown.txtBoxDropDown.text === "" || this.view.DropDown1.txtBoxDropDown.text === "") {
            this.view.btnAssign.setEnabled(false);
            this.view.btnAssign.skin = "sknbtndisabledeee666";
        } else {
            this.view.btnAssign.setEnabled(true);
            this.view.btnAssign.skin = "sknbtnprimaryFFFFFF411062";
        }
    },
    resetNewRole: function() {
        this.view.btnAssign.setEnabled(false);
        //this.view.btnAssign.skin = "sknBtnAssignmentDisabled";
        this.view.DropDown.txtBoxDropDown.text = "";
        this.view.DropDown1.txtBoxDropDown.text = "";
        this.view.txtSearch.text = "";
        this.view.txtSearchBox.text = "";
        this.view.segUnassignedPeople.setData([]);
        this.view.flxUnassignedPeople.setVisibility(false);
        this.viewOrDisableAssignBtn();
        if (!AppToolBox.util.isNil(AppToolBox.store.getItem("prevAssessSegData"))) {
            this.setToUnclickedState(AppToolBox.store.getItem("prevAssessSegData"));
        }
        kony.application.dismissLoadingScreen();
    },
    fetchAssignedUsers: function() {
        var assessmentID;
        var rowIndex;
        var sectionIndex;
        var prevData;
        assessmentID = this.view.DropDown1.segDropDown.selectedRowItems[0].assessmentID;
        AppToolBox.store.setItem("assessmentID", assessmentID);
        this.fetchAssignedUsersResponse();
    },
    fetchAssignedUsersResponse: function() {
        this.view.DropDown1.setTxtBoxValue();
        var assessmentID = AppToolBox.store.getItem("assessmentID");
        this.viewOrDisableAssignBtn();
        var roleID = this.view.DropDown.segDropDown.selectedRowItems[0].ID.replace(" ", "_");
        kony.application.showLoadingScreen();
        var params = {
            "Filter": "AssessmentID eq " + assessmentID + " and roleId eq '" + roleID + "'",
            "fetchInitiatedRoleUser": true
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.fetchAppStatus(params);
    },
    setToUnclickedState: function(prevData) {
        prevData.data.flxEvaluatorSegment.skin = "sknSegdetail";
        this.view.segEvaluatorSearchOptions.setDataAt(prevData.data, prevData.rowIndex, prevData.sectionIndex);
    },
    selectUsers: function() {
        var obj = this.view.segUnAssignedUsers;
        this.changeSegImg(obj);
        this.viewOrDisableAssignBtn();
    },
    changeSegImg: function(Obj) {
        kony.print(this.view.segAssignedUsers.selectedRowItems);
        var data = Obj.selectedRowItems[0];
        var rowIndex = Obj.selectedRowIndex[1];
        var sectionIndex = Obj.selectedRowIndex[0];
        if (data.imgMenu.src === "checkbox_selected.png") {
            data.imgMenu.src = "checkbox_unselected.png";
            selectedSeg.delete(data.userID);
        } else {
            data.imgMenu.src = "checkbox_selected.png";
            selectedSeg.add(data.userID);
        }
        Obj.setDataAt(data, rowIndex, sectionIndex);
    },
    fetchRoleAssessment: function() {
        kony.application.showLoadingScreen();
        this.view.DropDown1.flxTxtBoxContainer.setEnabled(true);
        this.view.DropDown.setTxtBoxValue();
        this.view.flxUnassignedPeople.setVisibility(false);
        this.view.DropDown1.segDropDown.removeAll();
        this.view.DropDown1.txtBoxDropDown.text = "";
        this.view.segUnassignedPeople.setData([]);
        this.viewOrDisableAssignBtn();
        var roleID = this.view.DropDown.segDropDown.selectedRowItems[0].ID;
        roleID = roleID.replace(" ", "_");
        var params = {
            "Filter": "RoleID eq '" + roleID + "'",
            "FormDetails": "frmAdminMapAssessment"
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.fetchAssessments(params);
    },
    setInitiatedUsers: function(response) {
        var filter = "ID ne " + response[0].ID;
        for (var i = 0; i < response.length; i++) {
            if (i !== 0) {
                filter = filter + " and ID ne " + response[i].ID;
            }
        }
        filter = filter + " and RoleID eq '" + this.view.DropDown.segDropDown.selectedRowItems[0].ID.replace(" ", "_") + "'";
        this.fetchUnAssignedUsers(filter);
    },
    showOrHideOption: function(Obj) {
        kony.print(this.view.segAssignedUsers.selectedRowItems);
        var data = Obj.selectedRowItems[0];
        var rowIndex = Obj.selectedRowIndex[1];
        var sectionIndex = Obj.selectedRowIndex[0];
        data.flxPopUpMenu = {
            "isVisible": true
        };
        Obj.setDataAt(data, rowIndex, sectionIndex);
    },
    /*setUnAssignedUsers : function(response){
       var Users = [];
       for(var i=0;i<response.length;i++){
         var keyValue = [response[i].ID,response[i].Name];
         Users.push(keyValue);
       }
       this.view.chckBoxEvaluator.masterData = Users;
       this.view.flxEvaluator.setVisibility(true);
       this.viewOrDisableAssignBtn();
       kony.application.dismissLoadingScreen();
     },
     */
    setUnAssignedUsers: function(response) {
        var scopeObj = this;
        var dataMap = {
            "flxSelectionImage": "flxSelectionImage",
            "imgSelection": "imgSelection",
            "lblUserName": "lblUserName"
        };
        var unassignedUsers = response.map(function(dataItem) {
            var unassignedUser = {
                "imgSelection": "rectangle_47.png",
                "lblUserName": {
                    "text": dataItem.Name
                },
                "flxSelectionImage": {
                    "onClick": function() {
                        scopeObj.setSelectedUsers();
                    }
                },
                id: dataItem.ID
            };
            return unassignedUser;
        });
        this.view.segUnassignedPeople.widgetDataMap = dataMap;
        this.view.segUnassignedPeople.setData(unassignedUsers);
        unAssignedList = unassignedUsers;
        this.view.flxUnassignedPeople.setVisibility(true);
        kony.application.dismissLoadingScreen();
        this.viewOrDisableAssignBtn();
    },
    setSelectedUsers: function() {
        var index = this.view.segUnassignedPeople.selectedRowIndex[1];
        var selectedUsers = this.view.segUnassignedPeople.data[index];
        if (selectedUsers.imgSelection === "rectangle_47.png") {
            selectedUsers.imgSelection = "checked.png";
        } else {
            selectedUsers.imgSelection = "rectangle_47.png";
        }
        this.view.segUnassignedPeople.setDataAt(selectedUsers, index);
        this.viewOrDisableAssignBtn();
    },
    setEvaluatorlst: function(response) {
        var Users = [];
        var dataMap = {
            lblEvaluatorserch: "lblEvaluatorserch",
            flxEvaluatorSegment: "flxEvaluatorSegment"
        };
        this.view.segEvaluatorSearchOptions.widgetDataMap = dataMap;
        for (var i = 0; i < response.length; i++) {
            var data = {
                lblEvaluatorserch: response[i].Name,
                ID: response[i].ID,
                flxEvaluatorSegment: {
                    "skin": "sknSegdetail"
                }
            };
            Users.push(data);
        }
        this.view.segEvaluatorSearchOptions.setData(Users);
        evalList = Users;
        kony.application.dismissLoadingScreen();
    },
    assignUser: function() {
        kony.application.showLoadingScreen();
        var evaluatorID = AppToolBox.store.getItem("selectedEval");
        var assessmentID = AppToolBox.store.getItem("assessmentID");
        var roleID = this.view.DropDown.segDropDown.selectedRowItems[0].ID.replace(" ", "_");
        var duration;
        var durationSet = AppToolBox.store.getItem("duration");
        for (var counts = 0; counts < durationSet.length; counts++) {
            if (durationSet[counts].AssessmentID === assessmentID) {
                duration = durationSet[counts].Duration;
                break;
            }
        }
        //var selectedUsers = this.view.chckBoxEvaluator.selectedKeys;
        var dataset = this.view.segUnassignedPeople.data;
        var selectedUsers = [];
        for (var count = 0; count < dataset.length; count++) {
            if (dataset[count].imgSelection === "checked.png") {
                selectedUsers.push(dataset[count].id);
            }
        }
        var params;

        function createParams(values) {
            if (AppToolBox.util.isNil(params)) {
                params = {
                    "loop_count": selectedUsers.length,
                    "loop_separator": "|",
                    "UserID": values,
                    "AssessmentID": assessmentID,
                    "ApplicationStatus": "STATUS001",
                    "Duration": duration,
                    "EvaluatorID": evaluatorID,
                    "ApplicantComments": "",
                    "ApplicationFile2": "",
                    "RoleID": roleID,
                    "ApplicationFile3": "",
                    "ApplicationFile1": ""
                };
            } else {
                params.UserID += "|" + values;
                params.AssessmentID += "|" + assessmentID;
                params.ApplicationStatus += "|STATUS001";
                params.Duration += "|" + duration;
                params.EvaluatorID += "|" + evaluatorID;
                params.RoleID += "|" + roleID;
            }
        }
        selectedUsers.forEach(createParams);
        var EvaluatorMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("EvaluatorModule");
        EvaluatorMod.presentationController.assignUsers(params);
    },
    fetchUnAssignedUsers: function(filter) {
        var params = {
            "Filter": filter,
            "fetchUnassigned": true
        };
        var DashMod = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashMod.presentationController.fetchAllUsers(params);
    },
    setRoleAssessmentDetails: function(response) {
        if (!AppToolBox.util.isNil((AppToolBox.store.getItem("prevAssessSegData")))) {
            this.setToUnclickedState(AppToolBox.store.getItem("prevAssessSegData"));
            AppToolBox.store.removeItem("prevAssessSegData");
        }
        var dataLst = [];
        var dataMap = {
            lblFilter: "lblFilter"
        };
        for (var i = 0; i < response.assessments.length; i++) {
            var data = {
                lblFilter: response.assessments[i].AssessmentName,
                assessmentID: response.assessments[i].ID,
                duration: response.assessments[i].Duration
            };
            dataLst.push(data);
        }
        this.view.DropDown1.setValues(dataMap, dataLst);
        kony.application.dismissLoadingScreen();
    },
    setLstBoxRoles: function() {
        kony.application.showLoadingScreen();
        var params = {
            "FormDetails": "frmAdminMapAssessment"
        };
        var DashBoardModule = kony.mvc.MDAApplication.getSharedInstance().getModuleManager().getModule("DashBoardModule");
        DashBoardModule.presentationController.fetchAllUserRole(params);
    },
    setRole: function() {
        var roles = AppToolBox.store.getItem("userRolesResponse");
        var dataLst = [];
        var dataMap = {
            lblFilter: "lblFilter"
        };
        for (var i = 0; i < roles.length; i++) {
            if (roles[i].ID !== "ADMIN" && roles[i].ID !== "EVALUATOR") {
                var data = {
                    lblFilter: roles[i].RoleName.replace("_", " "),
                    ID: roles[i].ID
                };
                dataLst.push(data);
            }
        }
        this.view.DropDown.setValues(dataMap, dataLst);
    },
    displayAndFetchUnassigned: function(msg) {
        this.displayNoAssignedUser(msg);
        var filter = "RoleID eq '" + this.view.DropDown.segDropDown.selectedRowItems[0].ID.replace(" ", "_") + "'";
        this.fetchUnAssignedUsers(filter);
    },
    displayNoAssessment: function(msg) {
        //this.view.lblNoAssessment.skin = "sknlblLatoReg12pxRed";
        //     this.view.lblNoAssessment.text = msg;
        //     this.view.flxAssessmentSegList.isVisible = false;
        //     this.view.flxNoAssessment.isVisible = true;
        var scope = this;
        //this.view.msgContainer.setImageWarning();
        scope.view.msgContainer.setMessage(msg);
        scope.view.msgContainer.showMessage(scope.view.flxMessageContainer, scope);
        //this.view.msgContainer.setCancelWarn();
        scope.view.msgContainer.imgClose.onTouchStart = scope.hideMessage;
        scope.view.DropDown1.flxTxtBoxContainer.setEnabled(false);
        kony.application.dismissLoadingScreen();
    },
    displayNoAssignedUser: function(msg) {
        //this.view.lblNoAssigned.skin = "sknlblLatoReg12pxRed";
        //this.view.lblNoAssigned.text = msg;
        //this.view.flxAssignedUsersSeg.isVisible = false;
        //this.view.flxNoAssignedUsers.isVisible = true;
    },
    displayNoUnassignedUser: function(msg) {
        //this.view.lblNoUnAssigned.text = msg;
        //this.view.flxUnAssignedUsersMain.isVisible = false;
        //this.view.flxEvaluatorSelect.isVisible = false;
        //this.view.flxNoUnAssignedUsers.isVisible =true;
        //this.view.lblUnAssignedSegHeader.text = "UnAssigned";
        kony.application.dismissLoadingScreen();
    },
    displayErrorMsg: function(errMsg) {
        var scope = this;
        //this.view.msgContainer.setImageWarning();
        scope.view.msgContainer.setMessage(errMsg);
        scope.view.msgContainer.showMessage(scope.view.flxMessageContainer, scope);
        //this.view.msgContainer.setCancelWarn();
        scope.view.msgContainer.imgClose.onTouchStart = scope.hideMessage;
        //this.view.flxMiddleErrorMessage.isVisible = true;
        //this.view.flxSegmentMain.height = "65%";
        //selectedSeg.clear();
        kony.application.dismissLoadingScreen();
    },
    hideMessage: function() {
        animations.hideMessage(this.view.flxMessageContainer);
    },
    displayMsg: function(Msg) {
        var scope = this;
        /*this.view.msgContainer.setImageSuccess();
        this.view.msgContainer.setMessage(Msg);
        this.view.msgContainer.setCancelSuccess();
        this.view.flxMiddleErrorMessage.isVisible = true;
        this.view.msgContainer.imgCancel.onTouchStart = function(){
          scope.view.flxMiddleErrorMessage.isVisible = false;
          scope.view.flxSegmentMain.height = "75%";
        };
        this.view.flxSegmentMain.height = "65%";
        kony.print(Msg);
        selectedSeg.clear();*/
        this.resetNewRole();
        //this.fetchAssignedUsersResponse();
        this.viewOrDisableAssignBtn();
        this.view.BreadCrum.navigateToHome(AppToolBox);
    },
    postShow: function() {
        AppToolBox.store.removeItem("prevAssessSegData");
        AppToolBox.store.removeItem("assessmentID");
        AppToolBox.store.removeItem("duration");
        selectedSeg.clear();
    },
}));
define("AdminFlow/frmAdminMapAssessmentControllerActions", {
    /*
        This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    AS_Form_cbe3e693312344a880f60f4d36c38f6d: function AS_Form_cbe3e693312344a880f60f4d36c38f6d(eventobject) {
        var self = this;
    }
});
define("AdminFlow/frmAdminMapAssessmentController", ["AdminFlow/userfrmAdminMapAssessmentController", "AdminFlow/frmAdminMapAssessmentControllerActions"], function() {
    var controller = require("AdminFlow/userfrmAdminMapAssessmentController");
    var controllerActions = ["AdminFlow/frmAdminMapAssessmentControllerActions"];
    return kony.visualizer.mixinControllerActions(controller, controllerActions);
});
