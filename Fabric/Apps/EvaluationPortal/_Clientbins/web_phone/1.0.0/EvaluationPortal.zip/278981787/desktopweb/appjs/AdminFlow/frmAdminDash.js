define("AdminFlow/frmAdminDash", function() {
    return function(controller) {
        function addWidgetsfrmAdminDash() {
            this.setDefaultUnit(kony.flex.DP);
            var flxMain = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxMain",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "1dp",
                "isModalContainer": false,
                "skin": "sknbgf5f5f5bgimg",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMain.setDefaultUnit(kony.flex.DP);
            var flxHeader = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "8%",
                "id": "flxHeader",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeader.setDefaultUnit(kony.flex.DP);
            var headerNew = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "headerNew": {
                        "height": "100%"
                    },
                    "imgHeader": {
                        "src": "logo_org2.png"
                    },
                    "imgLogout": {
                        "src": "right_from_bracket_solid.png"
                    },
                    "imgUserImage": {
                        "src": "user_solid.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeader.add(headerNew);
            var flxHeaderNew = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "18%",
                "id": "flxHeaderNew",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxHeaderNew.setDefaultUnit(kony.flex.DP);
            var headerNew1 = new com.evaluationPortal.headerNew({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "headerNew1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0%",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxUserRoleName": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "35%"
                    },
                    "headerNew": {
                        "height": "100%",
                        "isVisible": true
                    },
                    "imgHeader": {
                        "src": "aspirelogo.png"
                    },
                    "imgLogout": {
                        "src": "logout.png"
                    },
                    "imgUserImage": {
                        "src": "userimg.png"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxHeaderNew.add(headerNew1);
            var flxMainContent = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "bottom": "0%",
                "clipBounds": false,
                "height": "82%",
                "id": "flxMainContent",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxnobg",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxMainContent.setDefaultUnit(kony.flex.DP);
            var flxMiddleScroll = new kony.ui.FlexScrollContainer({
                "allowHorizontalBounce": false,
                "allowVerticalBounce": true,
                "bounces": true,
                "clipBounds": false,
                "enableScrolling": true,
                "height": "100%",
                "horizontalScrollIndicator": true,
                "id": "flxMiddleScroll",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "pagingEnabled": false,
                "scrollDirection": kony.flex.SCROLL_VERTICAL,
                "skin": "slFSbox",
                "top": "0dp",
                "verticalScrollIndicator": true,
                "width": "100%"
            }, {
                "paddingInPixel": false
            }, {});
            flxMiddleScroll.setDefaultUnit(kony.flex.DP);
            var flxBodyDash = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "100%",
                "id": "flxBodyDash",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "right": "3%",
                "skin": "sknflxnobg",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBodyDash.setDefaultUnit(kony.flex.DP);
            var flxTop = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxTop",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxTop.setDefaultUnit(kony.flex.DP);
            var flxDashboard = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDashboard",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "75%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboard.setDefaultUnit(kony.flex.DP);
            var flxDashboardTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxDashboardTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "97%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashboardTitle.setDefaultUnit(kony.flex.DP);
            var lblDashBoard = new kony.ui.Label({
                "id": "lblDashBoard",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl000000font28px",
                "text": "Dashboard",
                "top": "35dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxListBox = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "focusSkin": "sknflxlistbox",
                "height": "40dp",
                "id": "flxListBox",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "right": "0",
                "skin": "sknflxlistbox",
                "top": "35dp",
                "width": "240dp",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxListBox.setDefaultUnit(kony.flex.DP);
            var lstBoxRoles = new kony.ui.ListBox({
                "focusSkin": "sknlstFFFFFF15pxradius",
                "height": "40dp",
                "id": "lstBoxRoles",
                "isVisible": true,
                "masterData": [
                    ["lb1", "Interviewee"],
                    ["lb2", "Trainee"],
                    ["lbl3", "Consultant"],
                    ["lbl4", "Prospective candidate"],
                    ["lbl5", "All User"]
                ],
                "right": "0dp",
                "selectedKey": "lbl5",
                "skin": "sknlstFFFFFF15pxradius",
                "top": "0dp",
                "width": "240dp"
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [1, 0, 0, 0],
                "paddingInPixel": false
            }, {
                "multiSelect": false
            });
            flxListBox.add(lstBoxRoles);
            flxDashboardTitle.add(lblDashBoard, flxListBox);
            var flxDashChart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "310dp",
                "id": "flxDashChart",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxMiddle",
                "top": "20dp",
                "width": "99%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxDashChart.setDefaultUnit(kony.flex.DP);
            var flxChart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "centerX": "50%",
                "clipBounds": false,
                "height": "100%",
                "id": "flxChart",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0%",
                "isModalContainer": false,
                "skin": "sknflxnobg",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxChart.setDefaultUnit(kony.flex.DP);
            var flxVerticalChart = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "98%",
                "id": "flxVerticalChart",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "8dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "3dp",
                "width": "98%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxVerticalChart.setDefaultUnit(kony.flex.DP);
            var multiseriesverticalbar = new com.konymp.multiseriesverticalbar({
                "height": "100%",
                "id": "multiseriesverticalbar",
                "isVisible": true,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease",
                "overrides": {
                    "multiseriesverticalbar": {
                        "right": "viz.val_cleared",
                        "bottom": "viz.val_cleared",
                        "minWidth": "viz.val_cleared",
                        "minHeight": "viz.val_cleared",
                        "maxWidth": "viz.val_cleared",
                        "maxHeight": "viz.val_cleared",
                        "centerX": "viz.val_cleared",
                        "centerY": "viz.val_cleared"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            multiseriesverticalbar.enableGrid = true;
            multiseriesverticalbar.chartData = {
                "data": [{
                    "label": "d1",
                    "value1": "25",
                    "value2": "12",
                    "value3": "8",
                    "value4": "32",
                    "value5": "5",
                    "value6": ""
                }, {
                    "label": "d2",
                    "value1": "12",
                    "value2": "32",
                    "value3": "36",
                    "value4": "10",
                    "value5": "22",
                    "value6": ""
                }, {
                    "label": "d3",
                    "value1": "22",
                    "value2": "3",
                    "value3": "15",
                    "value4": "8",
                    "value5": "24",
                    "value6": ""
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Label",
                    "columnHeaderType": "text",
                    "columnID": "label",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "adb02a6b13a046f4861d9d64ef0c34ee"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value1",
                    "columnHeaderType": "text",
                    "columnID": "value1",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "f7ad02b6f3df4493bb1ef588ab70e008"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value2",
                    "columnHeaderType": "text",
                    "columnID": "value2",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "b59fe0cbc1394743a3214ea7583c0180"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value3",
                    "columnHeaderType": "text",
                    "columnID": "value3",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "d9cae0e9fe1548b0becf2dac23f4ceef"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value4",
                    "columnHeaderType": "text",
                    "columnID": "value4",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "f03e4f1fe95c4dd4b6f8e6f3d7629bd9"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value5",
                    "columnHeaderType": "text",
                    "columnID": "value5",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "bb532b4caa214aabb1f9e17780f59200"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Value6",
                    "columnHeaderType": "text",
                    "columnID": "value6",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "h48c357ca3fd4fddb1746caa9d5e4619"
                }]
            };
            multiseriesverticalbar.chartTitle = "Vertical Bars";
            multiseriesverticalbar.indicatorFontColor = "#000000";
            multiseriesverticalbar.barDetails = {
                "data": [{
                    "color": "#1B9ED9",
                    "legendName": "blue"
                }, {
                    "color": "#76C044",
                    "legendName": "green"
                }, {
                    "color": "#F26B29",
                    "legendName": "orange"
                }, {
                    "color": "#464648",
                    "legendName": "black"
                }, {
                    "color": "#FFC522",
                    "legendName": "yellow"
                }, {
                    "color": "#FFFF00",
                    "legendName": "dark yellow"
                }],
                "schema": [{
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Legend Name",
                    "columnHeaderType": "text",
                    "columnID": "legendName",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "f6de75a55e614f8385befc3ec254a1bd"
                }, {
                    "columnHeaderTemplate": null,
                    "columnHeaderText": "Color Code",
                    "columnHeaderType": "text",
                    "columnID": "color",
                    "columnText": "Not Defined",
                    "columnType": "text",
                    "kuid": "g50365d432034b0a92c5a5cd4b07d1c7"
                }]
            };
            multiseriesverticalbar.xAxisTitle = "x-axis";
            multiseriesverticalbar.lowValue = "0";
            multiseriesverticalbar.highValue = "50";
            multiseriesverticalbar.bgColor = "#FFFFFF";
            multiseriesverticalbar.enableChartAnimation = true;
            multiseriesverticalbar.enableLegends = true;
            multiseriesverticalbar.yAxisTitle = "y-axis";
            multiseriesverticalbar.titleFontSize = "12";
            multiseriesverticalbar.indicatorFontSize = "8";
            multiseriesverticalbar.legendFontSize = "95%";
            multiseriesverticalbar.enableStaticPreview = true;
            multiseriesverticalbar.titleFontColor = "#000000";
            multiseriesverticalbar.legendFontColor = "#000000";
            multiseriesverticalbar.seriesBarDistance = "40";
            multiseriesverticalbar.barWidth = "30";
            flxVerticalChart.add(multiseriesverticalbar);
            var flxNoData = new kony.ui.FlexContainer({
                "clipBounds": false,
                "height": "220dp",
                "id": "flxNoData",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxNoData.setDefaultUnit(kony.flex.DP);
            var lblNoData = new kony.ui.Label({
                "height": "15%",
                "id": "lblNoData",
                "isVisible": true,
                "left": "28%",
                "right": "24.78%",
                "skin": "defLabel",
                "text": "No Assessment assigned!",
                "top": "55%",
                "width": kony.flex.USE_PREFFERED_SIZE,
                "zIndex": 1
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxNoData.add(lblNoData);
            flxChart.add(flxVerticalChart, flxNoData);
            flxDashChart.add(flxChart);
            flxDashboard.add(flxDashboardTitle, flxDashChart);
            var flxQuickLinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "400dp",
                "id": "flxQuickLinks",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0",
                "width": "25%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinks.setDefaultUnit(kony.flex.DP);
            var flxQuickLinksTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "60dp",
                "id": "flxQuickLinksTitle",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxQuickLinksTitle.setDefaultUnit(kony.flex.DP);
            var lblQuickLinks = new kony.ui.Label({
                "id": "lblQuickLinks",
                "isVisible": true,
                "left": "0",
                "skin": "sknlbl000000font28px",
                "text": "QuickLinks",
                "top": "35dp",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxQuickLinksTitle.add(lblQuickLinks);
            var flxLinks = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxLinks",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "33dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxLinks.setDefaultUnit(kony.flex.DP);
            var flxManageAssesment = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "59dp",
                "id": "flxManageAssesment",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxMiddle",
                "top": "0dp",
                "width": "80%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageAssesment.setDefaultUnit(kony.flex.DP);
            var imgManageAssesment = new kony.ui.Image2({
                "centerY": "50%",
                "height": "24dp",
                "id": "imgManageAssesment",
                "isVisible": true,
                "left": "24dp",
                "skin": "slImage",
                "src": "manageassesment.png",
                "top": "0dp",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblManageAssesment = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblManageAssesment",
                "isVisible": true,
                "left": "18dp",
                "skin": "sknNameAssessment",
                "text": "Manage Assesment",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxManageAssesment.add(imgManageAssesment, lblManageAssesment);
            var flxManageUser = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "59dp",
                "id": "flxManageUser",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxMiddle",
                "top": "11dp",
                "width": "80%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageUser.setDefaultUnit(kony.flex.DP);
            var imgManageUser = new kony.ui.Image2({
                "centerY": "50%",
                "height": "24dp",
                "id": "imgManageUser",
                "isVisible": true,
                "left": "24dp",
                "skin": "slImage",
                "src": "manageuser.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblManageUser = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblManageUser",
                "isVisible": true,
                "left": "18dp",
                "skin": "sknNameAssessment",
                "text": "Manage User",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxManageUser.add(imgManageUser, lblManageUser);
            var flxManageRole = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "59dp",
                "id": "flxManageRole",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxMiddle",
                "top": "11dp",
                "width": "80%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxManageRole.setDefaultUnit(kony.flex.DP);
            var imgManageRole = new kony.ui.Image2({
                "centerY": "50%",
                "height": "24dp",
                "id": "imgManageRole",
                "isVisible": true,
                "left": "24dp",
                "skin": "slImage",
                "src": "managerole.png",
                "top": "0",
                "width": "24dp"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblManageRole = new kony.ui.Label({
                "centerY": "50%",
                "id": "lblManageRole",
                "isVisible": true,
                "left": "18dp",
                "skin": "sknNameAssessment",
                "text": "Manage Role",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxManageRole.add(imgManageRole, lblManageRole);
            var flxContactUs = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxContactUs",
                "isVisible": false,
                "layoutType": kony.flex.FLOW_HORIZONTAL,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxMiddle",
                "top": "0dp",
                "width": "80%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxContactUs.setDefaultUnit(kony.flex.DP);
            var imgContactUs = new kony.ui.Image2({
                "id": "imgContactUs",
                "isVisible": true,
                "left": "0dp",
                "skin": "slImage",
                "src": "contact_us_solid.png",
                "top": "0",
                "width": "20%"
            }, {
                "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblContactUs = new kony.ui.Label({
                "centerY": "50dp",
                "id": "lblContactUs",
                "isVisible": true,
                "left": "0dp",
                "skin": "defLabel",
                "text": "ContactUs",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxContactUs.add(imgContactUs, lblContactUs);
            flxLinks.add(flxManageAssesment, flxManageUser, flxManageRole, flxContactUs);
            var flxQuickLinks1 = new com.evaluationPortal.quickLinks.flxQuickLinks({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "100%",
                "id": "flxQuickLinks1",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "flxLinks": {
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxQuickLinks": {
                        "top": "0dp"
                    },
                    "flxQuickLinks1": {
                        "left": "0dp",
                        "right": "viz.val_cleared",
                        "width": "100%"
                    },
                    "flxQuickLinks2": {
                        "width": "100%"
                    },
                    "flxQuickLinks3": {
                        "width": "100%"
                    },
                    "flxQuickLinks4": {
                        "isVisible": false,
                        "width": "100%"
                    },
                    "flxQuickLinksMain": {
                        "top": "35dp"
                    },
                    "flxQuickLinksTitle": {
                        "width": "100%"
                    },
                    "imgQuickLinks1": {
                        "src": "manageassesment.png"
                    },
                    "imgQuickLinks2": {
                        "src": "manageuser.png"
                    },
                    "imgQuickLinks3": {
                        "src": "managerole.png"
                    },
                    "imgQuickLinks4": {
                        "src": "managerole.png"
                    },
                    "lblQuickLinks": {
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxQuickLinks.add(flxQuickLinksTitle, flxLinks, flxQuickLinks1);
            flxTop.add(flxDashboard, flxQuickLinks);
            var flxBottom = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "clipBounds": false,
                "height": "94%",
                "id": "flxBottom",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "3%",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "94%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxBottom.setDefaultUnit(kony.flex.DP);
            var flxAssessmentListTitle = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxAssessmentListTitle",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "right": "0",
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentListTitle.setDefaultUnit(kony.flex.DP);
            var lblAssessmentList = new kony.ui.Label({
                "centerY": "50dp",
                "id": "lblAssessmentList",
                "isVisible": true,
                "left": "0dp",
                "skin": "sknlbl000000font28px",
                "text": "Assigned Assessment List",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var lblViewAll = new kony.ui.Label({
                "centerY": "50dp",
                "id": "lblViewAll",
                "isVisible": true,
                "right": "0",
                "skin": "sknlbl000000font15px",
                "text": "VIEW ALL",
                "width": kony.flex.USE_PREFFERED_SIZE
            }, {
                "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_RIGHT,
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxAssessmentListTitle.add(lblAssessmentList, lblViewAll);
            var flxAssessmentList = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "bottom": "44dp",
                "clipBounds": false,
                "id": "flxAssessmentList",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "isModalContainer": false,
                "skin": "sknflxborderradiusfff",
                "top": "20dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxAssessmentList.setDefaultUnit(kony.flex.DP);
            var segAssessmentList = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "centerX": "50%",
                "data": [
                    [{
                            "imgSortAssignee": "sort_down_solid.png",
                            "imgSortDuration": "sort_down_solid.png",
                            "imgSortName": "sort_down_solid.png",
                            "imgSortRole": "sort_down_solid.png",
                            "imgSortStatus": "sort_down_solid.png",
                            "lblAssessmentName": "Assessment Name",
                            "lblAssigneeName": "Assignee Name",
                            "lblDuration": "Duration",
                            "lblRole": "Role",
                            "lblStatus": "Status"
                        },
                        [{
                            "btnAssessmentName": "Best Buy App",
                            "lblAssessmentName": "Best Buy App",
                            "lblAssigneeName": "Williams Smith",
                            "lblDuration": "20 Days",
                            "lblRole": "Consultant",
                            "lblStatus": "Completed"
                        }, {
                            "btnAssessmentName": "Every Day  - Retail",
                            "lblAssessmentName": "Every Day - Retail",
                            "lblAssigneeName": "Adam Smith",
                            "lblDuration": "40 Days",
                            "lblRole": "Trainee",
                            "lblStatus": "Overdue"
                        }, {
                            "btnAssessmentName": "Every Day - Onboarding",
                            "lblAssessmentName": "Every Day - Onboarding",
                            "lblAssigneeName": "John Adam",
                            "lblDuration": "22 Days",
                            "lblRole": "Consultant",
                            "lblStatus": "In-Progress"
                        }, {
                            "btnAssessmentName": "Retail Banking",
                            "lblAssessmentName": "Retail Banking",
                            "lblAssigneeName": "Peterson",
                            "lblDuration": "90 Days",
                            "lblRole": "Trainee",
                            "lblStatus": "Initiated"
                        }, {
                            "btnAssessmentName": "E-Shopping App",
                            "lblAssessmentName": "E-Shopping App",
                            "lblAssigneeName": "harris vettori",
                            "lblDuration": "70 Days",
                            "lblRole": "Consultant",
                            "lblStatus": "Completed"
                        }]
                    ]
                ],
                "groupCells": false,
                "id": "segAssessmentList",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowSkin": "sknflxnofff",
                "rowTemplate": "flxAssessmentList",
                "sectionHeaderTemplate": "flxAssessmentListHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorRequired": false,
                "showScrollbars": true,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "btnAssessmentName": "btnAssessmentName",
                    "flxAssessmentList": "flxAssessmentList",
                    "flxAssessmentListHeader": "flxAssessmentListHeader",
                    "flxAssessmentName": "flxAssessmentName",
                    "flxAssigneeName": "flxAssigneeName",
                    "flxDuration": "flxDuration",
                    "flxLabels": "flxLabels",
                    "flxRole": "flxRole",
                    "flxSeparator": "flxSeparator",
                    "flxStatus": "flxStatus",
                    "flxgroupheaders": "flxgroupheaders",
                    "imgSortAssignee": "imgSortAssignee",
                    "imgSortDuration": "imgSortDuration",
                    "imgSortName": "imgSortName",
                    "imgSortRole": "imgSortRole",
                    "imgSortStatus": "imgSortStatus",
                    "lblAssessmentName": "lblAssessmentName",
                    "lblAssigneeName": "lblAssigneeName",
                    "lblDuration": "lblDuration",
                    "lblRole": "lblRole",
                    "lblStatus": "lblStatus"
                },
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            var flxStatusFilterPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxStatusFilterPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "89%",
                "isModalContainer": false,
                "skin": "sknflxShadow",
                "top": "5dp",
                "width": "10%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxStatusFilterPopup.setDefaultUnit(kony.flex.DP);
            var segFilterStatus = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblFilter": "INITIATED"
                }, {
                    "lblFilter": "INPROGRESS"
                }, {
                    "lblFilter": "SUBMITTED"
                }, {
                    "lblFilter": "COMPLETED"
                }],
                "groupCells": false,
                "id": "segFilterStatus",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxFilterPopup",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFilterPopup": "flxFilterPopup",
                    "lblFilter": "lblFilter"
                },
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxStatusFilterPopup.add(segFilterStatus);
            var flxRoleFilterPopup = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxRoleFilterPopup",
                "isVisible": false,
                "layoutType": kony.flex.FREE_FORM,
                "left": "68%",
                "isModalContainer": false,
                "skin": "sknflxShadow",
                "top": "5dp",
                "width": "18%",
                "zIndex": 2,
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxRoleFilterPopup.setDefaultUnit(kony.flex.DP);
            var segFilterRole = new kony.ui.SegmentedUI2({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "data": [{
                    "lblFilter": "CONSULTANT"
                }, {
                    "lblFilter": "TRAINEE"
                }, {
                    "lblFilter": "INTERVIEWEE"
                }, {
                    "lblFilter": "PROSPECTIVE CANDIDATE"
                }],
                "groupCells": false,
                "id": "segFilterRole",
                "isVisible": true,
                "left": "0",
                "needPageIndicator": true,
                "pageOffDotImage": "pageoffdot.png",
                "pageOnDotImage": "pageondot.png",
                "retainSelection": false,
                "rowFocusSkin": "seg2Focus",
                "rowSkin": "seg2Normal",
                "rowTemplate": "flxFilterPopup",
                "sectionHeaderSkin": "sliPhoneSegmentHeader",
                "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
                "separatorColor": "aaaaaa00",
                "separatorRequired": true,
                "separatorThickness": 1,
                "showScrollbars": false,
                "top": "0",
                "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
                "widgetDataMap": {
                    "flxFilterPopup": "flxFilterPopup",
                    "lblFilter": "lblFilter"
                },
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "padding": [0, 0, 0, 0],
                "paddingInPixel": false
            }, {});
            flxRoleFilterPopup.add(segFilterRole);
            flxAssessmentList.add(segAssessmentList, flxStatusFilterPopup, flxRoleFilterPopup);
            flxBottom.add(flxAssessmentListTitle, flxAssessmentList);
            var flxFooter = new kony.ui.FlexContainer({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "clipBounds": false,
                "id": "flxFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0",
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "45dp",
                "width": "100%",
                "appName": "EPOLBRelease"
            }, {
                "paddingInPixel": false
            }, {});
            flxFooter.setDefaultUnit(kony.flex.DP);
            var appFooter = new com.evaluationPortal.appFooter({
                "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                "id": "appFooter",
                "isVisible": true,
                "layoutType": kony.flex.FLOW_VERTICAL,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "appFooter": {
                        "autogrowMode": kony.flex.AUTOGROW_HEIGHT,
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            var copyrightFooter = new com.evaluationPortal.copyrightFooter({
                "autogrowMode": kony.flex.AUTOGROW_NONE,
                "height": "55dp",
                "id": "copyrightFooter",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_DEFAULT,
                "isModalContainer": false,
                "skin": "slFbox",
                "top": "0dp",
                "width": "100%",
                "zIndex": 1,
                "appName": "EPOLBRelease",
                "overrides": {
                    "copyrightFooter": {
                        "centerY": "viz.val_cleared",
                        "top": "0dp"
                    }
                }
            }, {
                "paddingInPixel": false,
                "overrides": {}
            }, {
                "overrides": {}
            });
            flxFooter.add(appFooter, copyrightFooter);
            flxBodyDash.add(flxTop, flxBottom, flxFooter);
            flxMiddleScroll.add(flxBodyDash);
            flxMainContent.add(flxMiddleScroll);
            flxMain.add(flxHeader, flxHeaderNew, flxMainContent);
            this.breakpointResetData = {};
            this.breakpointData = {
                maxBreakpointWidth: 1366,
            }
            this.compInstData = {
                "headerNew": {
                    "height": "100%"
                },
                "headerNew.imgHeader": {
                    "src": "logo_org2.png"
                },
                "headerNew.imgLogout": {
                    "src": "right_from_bracket_solid.png"
                },
                "headerNew.imgUserImage": {
                    "src": "user_solid.png"
                },
                "headerNew1.flxUserRoleName": {
                    "centerY": "",
                    "top": "35%"
                },
                "headerNew1": {
                    "height": "100%"
                },
                "headerNew1.imgHeader": {
                    "src": "aspirelogo.png"
                },
                "headerNew1.imgLogout": {
                    "src": "logout.png"
                },
                "headerNew1.imgUserImage": {
                    "src": "userimg.png"
                },
                "multiseriesverticalbar": {
                    "right": "",
                    "bottom": "",
                    "minWidth": "",
                    "minHeight": "",
                    "maxWidth": "",
                    "maxHeight": "",
                    "centerX": "",
                    "centerY": ""
                },
                "flxQuickLinks1.flxLinks": {
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "flxQuickLinks1": {
                    "top": "0dp",
                    "left": "0dp",
                    "right": "",
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks2": {
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks3": {
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinks4": {
                    "width": "100%"
                },
                "flxQuickLinks1.flxQuickLinksMain": {
                    "top": "35dp"
                },
                "flxQuickLinks1.flxQuickLinksTitle": {
                    "width": "100%"
                },
                "flxQuickLinks1.imgQuickLinks1": {
                    "src": "manageassesment.png"
                },
                "flxQuickLinks1.imgQuickLinks2": {
                    "src": "manageuser.png"
                },
                "flxQuickLinks1.imgQuickLinks3": {
                    "src": "managerole.png"
                },
                "flxQuickLinks1.imgQuickLinks4": {
                    "src": "managerole.png"
                },
                "flxQuickLinks1.lblQuickLinks": {
                    "top": "0dp"
                },
                "appFooter": {
                    "centerY": "",
                    "top": "0dp"
                },
                "copyrightFooter": {
                    "centerY": "",
                    "top": "0dp"
                }
            }
            this.add(flxMain);
        };
        return [{
            "addWidgets": addWidgetsfrmAdminDash,
            "enabledForIdleTimeout": false,
            "id": "frmAdminDash",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "skin": "sknfrmbgimg",
            "onBreakpointHandler": onBreakpointHandler,
            "breakpoints": [640, 1024, 1366],
            "appName": "EPOLBRelease"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "paddingInPixel": false
        }, {
            "onDeviceBack": controller.AS_Form_fb2965d26f3745f2ab5bb84dd8a69da8,
            "retainScrollPosition": false
        }]
    }
});